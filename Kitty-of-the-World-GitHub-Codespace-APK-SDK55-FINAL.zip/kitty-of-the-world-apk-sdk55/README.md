# Kitty of the World

Projet Expo SDK 55 prêt pour un build Android APK avec EAS Build depuis GitHub Codespaces.

## APK

```bash
npm install
npx eas-cli@latest login
npx eas-cli@latest build -p android --profile apk
```

L'icône Android et l'écran de démarrage sont déjà configurés dans `assets/` et `app.json`.
