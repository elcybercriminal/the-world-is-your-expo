# Kitty of the World

- Expo SDK 55
- Notifications de J’aime intégrées dans l’application
- Le propriétaire d’une publication voit un badge cœur et une liste des comptes qui ont aimé sa publication
- Les notifications s’appuient sur la collection `likes` déjà existante : aucune nouvelle collection Firestore n’est requise
