// Kitty of the World — Snack / Expo SDK 55
// VERSION V8 — profil compact inspiré de la mise en page Instagram, navigation du bas conservée.
// Remplacer tout App.js dans le Snack existant. Dépendances inchangées.
import { setupURLPolyfill, URL as StandardURL, URLSearchParams as StandardURLSearchParams } from 'react-native-url-polyfill';
setupURLPolyfill();

// Asset Metro charge hors du chargeur de modules virtuels.
const __AUTH_BG_VIDEO = require('./assets/auth-background.mp4');

const __modules = Object.create(null);
const __cache = Object.create(null);
function __normalize(parts){const o=[];for(const p of parts){if(!p||p==='.')continue;if(p==='..')o.pop();else o.push(p);}return o.join('/');}
function __resolve(from,spec){if(!spec.startsWith('.'))return spec;const base=from.split('/');base.pop();return __normalize(base.concat(spec.split('/')));}
const __externals={react:require('react'),'react-native':require('react-native'),'@expo/vector-icons':require('@expo/vector-icons'),'@react-native-async-storage/async-storage':require('@react-native-async-storage/async-storage'),expo:require('expo'),'expo-audio':require('expo-audio'),'expo-image-picker':require('expo-image-picker'),'expo-linear-gradient':require('expo-linear-gradient'),'expo-navigation-bar':require('expo-navigation-bar'),'expo-video':require('expo-video'),'react-native-safe-area-context':require('react-native-safe-area-context'),'react-native-webview':require('react-native-webview')};
function __load(id){if(__cache[id])return __cache[id].exports;const factory=__modules[id];if(!factory)throw new Error('Module local introuvable: '+id);const module={exports:{}};__cache[id]=module;const localRequire=(spec)=>spec.startsWith('.')?__load(__resolve(id,spec)):__externals[spec];factory(module,module.exports,localRequire);return module.exports;}

__modules["App"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = App;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const async_storage_1 = __importDefault(require("@react-native-async-storage/async-storage"));
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const NavigationBar = __importStar(require("expo-navigation-bar"));
const react_native_safe_area_context_1 = require("react-native-safe-area-context");
const api = __importStar(__load("src/api"));
const context_1 = __load("src/context");
const theme_1 = __load("src/theme");
const ui_1 = __load("src/components/ui");
const overlays_1 = __load("src/components/overlays");
const auth_1 = __load("src/screens/auth");
const social_1 = __load("src/screens/social");
const chat_1 = __load("src/screens/chat");
const settings_1 = __load("src/screens/settings");
const THEME_KEY = 'twy-theme-v1';
const DATA_SAVER_KEY = 'twy-data-saver-v1';
function App() { return react_1.default.createElement(react_native_safe_area_context_1.SafeAreaProvider, null,
    react_1.default.createElement(Root, null)); }
function Root() {
    const insets = (0, react_native_safe_area_context_1.useSafeAreaInsets)();
    const [booting, setBooting] = (0, react_1.useState)(true);
    const [resetPassword, setResetPassword] = (0, react_1.useState)(false);
    const [me, setMe] = (0, react_1.useState)(null);
    const [posts, setPosts] = (0, react_1.useState)([]);
    const refreshSerial = (0, react_1.useRef)(0);
    const logicMerge = __load('src/logic').mergePosts;
    const [followed, setFollowed] = (0, react_1.useState)([]);
    const [stack, setStack] = (0, react_1.useState)([{ name: 'home' }]);
    const [theme, setThemeState] = (0, react_1.useState)('system');
    const [dataSaver, setDataSaverState] = (0, react_1.useState)(false);
    const [toast, setToast] = (0, react_1.useState)('');
    const [viewer, setViewer] = (0, react_1.useState)(null);
    const [commentPost, setCommentPost] = (0, react_1.useState)(null);
    const [lightbox, setLightbox] = (0, react_1.useState)(null);
    const [hasMore, setHasMore] = (0, react_1.useState)(false);
    const [notificationUnread, setNotificationUnread] = (0, react_1.useState)(0);
    const notificationUnreadRef = (0, react_1.useRef)(null);
    const { colors, dark } = (0, theme_1.useResolvedTheme)(theme);
    const route = stack[stack.length - 1];
    const notify = (0, react_1.useCallback)((message) => { setToast(message); setTimeout(() => setToast(v => v === message ? '' : v), 3500); }, []);
    const run = (0, react_1.useCallback)(async (fn) => { try {
        return await fn();
    }
    catch (e) {
        notify(e?.message || 'Une erreur est survenue.');
        return undefined;
    } }, [notify]);
    const refresh = (0, react_1.useCallback)(async () => {
        if (!api.uid) return [];
        const ticket = ++refreshSerial.current;
        const [p, f] = await Promise.all([api.posts(0, 30), api.following()]);
        if (ticket === refreshSerial.current) { setPosts(p); setFollowed(f); setHasMore(p.length === 30); }
        return p;
    }, []);
    const loadMore = (0, react_1.useCallback)(async () => { if (!hasMore)
        return; const more = await api.posts(posts.length, 30); setPosts(v => [...v, ...more.filter(x => !v.some(y => y.id === x.id))]); setHasMore(more.length === 30); }, [hasMore, posts.length]);
    const setTheme = (0, react_1.useCallback)((value) => { setThemeState(value); async_storage_1.default.setItem(THEME_KEY, value).catch(() => { }); }, []);
    const setDataSaver = (0, react_1.useCallback)((value) => { const enabled = !!value; setDataSaverState(enabled); async_storage_1.default.setItem(DATA_SAVER_KEY, enabled ? '1' : '0').catch(() => { }); }, []);
    const push = (0, react_1.useCallback)((r) => { setViewer(null); setCommentPost(null); setLightbox(null); setStack(v => [...v, r]); }, []);
    const replaceTab = (0, react_1.useCallback)((name) => {
        if (name === 'chats' && api.guest) { notify('La messagerie est réservée aux comptes inscrits.'); return; }
        setViewer(null); setCommentPost(null); setLightbox(null); setStack([name === 'profile' ? { name: 'profile' } : { name }]);
    }, [notify]);
    const back = (0, react_1.useCallback)(() => { if (lightbox) {
        setLightbox(null);
        return;
    } if (commentPost) {
        setCommentPost(null);
        return;
    } if (viewer) {
        setViewer(null);
        return;
    } setStack(v => v.length > 1 ? v.slice(0, -1) : v); }, [lightbox, commentPost, viewer]);
    const logout = (0, react_1.useCallback)(async () => { await api.logout(); setMe(null); setPosts([]); setFollowed([]); setStack([{ name: 'home' }]); }, []);
    const signedIn = (0, react_1.useCallback)(async (p) => { setResetPassword(false); setMe(p); setStack([{ name: 'home' }]); await refresh(); }, [refresh]);
    const consumeAuthLink = (0, react_1.useCallback)(async () => null, []);
    (0, react_1.useEffect)(() => { let mounted = true; (async () => { try {
        const [saved, savedDataSaver] = await Promise.all([
            async_storage_1.default.getItem(THEME_KEY),
            async_storage_1.default.getItem(DATA_SAVER_KEY)
        ]);
        if (saved === 'light' || saved === 'dark' || saved === 'system')
            setThemeState(saved);
        setDataSaverState(savedDataSaver === '1');
        await api.init();
        const sess = await api.session();
        if (sess && mounted) {
            const p = await api.profile(api.uid);
            setMe(p);
            const [data, f] = await Promise.all([api.posts(0, 30), api.following()]);
            if (mounted) {
                setPosts(data);
                setFollowed(f);
                setHasMore(data.length === 30);
            }
        }
    }
    catch (e) {
        notify(e.message);
    }
    finally {
        if (mounted)
            setBooting(false);
    } })(); return () => { mounted = false; }; }, []);
    (0, react_1.useEffect)(() => { const sub = react_native_1.BackHandler.addEventListener('hardwareBackPress', () => {
        if (!me)
            return true;
        if (lightbox || commentPost || viewer || stack.length > 1) {
            back();
            return true;
        }
        if (route.name !== 'home') {
            setStack([{ name: 'home' }]);
            return true;
        }
        return true;
    }); return () => sub.remove(); }, [me, lightbox, commentPost, viewer, stack.length, back, route.name]);
    (0, react_1.useEffect)(() => {
        if (react_native_1.Platform.OS === 'android') {
            NavigationBar.setVisibilityAsync(lightbox ? 'hidden' : 'visible').catch(() => {});
            NavigationBar.setButtonStyleAsync(dark || viewer || lightbox ? 'light' : 'dark').catch(() => {});
        }
    }, [!!viewer, !!lightbox, dark]);
    (0, react_1.useEffect)(() => {
        if (!me || api.guest) {
            notificationUnreadRef.current = null;
            setNotificationUnread(0);
            return;
        }
        let live = true;
        const checkNotifications = async () => {
            try {
                const count = await api.unreadNotificationsCount();
                if (!live) return;
                if (notificationUnreadRef.current !== null && count > notificationUnreadRef.current) {
                    notify('❤️ Nouvelle notification : quelqu’un a aimé ta publication.');
                }
                notificationUnreadRef.current = count;
                setNotificationUnread(count);
            } catch {}
        };
        checkNotifications();
        const timer = setInterval(checkNotifications, 15000);
        return () => { live = false; clearInterval(timer); };
    }, [me?.id, notify]);
    if (booting)
        return react_1.default.createElement(react_native_1.View, { style: [a.loading, { backgroundColor: colors.bg }] },
            react_1.default.createElement(ui_1.RainbowMark, { size: 70 }),
            react_1.default.createElement(react_native_1.Text, { style: [a.loadingTitle, { color: colors.text }] }, "Kitty of the World"),
            react_1.default.createElement(react_native_1.ActivityIndicator, { color: colors.accent }));
    if (!me)
        return react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(react_native_1.StatusBar, { hidden: false, barStyle: dark ? 'light-content' : 'dark-content', backgroundColor: colors.bg }),
            react_1.default.createElement(auth_1.AuthScreen, { colors: colors, onReady: signedIn, notify: notify, reset: resetPassword }),
            !!toast && react_1.default.createElement(Toast, { text: toast }));
    const ctx = { isGuest: !!api.guest, registerPost: (post) => { refreshSerial.current++; setPosts(current => logicMerge([post], current)); }, me, setMe, posts, setPosts, followed, push, replaceTab, back, run, notify, refresh, view: (list, index) => setViewer({ posts: list, index }), comments: (p) => setCommentPost(p), lightbox: (url, kind = 'image') => setLightbox({ url, kind }), theme, setTheme, dataSaver, setDataSaver, notificationUnread, setNotificationUnread, logout, loadMore, hasMore };
    const mainTab = stack.length === 1 && ['home', 'explore', 'chats', 'profile'].includes(route.name);
    const ownProfileRoute = route.name === 'profile' && (!route.person || route.person.id === me.id);
    return react_1.default.createElement(context_1.AppContext.Provider, { value: ctx },
        react_1.default.createElement(react_native_1.View, { style: [a.app, { backgroundColor: viewer || lightbox ? '#000' : colors.bg, paddingTop: lightbox ? 0 : insets.top, paddingBottom: 0 }] },
            react_1.default.createElement(react_native_1.StatusBar, { hidden: !!lightbox, barStyle: dark || viewer ? 'light-content' : 'dark-content', backgroundColor: viewer ? '#000' : colors.bg }),
            react_1.default.createElement(react_native_1.View, { pointerEvents: viewer || lightbox ? 'none' : 'auto', accessibilityElementsHidden: !!viewer || !!lightbox, importantForAccessibility: viewer || lightbox ? 'no-hide-descendants' : 'auto', style: { flex: 1, display: viewer || lightbox ? 'none' : 'flex' } }, renderRoute(route, colors, !viewer && !lightbox)),
            viewer && react_1.default.createElement(overlays_1.FullViewer, { visible: !!viewer, posts: viewer?.posts || [], start: viewer?.index || 0, paused: !!commentPost, colors: colors, onClose: () => setViewer(null) }),
            !lightbox && (mainTab || ownProfileRoute || !!viewer) && react_1.default.createElement(BottomNav, { current: ['home', 'explore', 'chats', 'profile'].includes(route.name) ? route.name : stack[0]?.name, onTab: replaceTab, onCreate: () => push({ name: 'create' }), colors: viewer ? { ...colors, bg: '#08090b', text: '#fff', muted: '#b9bbc0', line: '#25262a' } : colors, bottom: insets.bottom, me: me }),
            react_1.default.createElement(overlays_1.CommentsModal, { post: commentPost, colors: colors, onClose: () => setCommentPost(null) }),
            lightbox && react_1.default.createElement(overlays_1.MediaLightbox, { open: lightbox, colors: colors, onClose: () => setLightbox(null) }),
            !!toast && react_1.default.createElement(Toast, { text: toast })));
}
function renderRoute(route, colors, enabled = true) { switch (route.name) {
    case 'home': return react_1.default.createElement(social_1.HomeScreen, { colors: colors, enabled: enabled });
    case 'notifications': return react_1.default.createElement(social_1.NotificationsScreen, { colors: colors });
    case 'explore': return react_1.default.createElement(social_1.ExploreScreen, { colors: colors, initialQuery: route.query });
    case 'chats': return react_1.default.createElement(chat_1.ChatListScreen, { colors: colors });
    case 'profile': return react_1.default.createElement(social_1.ProfileScreen, { person: route.person, colors: colors });
    case 'connections': return react_1.default.createElement(social_1.ConnectionsScreen, { person: route.person, initialMode: route.mode, colors: colors });
    case 'edit': return react_1.default.createElement(social_1.EditProfileScreen, { colors: colors });
    case 'create': return react_1.default.createElement(social_1.CreatePostScreen, { colors: colors });
    case 'people': return react_1.default.createElement(social_1.PeopleScreen, { colors: colors });
    case 'conversation': return react_1.default.createElement(chat_1.ConversationScreen, { thread: route.thread, colors: colors });
    case 'settings': return react_1.default.createElement(settings_1.SettingsScreen, { colors: colors });
} }
function BottomNav({ current, onTab, onCreate, colors, bottom, me }) {
    const tabs = [
        ['home', 'home-outline', 'Accueil'],
        ['explore', 'search-outline', 'Explorer'],
        ['create', 'add-circle-outline', 'Publier'],
        ['chats', 'paper-plane-outline', 'Messages'],
        ['profile', 'person-circle-outline', 'Profil']
    ];
    const iconFor = (id, icon) => {
        if (id === 'create') return icon;
        if (current !== id) return icon;
        return icon.replace('-outline', '');
    };
    return react_1.default.createElement(
        react_native_1.View,
        {
            style: [
                a.nav,
                {
                    backgroundColor: colors.bg,
                    borderTopColor: colors.line,
                    paddingBottom: Math.max(bottom || 0, 10)
                }
            ]
        },
        tabs.map(([id, icon, label]) =>
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    key: id,
                    accessibilityRole: "button",
                    accessibilityLabel: label,
                    onPress: () => id === 'create' ? onCreate() : onTab(id),
                    style: ({ pressed }) => [a.navItem, pressed && { opacity: .55 }]
                },
                id === 'profile' && me?.avatar
                    ? react_1.default.createElement(react_native_1.Image, {
                        source: __load('src/logic').sourceFor(me.avatar),
                        resizeMode: "cover",
                        style: {
                            width: 27,
                            height: 27,
                            borderRadius: 13.5,
                            borderWidth: current === 'profile' ? 2 : 1,
                            borderColor: current === 'profile' ? colors.text : colors.line
                        }
                    })
                    : react_1.default.createElement(Ionicons_1.default, {
                        name: iconFor(id, icon),
                        size: id === 'create' ? 28 : 25,
                        color: colors.text
                    })
            )
        )
    );
}
function Toast({ text }) { return react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: a.toast },
    react_1.default.createElement(react_native_1.Text, { style: a.toastText }, text)); }
const a = react_native_1.StyleSheet.create({ app: { flex: 1 }, rainbow: { height: 0 }, loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 15 }, loadingTitle: { fontSize: 28, fontWeight: '900', letterSpacing: -1.5 }, nav: { minHeight: 52, borderTopWidth: 1, flexDirection: 'row', paddingTop: 2, paddingHorizontal: 2 }, navItem: { flex: 1, minHeight: 47, alignItems: 'center', justifyContent: 'center', position: 'relative' }, navActive: { display: 'none' }, toast: { position: 'absolute', left: 18, right: 18, bottom: 68, backgroundColor: '#252a31', paddingHorizontal: 16, paddingVertical: 12, borderRadius: 12, elevation: 20 }, toastText: { color: '#fff', fontSize: 12.5, lineHeight: 18 } });

};

__modules["src/api"] = function(module,exports,require){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) { return (mod && mod.__esModule) ? mod : { "default": mod }; };
Object.defineProperty(exports, "__esModule", { value: true });
exports.configured = exports.guest = exports.uid = exports.client = void 0;
exports.init = init;
exports.getConfig = getConfig;
exports.setConfig = setConfig;
exports.clearConfig = clearConfig;
exports.session = session;
exports.login = login;
exports.signup = signup;
exports.continueAsGuest = continueAsGuest;
exports.logout = logout;
exports.deleteAccount = deleteAccount;
exports.sendPasswordReset = sendPasswordReset;
exports.changePassword = changePassword;
exports.profile = profile;
exports.updateProfile = updateProfile;
exports.posts = posts;
exports.addPost = addPost;
exports.repostState = repostState;
exports.setRepost = setRepost;
exports.removePost = removePost;
exports.toggle = toggle;
exports.likeNotifications = likeNotifications;
exports.unreadNotificationsCount = unreadNotificationsCount;
exports.markNotificationsSeen = markNotificationsSeen;
exports.getComments = getComments;
exports.comment = comment;
exports.people = people;
exports.following = following;
exports.followersOf = followersOf;
exports.followingOf = followingOf;
exports.follow = follow;
exports.stats = stats;
exports.profilePosts = profilePosts;
exports.profileActivity = profileActivity;
exports.openThread = openThread;
exports.threads = threads;
exports.messages = messages;
exports.markRead = markRead;
exports.send = send;
exports.upload = upload;
exports.block = block;
exports.report = report;
exports.resolveAsset = resolveAsset;
const async_storage_1 = __importDefault(require("@react-native-async-storage/async-storage"));
const logic_1 = __load("src/logic");

const FIREBASE_CONFIG = {
    apiKey: 'AIzaSyByEW-1u5fhlZjEpwcmaMTjQahD-EIwSUM',
    authDomain: 'kidflix-953e1.firebaseapp.com',
    projectId: 'kidflix-953e1',
    storageBucket: 'kidflix-953e1.firebasestorage.app',
    appId: '1:146973041352:web:b3ede3adf7a12aac26fbfd'
};
const INTERNAL_EMAIL_DOMAIN = 'kidflix.invalid';
const NOTIFICATION_SEEN_PREFIX = 'ktw-like-notifications-seen-v1:';
const AUTH_SESSION_KEY = 'twy-firebase-rest-session-v1';
const AUTH_BASE = 'https://identitytoolkit.googleapis.com/v1';
const TOKEN_BASE = 'https://securetoken.googleapis.com/v1';
const FIRESTORE_BASE = 'https://firestore.googleapis.com/v1/projects/' + FIREBASE_CONFIG.projectId + '/databases/(default)/documents';
const IMAGEKIT_PUBLIC_KEY = 'public_ryUQYeBJUOv4BOukFMiU53GrwwQ=';
const IMAGEKIT_URL_ENDPOINT = 'https://ik.imagekit.io/e0fg07buj5';
const IMAGEKIT_AUTH_ENDPOINT = 'https://cool-scone-987bb2.netlify.app/api/imagekit-auth';
const IMAGEKIT_UPLOAD_ENDPOINT = 'https://upload.imagekit.io/api/v1/files/upload';
let authSession = null;
exports.client = { provider: 'firebase-rest' };
exports.uid = '';
exports.guest = false;

function rid() { return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10); }
function clean(value = '') { return String(value ?? '').trim(); }
function slugIdentifier(value = '') {
    const source = clean(value).toLowerCase();
    return source.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9._-]+/g, '.').replace(/^\.+|\.+$/g, '') || ('user' + Date.now());
}
function internalEmail(raw = '') {
    const value = slugIdentifier(clean(raw).toLowerCase()).slice(0, 40);
    return value + '@' + INTERNAL_EMAIL_DOMAIN;
}
function cleanIdentifier(raw = '') {
    return slugIdentifier(raw).replace(/\.+/g, '.').slice(0, 24);
}
function validateIdentifier(raw = '') {
    const id = cleanIdentifier(raw);
    if (id.length < 3) throw new Error('Ton identifiant doit contenir au moins 3 caractères.');
    return id;
}
function usernameFromHandle(value = '') { return clean(value).replace(/^@+/, '') || 'utilisateur'; }
function toIso(value) {
    if (!value) return new Date(0).toISOString();
    if (typeof value === 'string') return value;
    const d = new Date(value); return Number.isNaN(d.getTime()) ? new Date(0).toISOString() : d.toISOString();
}
function normalizeProfile(data = {}, id = '') {
    const rawHandle = data.username || data.handle || data.name || 'utilisateur';
    const username = usernameFromHandle(rawHandle);
    return {
        id: id || data.id || data.uid || '',
        uid: id || data.uid || data.id || '',
        username,
        handle: '@' + username,
        name: data.name || username,
        bio: data.bio || '',
        website: data.website || data.link || '',
        link: data.link || data.website || '',
        email: data.email || '',
        avatar: data.avatar || data.avatarUrl || '',
        avatarUrl: data.avatarUrl || data.avatar || '',
        banner: data.banner?.url || data.bannerUrl || data.banner || '',
        bannerPosition: Number(data.bannerPosition ?? 50),
        privateAccount: !!data.privateAccount,
        guest: !!data.guest
    };
}
function firebaseMessage(error) {
    const raw = String(error?.message || error?.error?.message || error || '');
    const code = raw.replace(/^Firebase:\s*/i, '').split(' ')[0].replace(/[().]/g, '');
    const messages = {
        EMAIL_EXISTS: 'Cet identifiant est déjà utilisé.',
        INVALID_LOGIN_CREDENTIALS: 'Identifiant ou mot de passe incorrect.',
        INVALID_PASSWORD: 'Mot de passe incorrect.',
        EMAIL_NOT_FOUND: 'Identifiant introuvable.',
        WEAK_PASSWORD: 'Mot de passe trop faible : 6 caractères minimum.',
        INVALID_EMAIL: 'Identifiant invalide.',
        TOO_MANY_ATTEMPTS_TRY_LATER: 'Trop de tentatives. Réessaie un peu plus tard.',
        OPERATION_NOT_ALLOWED: 'Active Email/Mot de passe et Anonyme dans Firebase Authentication.',
        USER_DISABLED: 'Ce compte est désactivé.'
    };
    return messages[code] || messages[raw] || raw || 'Une erreur est survenue.';
}
async function jsonFetch(url, options = {}) {
    let res;
    try { res = await fetch(url, options); }
    catch { throw new Error('Connexion Internet indisponible.'); }
    let data = null;
    try { data = await res.json(); } catch {}
    if (!res.ok) {
        const message = data?.error?.message || data?.message || ('Erreur HTTP ' + res.status);
        throw new Error(firebaseMessage(message));
    }
    return data;
}
async function saveAuth(data) {
    if (!data) {
        authSession = null; exports.uid = ''; exports.guest = false;
        await async_storage_1.default.removeItem(AUTH_SESSION_KEY).catch(() => {});
        return;
    }
    const expiresIn = Number(data.expiresIn || data.expires_in || 3600);
    authSession = {
        uid: data.localId || data.user_id || data.uid || authSession?.uid || '',
        email: data.email || authSession?.email || '',
        idToken: data.idToken || data.id_token || authSession?.idToken || '',
        refreshToken: data.refreshToken || data.refresh_token || authSession?.refreshToken || '',
        expiresAt: Date.now() + Math.max(60, expiresIn - 30) * 1000,
        isAnonymous: data.isAnonymous ?? authSession?.isAnonymous ?? false
    };
    exports.uid = authSession.uid;
    exports.guest = !!authSession.isAnonymous;
    await async_storage_1.default.setItem(AUTH_SESSION_KEY, JSON.stringify(authSession));
}
async function refreshAuth(force = false) {
    if (!authSession) return null;
    if (!force && authSession.idToken && authSession.expiresAt > Date.now() + 60000) return authSession;
    if (!authSession.refreshToken) { await saveAuth(null); return null; }
    try {
        const data = await jsonFetch(TOKEN_BASE + '/token?key=' + encodeURIComponent(FIREBASE_CONFIG.apiKey), {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'grant_type=refresh_token&refresh_token=' + encodeURIComponent(authSession.refreshToken)
        });
        await saveAuth(data);
        return authSession;
    } catch (e) {
        await saveAuth(null);
        return null;
    }
}
async function authPost(method, body) {
    return jsonFetch(AUTH_BASE + '/accounts:' + method + '?key=' + encodeURIComponent(FIREBASE_CONFIG.apiKey), {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
}
function encodeValue(value) {
    if (value === null || value === undefined) return { nullValue: null };
    if (typeof value === 'string') return { stringValue: value };
    if (typeof value === 'boolean') return { booleanValue: value };
    if (typeof value === 'number') return Number.isInteger(value) ? { integerValue: String(value) } : { doubleValue: value };
    if (Array.isArray(value)) return { arrayValue: { values: value.map(encodeValue) } };
    if (typeof value === 'object') return { mapValue: { fields: encodeFields(value) } };
    return { stringValue: String(value) };
}
function encodeFields(obj = {}) {
    const fields = {};
    for (const [k, v] of Object.entries(obj)) if (v !== undefined) fields[k] = encodeValue(v);
    return fields;
}
function decodeValue(v) {
    if (!v || typeof v !== 'object') return null;
    if ('stringValue' in v) return v.stringValue;
    if ('integerValue' in v) return Number(v.integerValue);
    if ('doubleValue' in v) return Number(v.doubleValue);
    if ('booleanValue' in v) return !!v.booleanValue;
    if ('nullValue' in v) return null;
    if ('timestampValue' in v) return v.timestampValue;
    if ('arrayValue' in v) return (v.arrayValue?.values || []).map(decodeValue);
    if ('mapValue' in v) return decodeFields(v.mapValue?.fields || {});
    return null;
}
function decodeFields(fields = {}) {
    const out = {};
    for (const [k, v] of Object.entries(fields)) out[k] = decodeValue(v);
    return out;
}
function docIdFromName(name = '') { return decodeURIComponent(name.split('/').pop() || ''); }
async function firestoreFetch(path, options = {}, retry = true) {
    const sess = await refreshAuth(false);
    if (!sess?.idToken) throw new Error('Connecte-toi pour continuer.');
    const headers = { ...(options.headers || {}), Authorization: 'Bearer ' + sess.idToken };
    if (options.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    let res;
    try { res = await fetch(FIRESTORE_BASE + path, { ...options, headers }); }
    catch { throw new Error('Connexion Internet indisponible.'); }
    if (res.status === 401 && retry) {
        const refreshed = await refreshAuth(true);
        if (refreshed) return firestoreFetch(path, options, false);
    }
    if (res.status === 404) return null;
    let data = null; try { data = await res.json(); } catch {}
    if (!res.ok) throw new Error(data?.error?.message || ('Firestore HTTP ' + res.status));
    return data;
}
async function getDocument(name, id) {
    const data = await firestoreFetch('/' + encodeURIComponent(name) + '/' + encodeURIComponent(id), { method: 'GET' });
    return data ? { id, ...decodeFields(data.fields || {}) } : null;
}
async function setDocument(name, id, data, merge = false) {
    let bodyData = data;
    if (merge) {
        const existing = await getDocument(name, id).catch(() => null);
        bodyData = { ...(existing || {}), ...data };
        delete bodyData.id;
    }
    await firestoreFetch('/' + encodeURIComponent(name) + '/' + encodeURIComponent(id), { method: 'PATCH', body: JSON.stringify({ fields: encodeFields(bodyData) }) });
}
async function updateDocument(name, id, data) { return setDocument(name, id, data, true); }
async function deleteDocument(name, id) { await firestoreFetch('/' + encodeURIComponent(name) + '/' + encodeURIComponent(id), { method: 'DELETE' }); }
async function allDocs(name) {
    const out = []; let token = '';
    do {
        const qs = '?pageSize=500' + (token ? '&pageToken=' + encodeURIComponent(token) : '');
        const data = await firestoreFetch('/' + encodeURIComponent(name) + qs, { method: 'GET' });
        for (const d of data?.documents || []) out.push({ id: docIdFromName(d.name), ...decodeFields(d.fields || {}) });
        token = data?.nextPageToken || '';
    } while (token && out.length < 5000);
    return out;
}
async function queryDocs(name, field, op, value) {
    const sess = await refreshAuth(false);
    if (!sess?.idToken) throw new Error('Connecte-toi pour continuer.');
    const body = {
        structuredQuery: {
            from: [{ collectionId: name }],
            where: { fieldFilter: { field: { fieldPath: field }, op, value: encodeValue(value) } },
            limit: 500
        }
    };
    let res;
    try {
        res = await fetch(FIRESTORE_BASE + ':runQuery', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + sess.idToken },
            body: JSON.stringify(body)
        });
    } catch { throw new Error('Connexion Internet indisponible.'); }
    if (res.status === 401) {
        const refreshed = await refreshAuth(true);
        if (refreshed?.idToken) return queryDocs(name, field, op, value);
    }
    let rows = null; try { rows = await res.json(); } catch {}
    if (!res.ok) throw new Error(rows?.error?.message || ('Firestore HTTP ' + res.status));
    return (rows || []).filter(x => x.document).map(x => ({ id: docIdFromName(x.document.name), ...decodeFields(x.document.fields || {}) }));
}
async function init() {
    const storedAuth = await async_storage_1.default.getItem(AUTH_SESSION_KEY).catch(() => null);
    if (storedAuth) { try { authSession = JSON.parse(storedAuth); } catch { authSession = null; } }
    await refreshAuth(false);
    exports.uid = authSession?.uid || '';
    exports.guest = !!authSession?.isAnonymous;
    exports.client = { provider: 'firebase-rest' };
    return { firebaseProjectId: FIREBASE_CONFIG.projectId, mediaProvider: 'imagekit' };
}
const configured = () => true;
exports.configured = configured;
async function getConfig() { return { firebaseProjectId: FIREBASE_CONFIG.projectId, mediaProvider: 'imagekit', imagekitEndpoint: IMAGEKIT_URL_ENDPOINT, authDomain: FIREBASE_CONFIG.authDomain }; }
async function setConfig() { return getConfig(); }
async function clearConfig() { return getConfig(); }
async function session() {
    await refreshAuth(false);
    exports.uid = authSession?.uid || '';
    exports.guest = !!authSession?.isAnonymous;
    return authSession ? { uid: authSession.uid, email: authSession.email, isAnonymous: !!authSession.isAnonymous } : null;
}
async function ensureProfile(user, rawIdentifier = '') {
    if (!user?.uid) return null;
    const existing = await getDocument('profiles', user.uid);
    if (existing) return normalizeProfile(existing, user.uid);
    const identifier = validateIdentifier(rawIdentifier || 'utilisateur');
    const username = identifier.replace(/\./g, '_').slice(0, 24) || 'utilisateur';
    const name = username.charAt(0).toUpperCase() + username.slice(1);
    const now = new Date().toISOString();
    const data = { uid: user.uid, id: user.uid, name, handle: '@' + username, username, email: '', bio: '', link: '', website: '', avatarUrl: '', avatar: '', banner: '', bannerPosition: 50, privateAccount: false, guest: false, createdAt: now, created_at: now };
    await setDocument('profiles', user.uid, data, true);
    return normalizeProfile(data, user.uid);
}
async function ensureGuestProfile(user) {
    if (!user?.uid) return null;
    const existing = await getDocument('profiles', user.uid);
    if (existing) return normalizeProfile(existing, user.uid);
    const suffix = String(user.uid).replace(/[^a-z0-9]/gi, '').slice(0, 7).toLowerCase() || Math.random().toString(36).slice(2, 8);
    const username = 'visiteur_' + suffix;
    const now = new Date().toISOString();
    const data = { uid: user.uid, id: user.uid, name: 'Visiteur', handle: '@' + username, username, email: '', bio: 'Compte visiteur', link: '', website: '', avatarUrl: '', avatar: '', banner: '', bannerPosition: 50, privateAccount: false, guest: true, createdAt: now, created_at: now };
    await setDocument('profiles', user.uid, data, true);
    return normalizeProfile(data, user.uid);
}
async function login(identifier, password) {
    const id = validateIdentifier(identifier);
    if (!password) throw new Error('Entre ton mot de passe.');
    const data = await authPost('signInWithPassword', { email: internalEmail(id), password, returnSecureToken: true });
    await saveAuth({ ...data, isAnonymous: false });
    return ensureProfile({ uid: data.localId }, id);
}
async function signup(identifier, password) {
    const id = validateIdentifier(identifier);
    if (clean(password).length < 6) throw new Error('Le mot de passe doit contenir au moins 6 caractères.');
    const data = await authPost('signUp', { email: internalEmail(id), password, returnSecureToken: true });
    await saveAuth({ ...data, isAnonymous: false });
    return ensureProfile({ uid: data.localId }, id);
}
async function continueAsGuest() {
    const data = await authPost('signUp', { returnSecureToken: true });
    await saveAuth({ ...data, isAnonymous: true });
    return ensureGuestProfile({ uid: data.localId });
}
async function logout() { await saveAuth(null); }
async function deleteAccount() {
    const sess = await refreshAuth(false);
    if (!sess?.idToken || !sess?.uid) throw new Error('Aucun compte connecté.');
    const userId = sess.uid;

    // Supprime d'abord les publications de l'utilisateur et leurs interactions associées.
    try {
        const ownPosts = (await allDocs('posts')).filter(x => x.user_id === userId);
        for (const post of ownPosts) {
            try { await removePost(post.id); } catch {}
        }
    } catch {}

    // Nettoyage des données directement rattachées au compte. Certaines suppressions
    // peuvent être refusées par les règles Firestore (ex. données créées par un tiers) :
    // elles sont alors simplement ignorées sans bloquer la suppression du compte.
    const cleanup = [
        ['likes', x => x.user_id === userId],
        ['saves', x => x.user_id === userId],
        ['comments', x => x.user_id === userId],
        ['follows', x => x.follower_id === userId || x.following_id === userId],
        ['blocks', x => x.user_id === userId || x.blocked_id === userId],
        ['reports', x => x.user_id === userId]
    ];
    for (const [name, belongsToUser] of cleanup) {
        try {
            const rows = await allDocs(name);
            for (const row of rows.filter(belongsToUser)) {
                try { await deleteDocument(name, row.id); } catch {}
            }
        } catch {}
    }

    try { await deleteDocument('profiles', userId); } catch {}

    // Supprime enfin le compte Firebase Authentication.
    await authPost('delete', { idToken: sess.idToken });
    await saveAuth(null);
}
async function sendPasswordReset() { throw new Error('Les comptes utilisent un identifiant sans adresse e-mail.'); }
async function changePassword(password) {
    if (!authSession?.idToken) throw new Error('Aucun compte connecté.');
    if (clean(password).length < 6) throw new Error('Le mot de passe doit contenir au moins 6 caractères.');
    const data = await authPost('update', { idToken: authSession.idToken, password, returnSecureToken: true });
    await saveAuth(data);
}
async function profile(id) {
    const row = await getDocument('profiles', id);
    if (row) return normalizeProfile(row, id);
    if (id === exports.uid && authSession) return authSession.isAnonymous ? ensureGuestProfile({ uid: authSession.uid }) : ensureProfile({ uid: authSession.uid }, String(authSession.email || '').split('@')[0]);
    throw new Error('Profil introuvable.');
}
async function updateProfile(p) {
    const username = (0, logic_1.cleanUsername)(p.username || p.handle || '');
    if (p.website && !(0, logic_1.safeUrl)(p.website)) throw new Error('Le lien du profil doit commencer par https://.');
    if (!(0, logic_1.validUsername)(username)) throw new Error('Pseudo : 3 à 24 caractères, lettres sans accents, chiffres, points ou _.');
    const data = { uid: exports.uid, id: exports.uid, name: p.name || username, handle: '@' + username, username, bio: p.bio || '', link: p.website || '', website: p.website || '', avatarUrl: p.avatar || '', avatar: p.avatar || '', banner: p.banner || '', bannerPosition: Number(p.bannerPosition ?? 50), privateAccount: !!p.privateAccount, guest: !!exports.guest, updatedAt: new Date().toISOString() };
    await setDocument('profiles', exports.uid, data, true);
    return normalizeProfile({ ...p, ...data }, exports.uid);
}
async function hydratePosts(rows) {
    const [profiles, likes, saves, comments] = await Promise.all([allDocs('profiles'), allDocs('likes'), allDocs('saves'), allDocs('comments')]);
    const profileMap = new Map(profiles.map(x => [x.id, normalizeProfile(x, x.id)]));
    return rows.map(p => {
        const userId = p.user_id || p.uid || '';
        const owner = profileMap.get(userId) || normalizeProfile({ username: 'utilisateur', name: 'Utilisateur' }, userId);
        const repostSourceId = p.media?.[0]?.repost?.source_user_id || '';
        const repostSource = repostSourceId ? profileMap.get(repostSourceId) : null;
        return {
            ...p,
            id: p.id,
            user_id: userId,
            caption: p.caption || '',
            media: Array.isArray(p.media) ? p.media : [],
            created_at: toIso(p.created_at || p.createdAt),
            owner,
            likes: likes.filter(x => x.post_id === p.id).map(x => ({ user_id: x.user_id })),
            saves: saves.filter(x => x.post_id === p.id).map(x => ({ user_id: x.user_id })),
            comments: comments.filter(x => x.post_id === p.id).map(x => ({ id: x.id })),
            _hiddenByPrivacy: (owner.privateAccount && userId !== exports.uid) || (!!repostSource?.privateAccount && repostSourceId !== exports.uid)
        };
    }).filter(p => !p._hiddenByPrivacy).map(({ _hiddenByPrivacy, ...p }) => p);
}
async function posts(offset = 0, limit = 30) {
    const rows = await allDocs('posts');
    rows.sort((a,b) => Date.parse(toIso(b.created_at || b.createdAt)) - Date.parse(toIso(a.created_at || a.createdAt)));
    return hydratePosts(rows.slice(offset, offset + limit));
}
async function addPost(caption, media) {
    const id = rid(); const created_at = new Date().toISOString();
    const serial = JSON.parse(JSON.stringify((media || []).map(m => ({ ...m, url: typeof m.url === 'string' ? m.url : '' }))));
    const data = { id, user_id: exports.uid, caption: caption || '', media: serial, created_at, createdAt: created_at };
    await setDocument('posts', id, data);
    return { ...data, owner: await profile(exports.uid), likes: [], saves: [], comments: [] };
}
async function repostState(sourceId) {
    const rows = await posts(0, 500);
    const found = rows.filter(p => p.media?.[0]?.repost?.source_post_id === sourceId);
    return { count: found.length, mine: found.find(p => p.user_id === exports.uid) || null };
}
const repostLocks = new Map();
async function setRepost(post, enabled) {
    const previous = post.media?.[0]?.repost; const sourceId = previous?.source_post_id || post.id; const key = exports.uid + ':' + sourceId;
    if (repostLocks.has(key)) return repostLocks.get(key);
    const task = (async () => {
        const state = await repostState(sourceId);
        if (enabled && state.mine) return { created: state.mine, removedId: null, count: state.count };
        if (!enabled) { if (state.mine) await removePost(state.mine.id); return { created: null, removedId: state.mine?.id || null, count: Math.max(0, state.count - (state.mine ? 1 : 0)) }; }
        const source = await getDocument('posts', sourceId);
        if (!source) throw new Error('La publication d’origine n’est plus disponible.');
        const owner = await profile(source.user_id); const author = owner.username || 'compte';
        const meta = { source_post_id: sourceId, source_user_id: source.user_id, source_username: author, source_caption: source.caption || '' };
        const media = (source.media || []).map((m,i) => i === 0 ? { ...m, repost: meta } : m);
        const created = await addPost(('↻ Republication de @' + author + (source.caption ? '\n' + source.caption : '')).slice(0,2200), media);
        return { created, removedId: null, count: state.count + 1 };
    })();
    repostLocks.set(key, task); try { return await task; } finally { repostLocks.delete(key); }
}
async function removePost(id) {
    const row = await getDocument('posts', id); if (!row) return;
    if (row.user_id !== exports.uid) throw new Error('Tu peux supprimer uniquement tes publications.');
    await deleteDocument('posts', id);
    for (const name of ['likes','saves','comments']) { const rows = await allDocs(name); await Promise.all(rows.filter(x => x.post_id === id).map(x => deleteDocument(name, x.id))); }
}
async function toggle(table, post) {
    if (!['likes','saves'].includes(table)) throw new Error('Action inconnue.');
    const id = exports.uid + '__' + post.id; const row = await getDocument(table, id);
    if (row) await deleteDocument(table, id); else { const now = new Date().toISOString(); await setDocument(table, id, { user_id: exports.uid, post_id: post.id, created_at: now, createdAt: now }); }
}

async function likeNotifications() {
    if (!exports.uid) return [];
    const [postRows, likeRows, profileRows] = await Promise.all([
        allDocs('posts'),
        allDocs('likes'),
        allDocs('profiles')
    ]);
    const ownPosts = postRows.filter(p => p.user_id === exports.uid);
    const ownPostMap = new Map(ownPosts.map(p => [p.id, p]));
    const profileMap = new Map(profileRows.map(p => [p.id, normalizeProfile(p, p.id)]));
    return likeRows
        .filter(like => like.user_id !== exports.uid && ownPostMap.has(like.post_id))
        .map(like => ({
            id: like.id,
            type: 'like',
            post_id: like.post_id,
            user_id: like.user_id,
            actor: profileMap.get(like.user_id) || normalizeProfile({}, like.user_id),
            post: ownPostMap.get(like.post_id),
            created_at: toIso(like.created_at || like.createdAt)
        }))
        .sort((a, b) => Date.parse(b.created_at || 0) - Date.parse(a.created_at || 0));
}
async function unreadNotificationsCount() {
    if (!exports.uid) return 0;
    const [items, seenRaw] = await Promise.all([
        likeNotifications(),
        async_storage_1.default.getItem(NOTIFICATION_SEEN_PREFIX + exports.uid).catch(() => '')
    ]);
    const seen = Date.parse(seenRaw || 0) || 0;
    return items.filter(item => (Date.parse(item.created_at || 0) || 0) > seen).length;
}
async function markNotificationsSeen() {
    if (!exports.uid) return;
    await async_storage_1.default.setItem(NOTIFICATION_SEEN_PREFIX + exports.uid, new Date().toISOString());
}
async function getComments(post_id) {
    const rows = (await allDocs('comments')).filter(x => x.post_id === post_id).sort((a,b) => Date.parse(toIso(a.created_at || a.createdAt)) - Date.parse(toIso(b.created_at || b.createdAt)));
    const result = []; for (const c of rows) { let owner; try { owner = await profile(c.user_id); } catch { owner = normalizeProfile({}, c.user_id); } result.push({ ...c, created_at: toIso(c.created_at || c.createdAt), owner }); } return result;
}
async function comment(post_id, body) { const id = rid(); const now = new Date().toISOString(); await setDocument('comments', id, { id, post_id, user_id: exports.uid, body, created_at: now, createdAt: now }); }
async function people(q = '') {
    // Firestore rules only allow a user to read their own block documents.
    // Querying the whole `blocks` collection made the new-chat screen fail with
    // "Missing or insufficient permissions". Restrict the query to this user.
    const [rows, blocks] = await Promise.all([
        allDocs('profiles'),
        queryDocs('blocks', 'user_id', 'EQUAL', exports.uid)
    ]);
    const blocked = new Set(blocks.map(x => x.blocked_id));
    const needle = clean(q).toLowerCase().replace(/^@/, '');
    return rows
        .map(x => normalizeProfile(x, x.id))
        .filter(p => p.id !== exports.uid && !blocked.has(p.id) && (!needle || (p.username + ' ' + p.name).toLowerCase().includes(needle)))
        .slice(0,40);
}
async function following() { return (await allDocs('follows')).filter(x => x.follower_id === exports.uid).map(x => x.following_id); }
async function profilesFromFollowRows(rows, field) {
    const ordered = [...rows].sort((a,b) => Date.parse(toIso(b.created_at || b.createdAt || 0)) - Date.parse(toIso(a.created_at || a.createdAt || 0)));
    const result = [];
    const seen = new Set();
    for (const row of ordered) {
        const id = row[field];
        if (!id || seen.has(id)) continue;
        seen.add(id);
        try { result.push(await profile(id)); }
        catch { result.push(normalizeProfile({}, id)); }
    }
    return result;
}
async function followersOf(id) {
    const rows = (await allDocs('follows')).filter(x => x.following_id === id);
    return profilesFromFollowRows(rows, 'follower_id');
}
async function followingOf(id) {
    const rows = (await allDocs('follows')).filter(x => x.follower_id === id);
    return profilesFromFollowRows(rows, 'following_id');
}
async function follow(id) {
    const key = exports.uid + '__' + id; const row = await getDocument('follows', key);
    if (row) await deleteDocument('follows', key); else { const now = new Date().toISOString(); await setDocument('follows', key, { follower_id: exports.uid, following_id: id, created_at: now, createdAt: now }); }
}
async function stats(id) {
    const [p,f] = await Promise.all([allDocs('posts'), allDocs('follows')]);
    return {
        posts: p.filter(x => x.user_id === id && !x.media?.[0]?.repost?.source_post_id).length,
        followers: f.filter(x => x.following_id === id).length,
        following: f.filter(x => x.follower_id === id).length
    };
}
async function profilePosts(id, saved = false, offset = 0) {
    let rows = await posts(0, 1000);
    if (saved) {
        const ids = new Set((await allDocs('saves')).filter(x => x.user_id === exports.uid).map(x => x.post_id));
        rows = rows.filter(p => ids.has(p.id));
    } else {
        // Les republications n'apparaissent jamais dans la grille Publications.
        // Elles restent visibles dans l'onglet 🥵 via profileActivityItems().
        rows = rows.filter(p => p.user_id === id && !p.media?.[0]?.repost?.source_post_id);
    }
    return rows.slice(offset, offset + 30);
}
async function profileActivity(offset = 0, limit = 30) { const rows = await posts(0,1000); const selected = (0, logic_1.profileActivityItems)(rows, exports.uid); return selected.slice(offset, offset + limit); }
function requireRegisteredAccount() {
    if (exports.guest) throw new Error('La messagerie est réservée aux comptes inscrits.');
    if (!exports.uid) throw new Error('Connecte-toi pour accéder à la messagerie.');
}
async function openThread(peer) {
    requireRegisteredAccount();
    if (!peer?.id) throw new Error('Compte introuvable.');
    if (peer.guest) throw new Error('La messagerie est réservée aux comptes inscrits.');
    const ids = [exports.uid, peer.id].sort();
    const id = ids.join('__');
    const now = new Date().toISOString();
    // Do not GET a possibly non-existent thread first: Firestore rules can reject
    // that read because resource.data does not exist yet. Upserting the deterministic
    // thread id directly works for both a new and an existing conversation.
    await setDocument('threads', id, {
        id,
        user_a: ids[0],
        user_b: ids[1],
        members: ids,
        created_at: now,
        createdAt: now,
        updated_at: now
    });
    return { id, user_a: ids[0], user_b: ids[1], members: ids, peer, created_at: now, unread: 0 };
}
async function threads() {
    requireRegisteredAccount();
    const mine = await queryDocs('threads', 'members', 'ARRAY_CONTAINS', exports.uid);
    const out = [];
    for (const t of mine) {
        const peerId = t.user_a === exports.uid ? t.user_b : t.user_a;
        let peer; try { peer = await profile(peerId); } catch { peer = normalizeProfile({}, peerId); }
        const msgs = (await queryDocs('messages', 'thread_id', 'EQUAL', t.id)).sort((a,b) => Date.parse(toIso(a.created_at || a.createdAt)) - Date.parse(toIso(b.created_at || b.createdAt)));
        const last = msgs.at(-1);
        const unread = msgs.filter(m => m.sender_id !== exports.uid && !m.read_at).length;
        out.push({ ...t, id: t.id, peer, last, unread, created_at: toIso(t.created_at || t.createdAt) });
    }
    return out.sort((a,b) => Date.parse(toIso(b.last?.created_at || b.created_at)) - Date.parse(toIso(a.last?.created_at || a.created_at)));
}
async function messages(thread_id) {
    requireRegisteredAccount();
    return (await queryDocs('messages', 'thread_id', 'EQUAL', thread_id))
        .sort((a,b) => Date.parse(toIso(a.created_at || a.createdAt)) - Date.parse(toIso(b.created_at || b.createdAt)))
        .map(m => ({ ...m, created_at: toIso(m.created_at || m.createdAt), url: m.media_path || '' }));
}
async function markRead(thread_id) {
    requireRegisteredAccount();
    const rows = (await queryDocs('messages', 'thread_id', 'EQUAL', thread_id)).filter(m => m.sender_id !== exports.uid && !m.read_at);
    await Promise.all(rows.map(m => updateDocument('messages', m.id, { read_at: new Date().toISOString() })));
}
async function send(thread_id, kind, body = '', media_path = '') { requireRegisteredAccount(); const id = rid(); const now = new Date().toISOString(); await setDocument('messages', id, { id, thread_id, sender_id: exports.uid, kind, body, media_path, created_at: now, createdAt: now, read_at: null }); }
function extFor(file) { return (file.fileName?.split('.').pop() || file.mimeType?.split('/').pop() || 'bin').replace(/[^a-z0-9]/gi, '').slice(0,8) || 'bin'; }
async function imageKitAuth() {
    let response;
    try {
        response = await fetch(IMAGEKIT_AUTH_ENDPOINT, { method: 'GET', headers: { 'Accept': 'application/json' } });
    } catch {
        throw new Error('Impossible de joindre le service sécurisé ImageKit.');
    }
    let data = null;
    try { data = await response.json(); } catch {}
    if (!response.ok || !data?.token || !data?.signature || !data?.expire) {
        throw new Error(data?.error || 'Le service ImageKit n’a pas renvoyé une autorisation valide.');
    }
    return data;
}
async function imageKitUpload(file, folder, progress = () => {}) {
    const auth = await imageKitAuth();
    const nowSec = Math.floor(Date.now() / 1000);
    if (Number(auth.expire) <= nowSec || Number(auth.expire) > nowSec + 3600)
        throw new Error('Autorisation ImageKit expirée ou invalide. Réessaie.');
    progress(12);
    const ext = extFor(file);
    const safeBase = String(file.fileName || ('media-' + Date.now() + '.' + ext))
        .replace(/[^a-zA-Z0-9._-]/g, '_')
        .slice(-120);
    const name = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,8) + '-' + safeBase;
    const form = new FormData();
    form.append('file', { uri: file.uri, name, type: file.mimeType || 'application/octet-stream' });
    form.append('fileName', name);
    form.append('publicKey', String(auth.publicKey || IMAGEKIT_PUBLIC_KEY));
    form.append('token', String(auth.token));
    form.append('signature', String(auth.signature));
    form.append('expire', String(auth.expire));
    form.append('useUniqueFileName', 'true');
    form.append('folder', folder);
    progress(28);
    let response;
    try {
        response = await fetch(IMAGEKIT_UPLOAD_ENDPOINT, { method: 'POST', body: form });
    } catch {
        throw new Error('Connexion interrompue pendant l’envoi vers ImageKit.');
    }
    progress(92);
    let data = null;
    try { data = await response.json(); } catch {}
    if (!response.ok) {
        const message = data?.message || data?.error?.message || data?.error || ('ImageKit HTTP ' + response.status);
        if (/invalid signature/i.test(String(message))) {
            throw new Error('ImageKit refuse l’autorisation d’upload. Recharge puis réessaie.');
        }
        throw new Error(String(message));
    }
    const endpoint = String(auth.urlEndpoint || IMAGEKIT_URL_ENDPOINT).replace(/\/$/, '');
    const url = data?.url || (data?.filePath ? endpoint + '/' + String(data.filePath).replace(/^\//, '') : '');
    if (!url) throw new Error('ImageKit a reçu le fichier mais n’a pas renvoyé son URL.');
    progress(100);
    return url;
}
async function upload(file, progress = () => {}, thread) {
    if ((file.fileSize || 0) > 100 * 1024 * 1024) throw new Error('Ce fichier dépasse 100 Mo. Choisis une version plus légère.');
    if (!/^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime)|audio\/(webm|ogg|mp4|mpeg|wav|m4a|x-m4a))/.test(file.mimeType || '')) throw new Error('Format non pris en charge.');
    if (!exports.uid) throw new Error('Connecte-toi avant d’envoyer un média.');
    if (exports.guest) throw new Error('En mode visiteur, publie avec Lien / Embed, iframe, BBCode ou URL.');
    const folder = thread ? '/the-world-is-your/chat/' + thread + '/' + exports.uid : '/the-world-is-your/media/' + exports.uid;
    return imageKitUpload(file, folder, progress);
}
async function block(id) { const key = exports.uid + '__' + id; const now = new Date().toISOString(); await setDocument('blocks', key, { user_id: exports.uid, blocked_id: id, created_at: now, createdAt: now }, true); }
async function report(post_id, reason) { const id = rid(); const now = new Date().toISOString(); await setDocument('reports', id, { id, user_id: exports.uid, post_id, reason, created_at: now, createdAt: now }); }
async function resolveAsset(ref) { return ref; }

};

__modules["src/components/media"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.m = void 0;
exports.NativeVideo = NativeVideo;
exports.MediaItem = MediaItem;
exports.MediaCarousel = MediaCarousel;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const expo_1 = require("expo");
const expo_video_1 = require("expo-video");
const react_native_webview_1 = require("react-native-webview");
const logic_1 = __load("src/logic");
const ui_1 = __load("src/components/ui");
const context_1 = __load("src/context");
const SCREEN = react_native_1.Dimensions.get('window');
function dataSaverUrl(uri, kind, enabled, full = false) {
    const raw = String(uri || '');
    if (!enabled || !/^https:\/\/ik\.imagekit\.io\/e0fg07buj5\//i.test(raw)) return raw;
    if (/[?&]tr=/.test(raw) || /\/tr:/.test(raw)) return raw;
    const join = raw.includes('?') ? '&' : '?';
    const transform = kind === 'video'
        ? (full ? 'w-720,q-45,f-mp4' : 'w-480,q-35,f-mp4')
        : (full ? 'w-1080,q-60,f-auto' : 'w-640,q-45,f-auto');
    return raw + join + 'tr=' + transform;
}
function NativeVideo({ uri, active, full = false, colors, fit, controls = true, minimal = false, onDoubleTap }) {
    const a = (0, context_1.useApp)();
    const deliveryUri = dataSaverUrl(uri, 'video', !!a.dataSaver, full);
    const player = (0, expo_video_1.useVideoPlayer)(deliveryUri, p => { p.loop = true; p.muted = !full; p.volume = full ? 1 : 0; p.timeUpdateEventInterval = a.dataSaver ? .5 : .15; });
    const [muted, setMuted] = (0, react_1.useState)(!full);
    const lastTap = (0, react_1.useRef)(0);
    const tapTimer = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(() => () => clearTimeout(tapTimer.current), []);
    const [trackW, setTrackW] = (0, react_1.useState)(0);
    const time = (0, expo_1.useEvent)(player, 'timeUpdate', { currentTime: 0, bufferedPosition: 0, currentLiveTimestamp: null, currentOffsetFromLive: null });
    const playing = (0, expo_1.useEvent)(player, 'playingChange', { isPlaying: false });
    const status = (0, expo_1.useEvent)(player, 'statusChange', { status: player.status });
    (0, react_1.useEffect)(() => { player.muted = muted; player.volume = muted ? 0 : 1; }, [muted]);
    (0, react_1.useEffect)(() => { setMuted(!full); }, [full, deliveryUri]);
    (0, react_1.useEffect)(() => { if (active)
        player.play();
    else
        player.pause(); }, [active]);
    const duration = Math.max(0, player.duration || 0), current = Math.max(0, time.currentTime || player.currentTime || 0);
    const ratio = duration ? Math.min(1, current / duration) : 0;
    const seek = (x) => { if (!duration || !trackW)
        return; player.currentTime = Math.max(0, Math.min(duration, (x / trackW) * duration)); };
    const pan = (0, react_1.useMemo)(() => react_native_1.PanResponder.create({ onStartShouldSetPanResponder: () => full, onMoveShouldSetPanResponder: () => full, onPanResponderGrant: e => seek(e.nativeEvent.locationX), onPanResponderMove: e => seek(e.nativeEvent.locationX) }), [duration, trackW, full]);
    if (status.status === 'error') return react_1.default.createElement(MediaFailure, { uri, message: 'Vidéo illisible. Vérifie le lien et le format du fichier.' });
    return react_1.default.createElement(react_native_1.View, { style: react_native_1.StyleSheet.absoluteFill },
        react_1.default.createElement(react_native_1.Pressable, { style: react_native_1.StyleSheet.absoluteFill, pointerEvents: full ? 'auto' : 'none', onPress: () => { if (minimal) {
                const now = Date.now();
                if (now - lastTap.current < 300) { clearTimeout(tapTimer.current); lastTap.current = 0; onDoubleTap?.(); }
                else { lastTap.current = now; tapTimer.current = setTimeout(() => setMuted(v => !v), 300); }
                return;
            } if (full) {
                if (playing.isPlaying ?? player.playing)
                    player.pause();
                else
                    player.play();
            } } },
            react_1.default.createElement(expo_video_1.VideoView, { player: player, style: react_native_1.StyleSheet.absoluteFill, contentFit: fit || (full ? 'contain' : 'cover'), nativeControls: false, surfaceType: "textureView" })),
        controls && !minimal && react_1.default.createElement(ui_1.IconButton, { name: muted ? 'volume-mute' : 'volume-high', label: muted ? 'Activer le son' : 'Couper le son', onPress: () => setMuted(v => !v), color: "#fff", size: 18, style: [exports.m.sound, full && exports.m.soundFull] }),
        full && controls && !minimal && react_1.default.createElement(react_native_1.View, { style: exports.m.progressTouch, onLayout: (e) => setTrackW(e.nativeEvent.layout.width), ...pan.panHandlers },
            react_1.default.createElement(react_native_1.View, { style: exports.m.progressTrack },
                react_1.default.createElement(react_native_1.View, { style: [exports.m.progressFill, { width: `${ratio * 100}%` }] }))));
}
function MediaFailure({ uri, message = 'Média indisponible. Le lien peut avoir expiré ou le site peut refuser la lecture intégrée.' }) {
    return react_1.default.createElement(react_native_1.View, { style: [react_native_1.StyleSheet.absoluteFill, { backgroundColor: '#19191d', alignItems: 'center', justifyContent: 'center', padding: 20, gap: 12 }] },
        react_1.default.createElement(react_native_1.Text, { style: { color: '#fff', textAlign: 'center' } }, message),
        /^https?:/.test(uri || '') && react_1.default.createElement(react_native_1.Pressable, { onPress: () => react_native_1.Linking.openURL(uri).catch(() => {}) },
            react_1.default.createElement(react_native_1.Text, { style: { color: '#d086fa', fontWeight: '700' } }, 'Ouvrir le lien')));
}
function RemoteImage({ media, fit = 'cover', full = false }) {
    const a = (0, context_1.useApp)();
    const deliveryUri = dataSaverUrl(media.url, 'image', !!a.dataSaver, full);
    const [failed, setFailed] = (0, react_1.useState)(false);
    (0, react_1.useEffect)(() => setFailed(false), [deliveryUri]);
    if (failed) return react_1.default.createElement(MediaFailure, { uri: media.url });
    return react_1.default.createElement(react_native_1.Image, { source: logic_1.sourceFor(deliveryUri), resizeMode: fit, style: react_native_1.StyleSheet.absoluteFill, onError: () => setFailed(true) });
}
function EmbedPlayer({ media, active }) {
    const [failed, setFailed] = (0, react_1.useState)('');
    (0, react_1.useEffect)(() => setFailed(''), [media.url, active]);
    if (failed) return react_1.default.createElement(MediaFailure, { uri: media.originalUrl || media.url, message: failed });
    if (!active) return react_1.default.createElement(react_native_1.View, { style: [react_native_1.StyleSheet.absoluteFill, { alignItems: 'center', justifyContent: 'center', backgroundColor: '#19191d' }] },
        media.poster ? react_1.default.createElement(RemoteImage, { media: { url: media.poster } }) : react_1.default.createElement(react_native_1.Text, { style: { color: '#fff' } }, '▶ Média intégré'));
    return react_1.default.createElement(react_native_1.View, { style: react_native_1.StyleSheet.absoluteFill },
        react_1.default.createElement(react_native_webview_1.WebView, {
            source: { uri: media.url }, style: { flex: 1, backgroundColor: '#000' }, containerStyle: { flex: 1 },
            javaScriptEnabled: true, domStorageEnabled: true, allowsInlineMediaPlayback: true,
            allowsFullscreenVideo: true, mediaPlaybackRequiresUserAction: true,
            originWhitelist: ['https://*', 'http://*'], scrollEnabled: false,
            onShouldStartLoadWithRequest: request => /^https?:\/\//i.test(request.url) || request.url === 'about:blank',
            startInLoadingState: true, renderLoading: () => react_1.default.createElement(react_native_1.ActivityIndicator, { style: react_native_1.StyleSheet.absoluteFill, color: '#d086fa' }),
            onError: e => setFailed('Le lecteur ne peut pas charger cette vidéo : ' + (e.nativeEvent.description || 'erreur réseau.')), onHttpError: e => { if (e.nativeEvent.statusCode >= 400 && e.nativeEvent.url === media.url) setFailed('L’hébergeur renvoie une erreur HTTP ' + e.nativeEvent.statusCode + '.'); }
        }));
}
function MediaItem({ media, active, full, colors, fit = 'contain', onDoubleTap }) {
    if (media.type === 'image') return react_1.default.createElement(RemoteImage, { media, fit, full: !!full });
    if (media.type === 'video') return react_1.default.createElement(NativeVideo, { uri: logic_1.uriFor(media.url), active, full, colors, fit: 'cover', minimal: !!full, onDoubleTap });
    return react_1.default.createElement(EmbedPlayer, { media, active });
}

const imageRatios = new Map();
function useImageRatio(media) {
    const uri = media?.type === 'image' ? logic_1.uriFor(media.url) : '';
    const explicit = media?.width > 0 && media?.height > 0 ? media.width / media.height : null;
    const [loaded, setLoaded] = (0, react_1.useState)(null);
    (0, react_1.useEffect)(() => {
        let live = true;
        if (uri && !explicit && !imageRatios.has(uri)) {
            react_native_1.Image.getSize(uri, (w, h) => {
                if (w > 0 && h > 0) {
                    if (imageRatios.size > 300) imageRatios.clear();
                    imageRatios.set(uri, w / h);
                    if (live) setLoaded({ uri, ratio: w / h });
                }
            }, () => {});
        }
        return () => { live = false; };
    }, [uri, explicit]);
    return explicit || imageRatios.get(uri) || (loaded?.uri === uri ? loaded.ratio : null);
}
function MediaCarousel({ media, active, full = false, colors, onDoubleTap, onOpen, fullHeight, onFrameChange }) {
    const [index, setIndex] = (0, react_1.useState)(0);
    const last = (0, react_1.useRef)(0);
    const single = (0, react_1.useRef)(null);
    const screen = react_native_1.useWindowDimensions();
    const [layoutWidth, setLayoutWidth] = (0, react_1.useState)(screen.width);
    const width = layoutWidth;
    const currentMedia = media[index] || media[0];
    const imageRatio = useImageRatio(currentMedia);
    const feedHeight = currentMedia?.type === 'image'
        ? Math.min(screen.height * .74, width / (imageRatio || 1))
        : Math.min(screen.height * .74, width * 1.70);
    const frame = logic_1.fittedImageFrame(width, fullHeight || screen.height, currentMedia?.type === 'image' ? imageRatio : null);
    (0, react_1.useEffect)(() => {
        if (full && onFrameChange) onFrameChange(frame);
    }, [full, onFrameChange, frame.bottom, frame.height]);
    (0, react_1.useEffect)(() => () => { if (single.current)
        clearTimeout(single.current); }, []);
    const tap = () => { const now = Date.now(); if (now - last.current < 300) {
        if (single.current)
            clearTimeout(single.current);
        single.current = null;
        onDoubleTap?.();
        last.current = 0;
    }
    else {
        last.current = now;
        if (onOpen)
            single.current = setTimeout(() => { single.current = null; onOpen(); }, 260);
    } };
    return react_1.default.createElement(react_native_1.View, { onLayout: e => setLayoutWidth(e.nativeEvent.layout.width), style: [exports.m.wrap, full ? { height: '100%', width: '100%' } : { height: feedHeight }] },
        react_1.default.createElement(react_native_1.FlatList, { horizontal: true, pagingEnabled: true, showsHorizontalScrollIndicator: false, data: media, keyExtractor: (_, i) => String(i), onMomentumScrollEnd: e => setIndex(Math.round(e.nativeEvent.contentOffset.x / e.nativeEvent.layoutMeasurement.width)), renderItem: ({ item, index: i }) => react_1.default.createElement(react_native_1.Pressable, { onPress: tap, style: { width, height: '100%' } },
                react_1.default.createElement(MediaItem, { media: item, active: active && i === index, full: full, onDoubleTap, colors: colors })) }),
        media.length > 1 && react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(react_native_1.View, { style: [exports.m.counter, full && { top: 80 }] },
                react_1.default.createElement(react_native_1.Text, { style: exports.m.counterText },
                    index + 1,
                    "/",
                    media.length)),
            react_1.default.createElement(react_native_1.View, { style: [exports.m.dots, full && { bottom: 185 }] }, media.map((_, i) => react_1.default.createElement(react_native_1.View, { key: i, style: [exports.m.dot, i === index && exports.m.dotOn] })))));
}
exports.m = react_native_1.StyleSheet.create({
    wrap: { width: '100%', backgroundColor: '#141418', position: 'relative' }, full: { height: '100%', width: SCREEN.width, backgroundColor: '#000' },
    counter: { position: 'absolute', right: 12, top: 12, backgroundColor: '#0008', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6 }, counterText: { color: '#fff', fontSize: 11 },
    dots: { position: 'absolute', left: 0, right: 0, bottom: 14, flexDirection: 'row', justifyContent: 'center', gap: 5 }, dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#ffffff66' }, dotOn: { width: 16, backgroundColor: '#fff' },
    sound: { position: 'absolute', right: 12, bottom: 13, backgroundColor: '#0008', width: 34, height: 34 }, soundFull: { right: 18, bottom: 235 },
    progressTouch: { position: 'absolute', left: 0, right: 0, bottom: 0, height: 25, justifyContent: 'flex-end' }, progressTrack: { height: 3, backgroundColor: '#ffffff55' }, progressFill: { height: 3, backgroundColor: '#fff' }
});

};

__modules["src/components/overlays"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.FullViewer = FullViewer;
exports.CommentsModal = CommentsModal;
exports.MediaLightbox = MediaLightbox;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const api = __importStar(__load("src/api"));
const logic_1 = __load("src/logic");
const context_1 = __load("src/context");
const ui_1 = __load("src/components/ui");
const media_1 = __load("src/components/media");
const post_1 = __load("src/components/post");
const INITIAL_VIEWER_H = react_native_1.Dimensions.get('window').height;
function FullViewer({ visible, posts, start, colors, onClose, paused = false }) {
    const a = (0, context_1.useApp)();
    const ref = (0, react_1.useRef)(null);
    const [index, setIndex] = (0, react_1.useState)(Math.max(0, start));
    const [pageH, setPageH] = (0, react_1.useState)(INITIAL_VIEWER_H);
    const clampIndex = (i) => Math.min(Math.max(0, i), Math.max(posts.length - 1, 0));
    const scrollTo = (i, animated = false) => {
        const n = clampIndex(i);
        ref.current?.scrollToOffset({ offset: n * Math.max(1, pageH), animated });
    };
    (0, react_1.useEffect)(() => {
        if (!visible) return;
        const i = clampIndex(start);
        setIndex(i);
        const t = setTimeout(() => scrollTo(i, false), 80);
        return () => clearTimeout(t);
    }, [visible, start, posts.length]);
    (0, react_1.useEffect)(() => {
        if (!visible) return;
        const t = setTimeout(() => scrollTo(index, false), 30);
        return () => clearTimeout(t);
    }, [pageH]);
    const go = (delta) => {
        const n = clampIndex(index + delta);
        if (n !== index) scrollTo(n, true);
    };
    if (!visible) return null;

    return react_1.default.createElement(
        react_native_1.View,
        { testID: 'fullscreen-post-screen', style: { flex: 1, backgroundColor: '#000' } },
        react_1.default.createElement(
            react_native_1.View,
            {
                style: v.root,
                onLayout: e => {
                    const h = Math.round(e.nativeEvent.layout.height);
                    if (h > 0 && Math.abs(h - pageH) > 1) setPageH(h);
                }
            },
            react_1.default.createElement(react_native_1.FlatList, {
                ref,
                data: posts,
                keyExtractor: x => x.id,
                pagingEnabled: true,
                snapToInterval: pageH,
                snapToAlignment: "start",
                decelerationRate: "fast",
                disableIntervalMomentum: true,
                showsVerticalScrollIndicator: false,
                getItemLayout: (_, i) => ({ length: pageH, offset: pageH * i, index: i }),
                onMomentumScrollEnd: e => {
                    const next = clampIndex(Math.round(e.nativeEvent.contentOffset.y / Math.max(1, pageH)));
                    setIndex(next);
                    const exact = next * pageH;
                    if (Math.abs(e.nativeEvent.contentOffset.y - exact) > 1)
                        ref.current?.scrollToOffset({ offset: exact, animated: false });
                },
                renderItem: ({ item: p, index: i }) =>
                    react_1.default.createElement(ViewerPage, {
                        post: p,
                        active: visible && i === index && !paused,
                        colors,
                        pageH,
                        onPrev: () => go(-1),
                        onNext: () => go(1),
                        canPrev: i > 0,
                        canNext: i < posts.length - 1
                    })
            }),
            react_1.default.createElement(
                react_native_1.View,
                { pointerEvents: "box-none", style: v.reelsHeader },
                react_1.default.createElement(ui_1.IconButton, {
                    name: 'chevron-back',
                    label: 'Retour',
                    onPress: onClose,
                    color: '#fff',
                    size: 27,
                    style: { backgroundColor: '#0002' }
                }),
                react_1.default.createElement(
                    react_native_1.View,
                    { style: v.reelsTitleWrap },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: v.reelsTitle },
                        "Reels"
                    ),
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: v.reelsFriends },
                        "Ami(e)s"
                    )
                ),
                react_1.default.createElement(ui_1.IconButton, {
                    name: 'camera-outline',
                    label: 'Créer',
                    onPress: () => {
                        onClose();
                        setTimeout(() => a.push({ name: 'create' }), 0);
                    },
                    color: '#fff',
                    size: 25
                })
            )
        )
    );
}
function ViewerActions({ post, colors, active }) {
    const a = (0, context_1.useApp)();
    const [updatedPost, setUpdatedPost] = (0, react_1.useState)(null);
    const livePost = a.posts.find(x => x.id === post.id) || (updatedPost?.id === post.id ? updatedPost : post);
    const sourceId = post.media?.[0]?.repost?.source_post_id || post.id;
    const [repost, setRepostState] = (0, react_1.useState)({ count: null, mine: null });
    const [error, setError] = (0, react_1.useState)('');
    const [busy, setBusy] = (0, react_1.useState)(false);
    const busyRef = (0, react_1.useRef)(false);
    const liked = livePost.likes.some(x => x.user_id === api.uid);
    const saved = livePost.saves.some(x => x.user_id === api.uid);

    (0, react_1.useEffect)(() => {
        let live = true;
        if (active) api.repostState(sourceId).then(state => {
            if (live) setRepostState(state);
        }).catch(() => {});
        return () => { live = false; };
    }, [sourceId, active, a.posts]);

    const act = async fn => {
        if (busyRef.current) return;
        busyRef.current = true;
        setBusy(true);
        setError('');
        try {
            await fn();
        } catch (e) {
            setError(e.message || 'Action impossible. Réessaie.');
        } finally {
            busyRef.current = false;
            setBusy(false);
        }
    };

    const toggleLike = () => act(async () => {
        await api.toggle('likes', livePost);
        const likes = liked
            ? livePost.likes.filter(x => x.user_id !== api.uid)
            : [...livePost.likes.filter(x => x.user_id !== api.uid), { user_id: api.uid }];
        const next = { ...livePost, likes };
        setUpdatedPost(next);
        a.setPosts(items => items.some(x => x.id === livePost.id)
            ? items.map(x => x.id === livePost.id ? next : x)
            : [...items, next]);
    });

    const toggleSave = () => act(async () => {
        await api.toggle('saves', livePost);
        const saves = saved
            ? livePost.saves.filter(x => x.user_id !== api.uid)
            : [...livePost.saves.filter(x => x.user_id !== api.uid), { user_id: api.uid }];
        const next = { ...livePost, saves };
        setUpdatedPost(next);
        a.setPosts(items => items.some(x => x.id === livePost.id)
            ? items.map(x => x.id === livePost.id ? next : x)
            : [...items, next]);
    });

    const toggleRepost = () => act(async () => {
        const result = await api.setRepost(livePost, !repost.mine);
        if (result.created) a.registerPost(result.created);
        if (result.removedId) a.setPosts(items => items.filter(x => x.id !== result.removedId));
        setRepostState({ count: result.count, mine: result.created });
    });

    const sharePost = () => react_native_1.Share.share({
        message: '@' + (livePost.owner?.username || 'compte') + (livePost.caption ? '\n' + livePost.caption : '')
    }).catch(() => {});

    const button = (icon, label, count, onPress, color = '#fff') =>
        react_1.default.createElement(
            react_native_1.Pressable,
            {
                key: label,
                accessibilityRole: 'button',
                accessibilityLabel: label,
                disabled: busy,
                onPress,
                style: {
                    width: 44,
                    minHeight: 48,
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: 2,
                    opacity: busy ? .6 : 1
                }
            },
            react_1.default.createElement(require('@expo/vector-icons').Ionicons, {
                name: icon,
                size: 28,
                color
            }),
            count !== null && react_1.default.createElement(
                react_native_1.Text,
                {
                    style: {
                        color: '#fff',
                        fontSize: 10.5,
                        fontWeight: '700',
                        textShadowColor: '#0009',
                        textShadowRadius: 3
                    }
                },
                String(count)
            )
        );

    return react_1.default.createElement(
        react_native_1.View,
        { style: { gap: 8, alignItems: 'center' } },
        button(liked ? 'heart' : 'heart-outline', 'J’aime', livePost.likes.length, toggleLike, liked ? '#ff3040' : '#fff'),
        button('chatbubble-outline', 'Commentaires', livePost.comments.length, () => a.comments(livePost)),
        button('paper-plane-outline', 'Partager', null, sharePost),
        button('repeat-outline', repost.mine ? 'Annuler la republication' : 'Republier', repost.count, toggleRepost, repost.mine ? '#50e8a1' : '#fff'),
        button(saved ? 'bookmark' : 'bookmark-outline', 'Enregistrer', null, toggleSave),
        !!error && react_1.default.createElement(
            react_native_1.Pressable,
            {
                onPress: () => setError(''),
                style: {
                    position: 'absolute',
                    right: 0,
                    bottom: -62,
                    width: 220,
                    backgroundColor: '#222e',
                    borderRadius: 10,
                    padding: 10
                }
            },
            react_1.default.createElement(react_native_1.Text, { style: { color: '#fff', fontSize: 11.5 } }, error)
        )
    );
}
function ViewerPage({ post: initialPost, active, colors, pageH, onPrev, onNext, canPrev, canNext }) {
    const [imageFrame, setImageFrame] = (0, react_1.useState)({ bottom: 0, height: pageH });
    const a = (0, context_1.useApp)();
    const post = a.posts.find(x => x.id === initialPost.id) || initialPost;
    const liked = post.likes.some(x => x.user_id === api.uid);
    const edge = (0, react_1.useMemo)(() => react_native_1.PanResponder.create({
        onMoveShouldSetPanResponder: (_, g) =>
            Math.abs(g.dy) > 18 && Math.abs(g.dy) > Math.abs(g.dx) * 1.3,
        onPanResponderRelease: (_, g) => {
            if (g.dy < -42) onNext();
            if (g.dy > 42) onPrev();
        }
    }), [onPrev, onNext]);

    return react_1.default.createElement(
        react_native_1.View,
        { style: [v.page, { height: pageH }] },
        react_1.default.createElement(media_1.MediaCarousel, {
            media: post.media,
            active,
            full: true,
            fullHeight: pageH,
            onFrameChange: setImageFrame,
            colors,
            onDoubleTap: () => {
                if (!liked) {
                    a.run(async () => {
                        await api.toggle('likes', post);
                        await a.refresh();
                    });
                }
            }
        }),
        react_1.default.createElement(react_native_1.View, {
            style: v.edgeSwipe,
            ...edge.panHandlers
        }),
        react_1.default.createElement(require('expo-linear-gradient').LinearGradient, {
            pointerEvents: 'none',
            colors: ['transparent', '#000a'],
            style: {
                position: 'absolute',
                bottom: imageFrame.bottom,
                left: 0,
                right: 0,
                height: Math.min(250, imageFrame.height)
            }
        }),

        react_1.default.createElement(
            react_native_1.View,
            {
                pointerEvents: 'box-none',
                style: [v.bottom, { bottom: Math.max(60, imageFrame.bottom + 54) }]
            },
            react_1.default.createElement(
                react_native_1.View,
                { style: v.identity },
                react_1.default.createElement(ui_1.Avatar, {
                    person: post.owner,
                    size: 32,
                    ring: false,
                    colors: { ...colors, bg: '#000' },
                    onPress: () => a.push({ name: 'profile', person: post.owner })
                }),
                react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        style: v.identityCopy,
                        onPress: () => a.push({ name: 'profile', person: post.owner })
                    },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { numberOfLines: 1, style: v.username },
                        post.owner.username
                    )
                ),
                post.user_id !== api.uid && react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        style: v.follow,
                        onPress: () => a.run(async () => {
                            await api.follow(post.user_id);
                            await a.refresh();
                        })
                    },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: v.followText },
                        a.followed.includes(post.user_id) ? 'Suivi(e)' : 'Suivre'
                    )
                )
            ),
            !!post.caption && react_1.default.createElement(
                react_native_1.View,
                { style: [v.caption, { maxHeight: 56, overflow: 'hidden' }] },
                react_1.default.createElement(post_1.CaptionText, {
                    text: post.caption,
                    colors: { ...colors, text: '#fff' }
                })
            )
        ),

        react_1.default.createElement(
            react_native_1.View,
            { style: [v.rail, { bottom: 74, right: 5 }] },
            react_1.default.createElement(ViewerActions, { post, colors, active })
        ),

    );
}
function CommentsModal({ post, colors, onClose }) { const a = (0, context_1.useApp)(); const [items, setItems] = (0, react_1.useState)([]); const [text, setText] = (0, react_1.useState)(''); const [busy, setBusy] = (0, react_1.useState)(false); (0, react_1.useEffect)(() => { if (post)
    api.getComments(post.id).then(setItems).catch(e => a.notify(e.message));
else {
    setItems([]);
    setText('');
} }, [post?.id]); const send = async () => { if (!post || !text.trim() || busy)
    return; setBusy(true); await a.run(async () => { await api.comment(post.id, text.trim()); setText(''); setItems(await api.getComments(post.id)); await a.refresh(); }); setBusy(false); }; return react_1.default.createElement(react_native_1.Modal, { visible: !!post, transparent: true, animationType: "slide", onRequestClose: onClose },
    react_1.default.createElement(react_native_1.KeyboardAvoidingView, { style: o.shade, behavior: react_native_1.Platform.OS === 'ios' ? 'padding' : undefined },
        react_1.default.createElement(react_native_1.Pressable, { style: react_native_1.StyleSheet.absoluteFill, onPress: onClose }),
        react_1.default.createElement(react_native_1.View, { style: [o.sheet, { backgroundColor: colors.bg }] },
            react_1.default.createElement(react_native_1.View, { style: [o.grab, { backgroundColor: colors.line }] }),
            react_1.default.createElement(react_native_1.View, { style: o.sheetHead },
                react_1.default.createElement(react_native_1.Text, { style: [o.sheetTitle, { color: colors.text }] }, "Commentaires"),
                react_1.default.createElement(ui_1.IconButton, { name: "close", label: "Fermer", onPress: onClose, color: colors.text })),
            react_1.default.createElement(react_native_1.FlatList, { data: items, keyExtractor: x => x.id, style: { flex: 1 }, ListEmptyComponent: react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, textAlign: 'center', padding: 30 } }, "Sois le premier \u00E0 commenter."), renderItem: ({ item: c }) => react_1.default.createElement(react_native_1.View, { style: o.comment },
                    react_1.default.createElement(ui_1.Avatar, { person: c.owner, colors: colors }),
                    react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 12, lineHeight: 18 } },
                            react_1.default.createElement(react_native_1.Text, { style: { fontWeight: '800' } },
                                c.owner.username,
                                " "),
                            c.body),
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 10, marginTop: 4 } }, (0, logic_1.formatWhen)(c.created_at)))) }),
            react_1.default.createElement(react_native_1.View, { style: [o.compose, { borderTopColor: colors.line }] },
                react_1.default.createElement(ui_1.Avatar, { person: a.me, size: 32, colors: colors }),
                react_1.default.createElement(react_native_1.TextInput, { value: text, onChangeText: setText, placeholder: "Ajouter un commentaire\u2026", placeholderTextColor: colors.muted, multiline: true, maxLength: 1000, style: [o.input, { backgroundColor: colors.panel, color: colors.text }] }),
                react_1.default.createElement(react_native_1.Pressable, { disabled: !text.trim() || busy, onPress: send, style: { opacity: (!text.trim() || busy) ? .4 : 1 } },
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.accent, fontWeight: '800' } }, "Publier")))))); }
function MediaLightbox({ open, colors, onClose }) {
    const [paused, setPaused] = (0, react_1.useState)(false);
    const translateY = (0, react_1.useRef)(new react_native_1.Animated.Value(0)).current;
    const closing = (0, react_1.useRef)(false);
    const closeRef = (0, react_1.useRef)(onClose); closeRef.current = onClose;
    (0, react_1.useEffect)(() => { translateY.stopAnimation(); translateY.setValue(0); closing.current = false; setPaused(false); }, [open?.url, open?.kind]);
    const pan = (0, react_1.useMemo)(() => {
        const reset = () => react_native_1.Animated.spring(translateY, { toValue: 0, useNativeDriver: true, speed: 24, bounciness: 4 }).start();
        return react_native_1.PanResponder.create({
            onStartShouldSetPanResponder: () => false,
            onMoveShouldSetPanResponder: (_, g) => logic_1.isUpSwipe(g),
            onMoveShouldSetPanResponderCapture: (_, g) => logic_1.isUpSwipe(g),
            onPanResponderTerminationRequest: () => false,
            onShouldBlockNativeResponder: () => true,
            onPanResponderMove: (_, g) => { if (!closing.current) translateY.setValue(Math.min(0, g.dy)); },
            onPanResponderRelease: (_, g) => {
                if (closing.current) return;
                if (logic_1.shouldDismissMedia(g)) {
                    closing.current = true;
                    react_native_1.Animated.timing(translateY, { toValue: -react_native_1.Dimensions.get('screen').height, duration: 160, useNativeDriver: true }).start(({ finished }) => { if (finished) closeRef.current(); });
                } else reset();
            },
            onPanResponderTerminate: reset
        });
    }, [translateY]);
    return react_1.default.createElement(react_native_1.Modal, { visible: !!open, animationType: 'fade', statusBarTranslucent: true, navigationBarTranslucent: true, onRequestClose: onClose },
        react_1.default.createElement(react_native_1.View, { style: o.lightbox, ...pan.panHandlers },
            react_1.default.createElement(react_native_1.Animated.View, { style: [react_native_1.StyleSheet.absoluteFill, { transform: [{ translateY }] }] },
                open?.kind === 'video'
                    ? react_1.default.createElement(media_1.NativeVideo, { key: open.url, uri: logic_1.uriFor(open.url), active: !paused, full: true, fit: 'contain', colors })
                    : open ? react_1.default.createElement(media_1.MediaItem, { media: { type: 'image', url: open.url }, active: true, full: true, colors: colors, fit: 'contain' }) : null,
                react_1.default.createElement(react_native_1.Pressable, { onPress: () => setPaused(v => !v), accessibilityLabel: 'Lecture ou pause ; glisser vers le haut pour fermer', collapsable: false, style: { position: 'absolute', top: 70, left: 0, right: 64, bottom: 42 }, ...pan.panHandlers })),
            react_1.default.createElement(ui_1.IconButton, { name: 'close', label: 'Fermer le média', onPress: onClose, color: '#fff', style: { position: 'absolute', top: 28, left: 12, backgroundColor: '#0008' } })));
}

const v = react_native_1.StyleSheet.create({
    root: { flex: 1, backgroundColor: '#000' },
    page: { backgroundColor: '#000', overflow: 'hidden' },
    reelsHeader: {
        position: 'absolute',
        left: 2,
        right: 2,
        top: 2,
        minHeight: 46,
        flexDirection: 'row',
        alignItems: 'center',
        zIndex: 40
    },
    reelsTitleWrap: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingLeft: 2
    },
    reelsTitle: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '800',
        textShadowColor: '#0009',
        textShadowRadius: 3
    },
    reelsFriends: {
        color: '#ffffffdd',
        fontSize: 13,
        fontWeight: '700',
        textShadowColor: '#0009',
        textShadowRadius: 3
    },
    header: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        height: 52,
        paddingHorizontal: 6,
        flexDirection: 'row',
        alignItems: 'center',
        zIndex: 30,
        backgroundColor: 'transparent'
    },
    headerTitle: { color: '#fff', fontSize: 15, fontWeight: '800', flex: 1 },
    count: { color: '#ffffffaa', fontSize: 11, marginRight: 12 },
    edgeSwipe: { position: 'absolute', right: 0, top: 70, bottom: 70, width: 22, zIndex: 5 },
    bottom: {
        position: 'absolute',
        left: 12,
        right: 61,
        zIndex: 12,
        paddingTop: 6
    },
    identity: { flexDirection: 'row', alignItems: 'center', gap: 7 },
    identityCopy: { flexShrink: 1, maxWidth: 132, justifyContent: 'center' },
    username: {
        color: '#fff',
        fontSize: 12.5,
        fontWeight: '800',
        textShadowColor: '#0009',
        textShadowRadius: 3
    },
    handle: { color: '#ddd', fontSize: 10, marginTop: 2 },
    follow: { borderWidth: 0, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 5 },
    followText: {
        color: '#fff',
        fontSize: 10,
        fontWeight: '800',
        textShadowColor: '#0009',
        textShadowRadius: 3
    },
    caption: {
        color: '#fff',
        fontSize: 11.5,
        lineHeight: 17,
        marginTop: 7,
        textShadowColor: '#000',
        textShadowRadius: 3
    },
    when: { color: '#ddd', fontSize: 10, marginTop: 5 },
    rail: { position: 'absolute', right: 5, bottom: 74, zIndex: 15 },
    quickComment: {
        position: 'absolute',
        left: 12,
        right: 58,
        bottom: 8,
        height: 42,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
        zIndex: 18
    },
    quickCommentInput: {
        flex: 1,
        height: 38,
        borderRadius: 20,
        backgroundColor: '#32363dcc',
        justifyContent: 'center',
        paddingHorizontal: 13
    },
    quickCommentText: { color: '#d8dbe0', fontSize: 11.5 },
    arrows: { position: 'absolute', right: 10, top: '39%', gap: 8, zIndex: 18 },
    arrow: { width: 34, height: 34, backgroundColor: '#0005' }
});
const o = react_native_1.StyleSheet.create({ shade: { flex: 1, backgroundColor: '#0008', justifyContent: 'flex-end' }, sheet: { height: '70%', borderTopLeftRadius: 24, borderTopRightRadius: 24, paddingHorizontal: 18, paddingTop: 8, paddingBottom: 10 }, grab: { width: 38, height: 4, borderRadius: 2, alignSelf: 'center', marginVertical: 4 }, sheetHead: { height: 48, flexDirection: 'row', alignItems: 'center' }, sheetTitle: { fontSize: 18, fontWeight: '800', flex: 1 }, comment: { flexDirection: 'row', gap: 10, paddingVertical: 11 }, compose: { minHeight: 62, borderTopWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 8, paddingTop: 8 }, input: { flex: 1, minHeight: 42, maxHeight: 90, borderRadius: 20, paddingHorizontal: 13, paddingVertical: 10 }, lightbox: { flex: 1, backgroundColor: '#000' }, lightHeader: { position: 'absolute', zIndex: 10, top: 8, left: 5 } });

};

__modules["src/components/post"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.p = void 0;
exports.CaptionText = CaptionText;
exports.PostActions = PostActions;
exports.PostMenu = PostMenu;
exports.PostCard = PostCard;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const safe_area_1 = require("react-native-safe-area-context");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const expo_linear_gradient_1 = require("expo-linear-gradient");
const api = __importStar(__load("src/api"));
const logic_1 = __load("src/logic");
const context_1 = __load("src/context");
const ui_1 = __load("src/components/ui");
const media_1 = __load("src/components/media");
function CaptionText({ text, colors }) { const a = (0, context_1.useApp)(); return react_1.default.createElement(react_native_1.Text, { style: { color: colors.text } }, text.split(/(#[\p{L}\p{N}_]+)/gu).map((part, i) => part.startsWith('#') ? react_1.default.createElement(react_native_1.Text, { key: i, onPress: () => a.push({ name: 'explore', query: part }), style: { color: colors.accent } }, part) : part)); }
function PostActions({ post, compact = false, colors }) {
    const a = (0, context_1.useApp)();
    const liked = post.likes.some(l => l.user_id === api.uid);
    const saved = post.saves.some(l => l.user_id === api.uid);

    const Action = ({ name, label, onPress, count, active, pushRight = false }) =>
        react_1.default.createElement(
            react_native_1.Pressable,
            {
                accessibilityLabel: label,
                onPress: onPress,
                style: [
                    exports.p.action,
                    compact && exports.p.actionVertical,
                    pushRight && !compact && exports.p.actionPushRight
                ]
            },
            react_1.default.createElement(
                Ionicons_1.default,
                {
                    name: name,
                    size: compact ? 28 : 29,
                    color: active ? '#ff3040' : compact ? '#fff' : colors.text
                }
            ),
            typeof count === 'number' && react_1.default.createElement(
                react_native_1.Text,
                {
                    style: compact
                        ? exports.p.actionCount
                        : [exports.p.actionCountInline, { color: colors.text }]
                },
                count
            )
        );

    return react_1.default.createElement(
        react_native_1.View,
        { style: [exports.p.actions, compact && exports.p.actionsVertical] },
        react_1.default.createElement(Action, {
            name: liked ? 'heart' : 'heart-outline',
            active: liked,
            label: "J’aime",
            count: post.likes.length,
            onPress: () => a.run(async () => {
                await api.toggle('likes', post);
                await a.refresh();
            })
        }),
        react_1.default.createElement(Action, {
            name: "chatbubble-outline",
            label: "Commentaires",
            count: post.comments.length,
            onPress: () => a.comments(post)
        }),
        react_1.default.createElement(Action, {
            name: "paper-plane-outline",
            label: "Partager",
            onPress: () => a.run(async () => {
                const link = typeof post.media[0]?.url === 'string' ? post.media[0].url : '';
                await react_native_1.Share.share({
                    title: 'Kitty of the World',
                    message: link && (0, logic_1.safeUrl)(link)
                        ? `${post.caption}\n${link}`
                        : post.caption
                });
            })
        }),
        react_1.default.createElement(Action, {
            name: saved ? 'bookmark' : 'bookmark-outline',
            label: "Enregistrer",
            active: false,
            pushRight: true,
            onPress: () => a.run(async () => {
                await api.toggle('saves', post);
                await a.refresh();
            })
        })
    );
}
function PostMenu({ post, colors }) {
    const a = (0, context_1.useApp)();
    const [open, setOpen] = (0, react_1.useState)(false);

    const confirmDelete = () => {
        react_native_1.Alert.alert(
            'Supprimer la publication',
            'Cette publication sera supprimée définitivement.',
            [
                { text: 'Annuler', style: 'cancel' },
                {
                    text: 'Supprimer',
                    style: 'destructive',
                    onPress: () => a.run(async () => {
                        await api.removePost(post.id);
                        if (a.setPosts)
                            a.setPosts(v => v.filter(x => x.id !== post.id));
                        await a.refresh();
                        a.notify('Publication supprimée.');
                    })
                }
            ]
        );
    };

    if (post.user_id === api.uid) {
        return react_1.default.createElement(ui_1.IconButton, {
            name: "ellipsis-horizontal",
            label: "Supprimer la publication",
            onPress: confirmDelete,
            color: colors.text
        });
    }

    if (!open)
        return react_1.default.createElement(ui_1.IconButton, {
            name: "ellipsis-horizontal",
            label: "Options",
            onPress: () => setOpen(true),
            color: colors.text
        });

    return react_1.default.createElement(
        react_native_1.View,
        { style: exports.p.menu },
        react_1.default.createElement(react_native_1.Pressable, {
            onPress: () => setOpen(false),
            style: react_native_1.StyleSheet.absoluteFill
        }),
        react_1.default.createElement(
            react_native_1.View,
            { style: [exports.p.menuPop, { backgroundColor: colors.bg, borderColor: colors.line }] },
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    style: exports.p.menuRow,
                    onPress: () => {
                        setOpen(false);
                        a.run(async () => {
                            await api.report(post.id, 'Signalement depuis l’application');
                            a.notify('Signalement envoyé.');
                        });
                    }
                },
                react_1.default.createElement(Ionicons_1.default, { name: "flag-outline", size: 18, color: colors.text }),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text } }, "Signaler")
            ),
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    style: exports.p.menuRow,
                    onPress: () => {
                        setOpen(false);
                        a.run(async () => {
                            await api.block(post.user_id);
                            await a.refresh();
                        });
                    }
                },
                react_1.default.createElement(Ionicons_1.default, { name: "person-remove-outline", size: 18, color: colors.text }),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text } }, "Bloquer ce compte")
            )
        )
    );
}
function PostCard({ post, active, onOpen, colors }) {
    const a = (0, context_1.useApp)();

    return react_1.default.createElement(
        react_native_1.View,
        { style: exports.p.card },

        react_1.default.createElement(
            react_native_1.View,
            { style: exports.p.mediaShell },

            react_1.default.createElement(media_1.MediaCarousel, {
                media: post.media,
                active: active,
                colors: colors,
                onOpen: onOpen,
                onDoubleTap: () => {
                    if (!post.likes.some(l => l.user_id === api.uid)) {
                        a.run(async () => {
                            await api.toggle('likes', post);
                            await a.refresh();
                        });
                    }
                }
            }),

            react_1.default.createElement(
                expo_linear_gradient_1.LinearGradient,
                {
                    pointerEvents: "none",
                    colors: ['rgba(0,0,0,.56)', 'rgba(0,0,0,.20)', 'rgba(0,0,0,0)'],
                    locations: [0, .55, 1],
                    style: exports.p.overlayGradient
                }
            ),

            react_1.default.createElement(
                react_native_1.View,
                { style: exports.p.headingOverlay },

                react_1.default.createElement(ui_1.Avatar, {
                    person: post.owner,
                    size: 42,
                    ring: true,
                    colors: { ...colors, bg: '#000', panel: '#29292d' },
                    onPress: () => a.push({ name: 'profile', person: post.owner })
                }),

                react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        style: exports.p.identityOverlay,
                        onPress: () => a.push({ name: 'profile', person: post.owner })
                    },
                    react_1.default.createElement(
                        react_native_1.Text,
                        {
                            numberOfLines: 1,
                            style: exports.p.overlayUsername
                        },
                        post.owner.username
                    ),
                    react_1.default.createElement(
                        react_native_1.Text,
                        {
                            numberOfLines: 1,
                            style: exports.p.overlayMeta
                        },
                        (0, logic_1.formatWhen)(post.created_at)
                    )
                ),

                post.user_id !== api.uid &&
                react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        style: exports.p.followOverlay,
                        onPress: () => a.run(async () => {
                            await api.follow(post.user_id);
                            await a.refresh();
                        })
                    },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: exports.p.followOverlayText },
                        a.followed.includes(post.user_id) ? 'Suivi(e)' : 'Suivre'
                    )
                ),

                react_1.default.createElement(PostMenu, {
                    post: post,
                    colors: { ...colors, text: '#fff', bg: '#111', line: '#333' }
                })
            )
        ),

        react_1.default.createElement(PostActions, {
            post: post,
            colors: colors
        }),

        (!!post.caption || post.comments.length > 0) &&
        react_1.default.createElement(
            react_native_1.View,
            { style: exports.p.copy },

            !!post.caption &&
            react_1.default.createElement(
                react_native_1.Text,
                {
                    numberOfLines: 2,
                    style: [exports.p.caption, { color: colors.text }]
                },
                react_1.default.createElement(
                    react_native_1.Text,
                    { style: { fontWeight: '800' } },
                    post.owner.username,
                    " "
                ),
                react_1.default.createElement(CaptionText, {
                    text: post.caption,
                    colors: colors
                })
            ),

            post.comments.length > 0 &&
            react_1.default.createElement(
                react_native_1.Pressable,
                { onPress: () => a.comments(post) },
                react_1.default.createElement(
                    react_native_1.Text,
                    {
                        style: {
                            color: colors.muted,
                            fontSize: 12
                        }
                    },
                    `Voir les ${post.comments.length} commentaires`
                )
            )
        )
    );
}
exports.p = react_native_1.StyleSheet.create({
    card: {
        paddingBottom: 2
    },
    mediaShell: {
        position: 'relative',
        backgroundColor: '#000'
    },
    heading: {
        height: 64,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingHorizontal: 15
    },
    headingOverlay: {
        position: 'absolute',
        left: 14,
        right: 10,
        top: 12,
        minHeight: 54,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        zIndex: 10
    },
    overlayGradient: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        height: 118,
        zIndex: 5
    },
    identityOverlay: {
        flex: 1,
        minWidth: 0,
        justifyContent: 'center'
    },
    overlayUsername: {
        color: '#fff',
        fontSize: 14,
        lineHeight: 18,
        fontWeight: '800',
        textShadowColor: '#0009',
        textShadowOffset: { width: 0, height: 1 },
        textShadowRadius: 2
    },
    overlayMeta: {
        color: '#f1f1f1',
        fontSize: 11,
        lineHeight: 15,
        marginTop: 1,
        textShadowColor: '#0009',
        textShadowOffset: { width: 0, height: 1 },
        textShadowRadius: 2
    },
    followOverlay: {
        paddingHorizontal: 8,
        minHeight: 34,
        justifyContent: 'center',
        alignItems: 'center'
    },
    followOverlayText: {
        color: '#fff',
        fontSize: 13,
        fontWeight: '800',
        textShadowColor: '#0009',
        textShadowOffset: { width: 0, height: 1 },
        textShadowRadius: 2
    },
    user: {
        fontSize: 14,
        fontWeight: '800'
    },
    handle: {
        fontSize: 11,
        marginTop: 2
    },
    when: {
        fontSize: 10,
        marginTop: 3
    },
    actions: {
        minHeight: 58,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 14,
        gap: 16
    },
    actionsVertical: {
        height: 'auto',
        minHeight: 0,
        flexDirection: 'column',
        paddingHorizontal: 0,
        gap: 14
    },
    action: {
        minWidth: 34,
        height: 48,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6
    },
    actionPushRight: {
        marginLeft: 'auto'
    },
    actionVertical: {
        height: 47,
        flexDirection: 'column',
        gap: 2
    },
    actionCount: {
        color: '#fff',
        fontSize: 10,
        marginTop: 2,
        fontWeight: '700'
    },
    actionCountInline: {
        fontSize: 12,
        fontWeight: '700'
    },
    copy: {
        paddingHorizontal: 15,
        paddingBottom: 10,
        gap: 5
    },
    likes: {
        fontSize: 12,
        fontWeight: '800'
    },
    caption: {
        fontSize: 12,
        lineHeight: 18
    },
    menu: {
        position: 'relative',
        zIndex: 50
    },
    menuPop: {
        position: 'absolute',
        right: 0,
        top: 42,
        width: 205,
        borderWidth: 1,
        borderRadius: 15,
        padding: 6,
        zIndex: 60,
        shadowColor: '#000',
        shadowOpacity: .2,
        shadowRadius: 20,
        elevation: 10
    },
    menuRow: {
        flexDirection: 'row',
        gap: 12,
        alignItems: 'center',
        padding: 13
    }
});

};

__modules["src/components/ui"] = function(module,exports,require){
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.s = void 0;
exports.IconButton = IconButton;
exports.RainbowMark = RainbowMark;
exports.Avatar = Avatar;
exports.Header = Header;
exports.Empty = Empty;
exports.PrimaryButton = PrimaryButton;
exports.SecondaryButton = SecondaryButton;
exports.TabChip = TabChip;
const react_1 = __importDefault(require("react"));
const react_native_1 = require("react-native");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const expo_linear_gradient_1 = require("expo-linear-gradient");
const theme_1 = __load("src/theme");
const logic_1 = __load("src/logic");
function IconButton({ name, label, onPress, color, size = 23, disabled = false, style }) {
    return react_1.default.createElement(react_native_1.Pressable, { accessibilityLabel: label, disabled: disabled, onPress: onPress, style: ({ pressed }) => [exports.s.iconButton, style, pressed && { opacity: .6 }, disabled && { opacity: .35 }] },
        react_1.default.createElement(Ionicons_1.default, { name: name, size: size, color: color }));
}
function RainbowMark({ size = 34 }) { return react_1.default.createElement(expo_linear_gradient_1.LinearGradient, { colors: theme_1.RAINBOW, start: { x: 0, y: 0 }, end: { x: 1, y: 1 }, style: [exports.s.mark, { width: size, height: size, borderRadius: size * .35 }] },
    react_1.default.createElement(react_native_1.Text, { style: [exports.s.markText, { fontSize: size * .82 }] }, "W")); }
function Avatar({ person, size = 38, ring = false, onPress, colors }) {
    const body = react_1.default.createElement(react_native_1.View, { style: [exports.s.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: colors.panel }] }, person.avatar ? react_1.default.createElement(react_native_1.Image, { source: (0, logic_1.sourceFor)(person.avatar), style: { width: '100%', height: '100%', borderRadius: size / 2 }, resizeMode: "cover" }) : react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800', fontSize: size * .38 } }, (person.name || person.username || '?')[0]?.toUpperCase()));
    const inner = ring ? react_1.default.createElement(expo_linear_gradient_1.LinearGradient, { colors: theme_1.RAINBOW, style: { padding: 3, borderRadius: size / 2 + 4 } }, react_1.default.cloneElement(body, { style: [body.props.style, { borderWidth: 3, borderColor: colors.bg }] })) : body;
    return onPress ? react_1.default.createElement(react_native_1.Pressable, { onPress: onPress }, inner) : inner;
}
function Header({ title, onBack, right, colors }) { return react_1.default.createElement(react_native_1.View, { style: [exports.s.header, { backgroundColor: colors.bg }] },
    onBack ? react_1.default.createElement(IconButton, { name: "chevron-back", label: "Retour", onPress: onBack, color: colors.text }) : react_1.default.createElement(react_native_1.View, { style: { width: 42 } }),
    react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [exports.s.headerTitle, { color: colors.text }] }, title),
    right || react_1.default.createElement(react_native_1.View, { style: { width: 42 } })); }
function Empty({ title, body, colors, icon = 'camera-outline' }) { return react_1.default.createElement(react_native_1.View, { style: exports.s.empty },
    react_1.default.createElement(react_native_1.View, { style: [exports.s.emptyIcon, { borderColor: colors.line }] },
        react_1.default.createElement(Ionicons_1.default, { name: icon, size: 30, color: colors.accent })),
    react_1.default.createElement(react_native_1.Text, { style: [exports.s.emptyTitle, { color: colors.text }] }, title),
    react_1.default.createElement(react_native_1.Text, { style: [exports.s.emptyBody, { color: colors.muted }] }, body)); }
function PrimaryButton({ title, onPress, disabled = false, colors }) { return react_1.default.createElement(react_native_1.Pressable, { disabled: disabled, onPress: onPress, style: { opacity: disabled ? .45 : 1 } },
    react_1.default.createElement(expo_linear_gradient_1.LinearGradient, { colors: ['#ff4fa3', '#ff4fa3'], start: { x: 0, y: .5 }, end: { x: 1, y: .5 }, style: exports.s.primary },
        react_1.default.createElement(react_native_1.Text, { style: exports.s.primaryText }, title))); }
function SecondaryButton({ title, onPress, colors }) { return react_1.default.createElement(react_native_1.Pressable, { onPress: onPress, style: [exports.s.secondary, { backgroundColor: colors.panel, borderColor: colors.line }] },
    react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '700' } }, title)); }
function TabChip({ title, active, onPress, colors }) { return react_1.default.createElement(react_native_1.Pressable, { onPress: onPress, style: [exports.s.chip, { backgroundColor: active ? colors.accent + '20' : colors.panel }] },
    react_1.default.createElement(react_native_1.Text, { style: { fontSize: 12, fontWeight: active ? '800' : '500', color: active ? colors.accent : colors.text } }, title)); }
exports.s = react_native_1.StyleSheet.create({
    iconButton: { width: 42, height: 42, alignItems: 'center', justifyContent: 'center', borderRadius: 21 },
    mark: { alignItems: 'center', justifyContent: 'center' }, markText: { color: '#fff', fontWeight: '900', fontFamily: 'sans-serif-condensed', lineHeight: 34 },
    avatar: { overflow: 'hidden', alignItems: 'center', justifyContent: 'center' },
    header: { height: 62, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10 }, headerTitle: { flex: 1, fontSize: 22, fontWeight: '800', letterSpacing: -.7, textAlign: 'center' },
    empty: { paddingHorizontal: 25, paddingVertical: 50, alignItems: 'center', gap: 12 }, emptyIcon: { width: 68, height: 68, borderRadius: 34, borderWidth: 1, alignItems: 'center', justifyContent: 'center' }, emptyTitle: { fontSize: 18, fontWeight: '800' }, emptyBody: { fontSize: 13, lineHeight: 22, textAlign: 'center', maxWidth: 290 },
    primary: { minHeight: 48, borderRadius: 13, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 20 }, primaryText: { color: '#fff', fontWeight: '800', fontSize: 14 },
    secondary: { minHeight: 44, borderRadius: 11, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 18 },
    chip: { paddingHorizontal: 15, paddingVertical: 8, borderRadius: 20 }
});

};

__modules["src/context"] = function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppContext = void 0;
exports.useApp = useApp;
const react_1 = require("react");
exports.AppContext = (0, react_1.createContext)(null);
function useApp() { const v = (0, react_1.useContext)(exports.AppContext); if (!v)
    throw new Error('AppContext absent'); return v; }

};

__modules["src/logic"] = function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.uriFor = exports.sourceFor = exports.sortPosts = exports.validUsername = exports.cleanUsername = void 0;
exports.safeUrl = safeUrl;
exports.parseEmbed = parseEmbed;
exports.parseEmbeds = parseEmbeds;
exports.formatWhen = formatWhen;
const cleanUsername = (v) => v.trim().toLowerCase().replace(/^@/, '');
exports.cleanUsername = cleanUsername;
const validUsername = (v) => /^[a-z0-9_.]{3,24}$/.test(v);
exports.validUsername = validUsername;
function parseWebUrl(raw) {
    // Media parsing deliberately uses no platform URL/URLSearchParams constructor.
    const value = String(raw || '').replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, '').trim();
    if (/[\s\\\u0000-\u001F\u007F<>"']/.test(value)) return null;
    const parts = value.match(/^(https?):\/\/([^/?#]+)([^?#]*)(\?[^#]*)?(#.*)?$/i);
    if (!parts || parts[2].includes('@')) return null;
    const authority = parts[2].toLowerCase();
    const hostParts = authority.startsWith('[')
        ? authority.match(/^(\[[0-9a-f:.]+\])(?::(\d+))?$/i)
        : authority.match(/^([a-z0-9](?:[a-z0-9.-]*[a-z0-9])?)(?::(\d+))?$/i);
    if (!hostParts || (hostParts[2] && Number(hostParts[2]) > 65535)) return null;
    const hostname = hostParts[1];
    if (!hostname.startsWith('[') && hostname.split('.').some(label => !label || label.startsWith('-') || label.endsWith('-'))) return null;
    const protocol = parts[1].toLowerCase() + ':';
    const pathname = parts[3] || '/';
    const search = parts[4] || '';
    const hash = parts[5] || '';
    const decode = x => { try { return decodeURIComponent(x.replace(/\+/g, ' ')); } catch { return x; } };
    const query = search.slice(1).split('&').map(pair => { const i = pair.indexOf('='); return i < 0 ? [decode(pair), ''] : [decode(pair.slice(0, i)), decode(pair.slice(i + 1))]; });
    return { protocol, hostname, pathname, search, hash, href: protocol + '//' + authority + pathname + search + hash,
        searchParams: { get: name => query.find(pair => pair[0] === name)?.[1] ?? null } };
}
function safeUrl(raw) { return parseWebUrl(raw)?.href || ''; }
function mediaFromUrl(raw, forcedType = '') {
    const value = decodeMarkup(raw).trim();
    const href = safeUrl(value.startsWith('//') ? 'https:' + value : value);
    if (!href)
        throw new Error('Lien non reconnu. Colle une adresse complète commençant par https://.');
    const u = parseWebUrl(href), host = u.hostname;
    if (forcedType === 'image')
        return { type: 'image', url: href };
    if (forcedType === 'video')
        return { type: 'video', url: href };
    if (/\.(mp4|webm|m4v|mov|m3u8)(\?.*)?$/i.test(u.pathname))
        return { type: 'video', url: href };
    if (/\.(jpe?g|png|webp|gif|avif|heic)(\?.*)?$/i.test(u.pathname))
        return { type: 'image', url: href };
    if (host === 'sendvid.com' || host === 'www.sendvid.com') {
        const match = u.pathname.match(/^\/(?:embed\/)?([a-zA-Z0-9]+)\/?$/);
        if (match) return { type: 'embed', url: 'https://sendvid.com/embed/' + match[1] + u.search, originalUrl: href };
    }
    if (['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'www.youtube-nocookie.com'].includes(host)) {
        const id = host === 'youtu.be' ? u.pathname.slice(1) : u.searchParams.get('v') || u.pathname.split('/').filter(Boolean).pop();
        if (!/^[\w-]{11}$/.test(id || ''))
            throw new Error('Ce lien YouTube ne contient pas de vidéo valide.');
        return { type: 'embed', url: 'https://www.youtube-nocookie.com/embed/' + id, poster: 'https://i.ytimg.com/vi/' + id + '/hqdefault.jpg' };
    }
    if (['vimeo.com', 'www.vimeo.com', 'player.vimeo.com'].includes(host)) {
        const id = u.pathname.split('/').filter(Boolean).pop();
        if (!/^\d+$/.test(id || ''))
            throw new Error('Lien Vimeo invalide.');
        return { type: 'embed', url: 'https://player.vimeo.com/video/' + id };
    }
    if (['www.dailymotion.com', 'dailymotion.com', 'dai.ly'].includes(host)) {
        const id = u.pathname.split('/').filter(Boolean).pop()?.split('_')[0];
        if (!/^[a-zA-Z0-9]+$/.test(id || ''))
            throw new Error('Lien Dailymotion invalide.');
        return { type: 'embed', url: 'https://www.dailymotion.com/embed/video/' + id };
    }
    if (forcedType === 'embed')
        return { type: 'embed', url: href };
    return { type: 'embed', url: href };
}
function decodeMarkup(value) {
    return String(value || '').replace(/[\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g, '').replace(/\\\//g, '/').replace(/\\(["'])/g, '$1')
        .replace(/[“”]/g, '"').replace(/[‘’]/g, "'")
        .replace(/&(?:amp|quot|apos|lt|gt|nbsp);|&#(?:x[\da-f]+|\d+);/gi, token => {
            const named = { '&amp;': '&', '&quot;': '"', '&apos;': "'", '&lt;': '<', '&gt;': '>', '&nbsp;': ' ' };
            if (named[token.toLowerCase()]) return named[token.toLowerCase()];
            const hex = token[2].toLowerCase() === 'x';
            const n = parseInt(token.slice(hex ? 3 : 2, -1), hex ? 16 : 10);
            return n > 0 && n <= 0x10ffff ? String.fromCodePoint(n) : '';
        });
}
function parseEmbed(raw) {
    const all = parseEmbeds(raw);
    if (!all.length) throw new Error('Ajoute un lien ou un code intégré.');
    return all[0];
}
function parseEmbeds(raw) {
    const text = decodeMarkup(raw).trim().replace(/<script\b[^>]*>[\s\S]*?<\/script\s*>/gi, '');
    if (!text) return [];
    const candidates = [];
    const ranges = [];
    const add = (url, type, index) => candidates.push({ url: url.trim(), type, index });
    const typeFor = tag => tag === 'img' ? 'image' : ['video', 'source'].includes(tag) ? 'video' : 'embed';
    const tags = /<\s*(iframe|img|video|source)\b[^>]*>/gi;
    let match;
    while ((match = tags.exec(text))) {
        const src = match[0].match(/\s(?:src|data-src)\s*=\s*(?:"([^"]+)"|'([^']+)'|([^\s>]+))/i);
        if (src) add(src[1] || src[2] || src[3], typeFor(match[1].toLowerCase()), match.index);
        ranges.push([match.index, tags.lastIndex]);
    }
    const bb = /\[(img|video|iframe|media)(?:[^\]]*)\]\s*([^\[]+?)\s*\[\/\1\]/gi;
    while ((match = bb.exec(text))) {
        add(match[2], typeFor(match[1].toLowerCase()), match.index);
        ranges.push([match.index, bb.lastIndex]);
    }
    // Plain URLs can coexist with HTML or BBCode; skip links inside wrapper tags.
    const remaining = text.replace(/<[^>]*>/g, m => ' '.repeat(m.length))
        .replace(/\[[^\]]*\]/g, m => ' '.repeat(m.length));
    const urls = /https?:\/\/[^\s<>"'\[\]]+/gi;
    while ((match = urls.exec(remaining))) {
        if (!ranges.some(([a, b]) => match.index >= a && match.index < b)) add(match[0], '', match.index);
    }
    if (!candidates.length && /^\/\//.test(text)) add(text, '', 0);
    // URL-only BBCode, including [url=https://…]label[/url].
    if (!candidates.length) {
        const urlTag = text.match(/\[url\s*=\s*["']?([^\]"']+)["']?\]/i);
        if (urlTag) add(urlTag[1], '', 0);
    }
    if (!candidates.length) throw new Error('Aucun média détecté. Colle une URL, une balise <img>/<video>/<iframe> ou du BBCode [img].');
    const found = [];
    for (const item of candidates.sort((a, b) => a.index - b.index)) {
        const media = mediaFromUrl(item.url, item.type);
        if (!found.some(x => x.url === media.url && x.type === media.type)) found.push(media);
    }
    return found;
}
exports.fittedImageFrame = (width, height, ratio) => {
    const fittedHeight = ratio > 0 && Number.isFinite(ratio) ? Math.min(height, width / ratio) : height;
    return { height: fittedHeight, bottom: Math.max(0, (height - fittedHeight) / 2) };
};
exports.mergePosts = function(primary, secondary = []) {
    const seen = new Set();
    return [...primary, ...secondary].filter(p => p && p.id && !seen.has(p.id) && seen.add(p.id))
        .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
};
exports.profileItems = (posts, id, saved, currentUser) => posts.filter(p => saved
    ? (p.saves || []).some(s => s.user_id === currentUser)
    : (p.user_id || p.owner?.id) === id && !p.media?.[0]?.repost?.source_post_id);
exports.isVideoPost = post => (post.media || []).some(m => m.type === 'video' || m.type === 'embed');
exports.profileActivityItems = (posts, currentUser) => {
    const selected = exports.mergePosts(posts).filter(p =>
        (p.user_id === currentUser && !!p.media?.[0]?.repost?.source_post_id) ||
        (exports.isVideoPost(p) && (p.likes || []).some(l => l.user_id === currentUser)));
    const seen = new Set();
    return selected.filter(p => {
        const originalId = p.media?.[0]?.repost?.source_post_id || p.id;
        if (seen.has(originalId)) return false;
        seen.add(originalId); return true;
    });
};
exports.isUpSwipe = g => g.dy < -10 && Math.abs(g.dy) > Math.abs(g.dx) * 1.2;
exports.shouldDismissMedia = g => exports.isUpSwipe(g) && (g.dy < -65 || (g.vy < -0.60 && g.dy < -24));

const popularityScore = post => {
    const likes = Array.isArray(post?.likes) ? post.likes.length : 0;
    const comments = Array.isArray(post?.comments) ? post.comments.length : 0;
    // Les commentaires pèsent légèrement plus que les likes pour faire remonter
    // automatiquement les publications qui génèrent le plus d'interactions.
    return likes * 2 + comments * 3;
};
const sortPosts = (posts, mode) => [...posts].sort((a, b) => {
    if (mode === 'popular') {
        const scoreDiff = popularityScore(b) - popularityScore(a);
        if (scoreDiff) return scoreDiff;
        const commentDiff = (Array.isArray(b?.comments) ? b.comments.length : 0) - (Array.isArray(a?.comments) ? a.comments.length : 0);
        if (commentDiff) return commentDiff;
        const likeDiff = (Array.isArray(b?.likes) ? b.likes.length : 0) - (Array.isArray(a?.likes) ? a.likes.length : 0);
        if (likeDiff) return likeDiff;
    }
    return Date.parse(b.created_at) - Date.parse(a.created_at);
});
exports.sortPosts = sortPosts;
function formatWhen(date) { const diff = Date.now() - Date.parse(date); return diff < 60000 ? 'À l’instant' : diff < 3600000 ? Math.floor(diff / 60000) + ' min' : diff < 86400000 ? Math.floor(diff / 3600000) + ' h' : new Date(date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }); }
const sourceFor = (ref) => typeof ref === 'number' ? ref : ref ? { uri: ref } : undefined;
exports.sourceFor = sourceFor;
const uriFor = (ref) => typeof ref === 'string' ? ref : '';
exports.uriFor = uriFor;

};

__modules["src/screens/auth"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigModal = ConfigModal;
exports.AuthScreen = AuthScreen;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const expo_video_1 = require("expo-video");
const api = __importStar(__load("src/api"));
const ui_1 = __load("src/components/ui");
function ConfigModal({ visible, onClose, colors }) {
    return react_1.default.createElement(react_native_1.Modal, { visible: visible, transparent: true, animationType: "slide", onRequestClose: onClose },
        react_1.default.createElement(react_native_1.Pressable, { style: s.shade, onPress: onClose },
            react_1.default.createElement(react_native_1.Pressable, { style: [s.sheet, { backgroundColor: colors.bg }], onPress: () => { } },
                react_1.default.createElement(react_native_1.View, { style: [s.grab, { backgroundColor: colors.line }] }),
                react_1.default.createElement(react_native_1.Text, { style: [s.sheetTitle, { color: colors.text }] }, "Firebase connecté"),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 12, lineHeight: 19 } }, "Comptes, profils, publications et messagerie utilisent Firebase. Les photos et vidéos sont envoyées sur ImageKit via un endpoint sécurisé Netlify."),
                react_1.default.createElement(react_native_1.View, { style: { gap: 6, paddingVertical: 6 } },
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '700' } }, "Projet : kidflix-953e1"),
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 11 } }, "Médias : ImageKit · Frankfurt (Europe)")),
                react_1.default.createElement(ui_1.SecondaryButton, { title: "Fermer", onPress: onClose, colors: colors }))));
}
const AUTH_BG_VIDEO = __AUTH_BG_VIDEO;
function AuthScreen({ colors, onReady, notify }) {
    const [mode, setMode] = (0, react_1.useState)('login');
    const [identifier, setIdentifier] = (0, react_1.useState)('');
    const [password, setPassword] = (0, react_1.useState)('');
    const [busy, setBusy] = (0, react_1.useState)(false);
    const [visible, setVisible] = (0, react_1.useState)(false);
    const backgroundPlayer = (0, expo_video_1.useVideoPlayer)(AUTH_BG_VIDEO, p => {
        p.loop = true;
        p.muted = false;
        p.volume = 1;
        p.play();
    });
    (0, react_1.useEffect)(() => {
        backgroundPlayer.muted = false;
        backgroundPlayer.volume = 1;
        backgroundPlayer.play();
        return () => { try { backgroundPlayer.pause(); } catch (_) { } };
    }, [backgroundPlayer]);
    const submit = async () => {
        if (busy) return;
        setBusy(true);
        try {
            const p = mode === 'signup' ? await api.signup(identifier, password) : await api.login(identifier, password);
            if (p) onReady(p);
        } catch (e) { notify(e.message); }
        finally { setBusy(false); }
    };
    const enterGuest = async () => {
        if (busy) return;
        setBusy(true);
        try {
            const p = await api.continueAsGuest();
            if (p) onReady(p);
        } catch (e) { notify(e.message); }
        finally { setBusy(false); }
    };
    const title = mode === 'signup' ? 'Inscription' : 'Connexion';
    const subtitle = mode === 'signup'
        ? 'Choisis simplement un identifiant et un mot de passe. Aucune adresse e-mail demandée.'
        : 'Connecte-toi avec ton identifiant et ton mot de passe.';
    return react_1.default.createElement(react_native_1.KeyboardAvoidingView, { style: s.authRoot, behavior: react_native_1.Platform.OS === 'ios' ? 'padding' : undefined },
        react_1.default.createElement(expo_video_1.VideoView, { player: backgroundPlayer, style: react_native_1.StyleSheet.absoluteFill, contentFit: "cover", nativeControls: false, surfaceType: "textureView", pointerEvents: "none" }),
        react_1.default.createElement(react_native_1.View, { style: s.snapStage },
            react_1.default.createElement(react_native_1.View, { style: s.snapHeader }),
            react_1.default.createElement(react_native_1.ScrollView, { keyboardShouldPersistTaps: "handled", contentContainerStyle: s.snapScroll },
                react_1.default.createElement(react_native_1.View, { style: s.snapHero },
                    react_1.default.createElement(react_native_1.Text, { style: s.snapTitle }, title),
                    react_1.default.createElement(react_native_1.Text, { style: s.snapSubtitle }, subtitle)),
                react_1.default.createElement(react_native_1.View, { style: s.snapForm },
                    react_1.default.createElement(react_native_1.View, { style: s.snapInput },
                        react_1.default.createElement(Ionicons_1.default, { name: "person-outline", size: 20, color: "#7e91aa" }),
                        react_1.default.createElement(react_native_1.TextInput, { value: identifier, onChangeText: setIdentifier, autoCapitalize: "none", autoCorrect: false, placeholder: "Identifiant", placeholderTextColor: "#7a8797", style: s.snapInputText })),
                    react_1.default.createElement(react_native_1.View, { style: s.snapInput },
                        react_1.default.createElement(Ionicons_1.default, { name: "lock-closed-outline", size: 20, color: "#7e91aa" }),
                        react_1.default.createElement(react_native_1.TextInput, { value: password, onChangeText: setPassword, secureTextEntry: !visible, autoCapitalize: "none", placeholder: mode === 'signup' ? 'Mot de passe · 6 caractères minimum' : 'Mot de passe', placeholderTextColor: "#7a8797", style: s.snapInputText }),
                        react_1.default.createElement(ui_1.IconButton, { name: visible ? 'eye-off-outline' : 'eye-outline', label: visible ? 'Masquer' : 'Afficher', onPress: () => setVisible(v => !v), color: '#7e91aa', size: 19 })),
                    react_1.default.createElement(react_native_1.Pressable, { disabled: busy, onPress: submit, style: [s.snapPrimary, busy && { opacity: .6 }] },
                        react_1.default.createElement(react_native_1.Text, { style: s.snapPrimaryText }, busy ? 'Un instant…' : mode === 'signup' ? 'S’inscrire' : 'Se connecter')),
                    react_1.default.createElement(react_native_1.Pressable, { disabled: busy, onPress: enterGuest, style: [s.guestButton, busy && { opacity: .6 }] },
                        react_1.default.createElement(Ionicons_1.default, { name: "eye-outline", size: 18, color: "#d8e8ff" }),
                        react_1.default.createElement(react_native_1.Text, { style: s.guestButtonText }, "Continuer en visiteur")),
                    react_1.default.createElement(react_native_1.Text, { style: s.guestHint }, "Visiteur : Accueil, Explorer, profils et publication par URL / iframe / BBCode. Messagerie indisponible."))),
            react_1.default.createElement(react_native_1.View, { style: s.snapFooter },
                react_1.default.createElement(react_native_1.Pressable, { onPress: () => setMode('signup'), style: s.snapFooterTab },
                    react_1.default.createElement(react_native_1.Text, { style: [s.snapFooterText, mode === 'signup' && s.snapFooterTextActive] }, "Inscription")),
                react_1.default.createElement(react_native_1.View, { style: s.snapFooterDivider }),
                react_1.default.createElement(react_native_1.Pressable, { onPress: () => setMode('login'), style: s.snapFooterTab },
                    react_1.default.createElement(react_native_1.Text, { style: [s.snapFooterText, mode === 'login' && s.snapFooterTextActive] }, "Connexion")))));
}
const s = react_native_1.StyleSheet.create({ authRoot: { flex: 1, backgroundColor: 'transparent' }, snapStage: { flex: 1, backgroundColor: 'transparent' }, snapHeader: { height: 14, backgroundColor: 'transparent' }, snapScroll: { flexGrow: 1, paddingHorizontal: 24, paddingBottom: 20, backgroundColor: 'transparent' }, snapHero: { flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 300, backgroundColor: 'transparent' }, snapTitle: { color: '#ffffff', fontSize: 28, fontWeight: '900', textAlign: 'center', letterSpacing: -.8, textShadowColor: '#000000cc', textShadowOffset: { width: 0, height: 2 }, textShadowRadius: 8 }, snapSubtitle: { color: '#fff5fb', fontSize: 12.5, lineHeight: 18, textAlign: 'center', marginTop: 7, paddingHorizontal: 14, textShadowColor: '#000000dd', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 6 }, snapForm: { gap: 11, paddingBottom: 14 }, snapInput: { minHeight: 52, borderRadius: 15, backgroundColor: '#08040aaa', borderWidth: 1, borderColor: '#ff6ab8aa', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14 }, snapInputText: { flex: 1, paddingHorizontal: 10, color: '#ffffff', fontSize: 14 }, snapPrimary: { minHeight: 56, borderRadius: 28, backgroundColor: '#ff4fa3cc', borderWidth: 1, borderColor: '#ff9ad0cc', alignItems: 'center', justifyContent: 'center', marginTop: 3 }, snapPrimaryText: { color: '#fff', fontSize: 16.5, fontWeight: '800', textShadowColor: '#00000088', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3 }, guestButton: { minHeight: 48, borderRadius: 24, borderWidth: 1, borderColor: '#ff79bd99', backgroundColor: '#08040a99', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8 }, guestButtonText: { color: '#ffffff', fontSize: 14, fontWeight: '750', textShadowColor: '#000000aa', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 3 }, guestHint: { color: '#fff5fb', fontSize: 10.5, lineHeight: 15, textAlign: 'center', paddingHorizontal: 10, textShadowColor: '#000000dd', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 }, snapFooter: { minHeight: 96, paddingBottom: 40, paddingHorizontal: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: 'transparent' }, snapFooterTab: { flex: 1, alignItems: 'center', justifyContent: 'center', minHeight: 42 }, snapFooterDivider: { width: 1, height: 28, backgroundColor: '#ffffff55', marginHorizontal: 8 }, snapFooterText: { color: '#ffffff', fontSize: 15, fontWeight: '700', opacity: .72, textShadowColor: '#000000cc', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 4 }, snapFooterTextActive: { opacity: 1, color: '#ffffff' }, shade: { flex: 1, backgroundColor: '#0008', justifyContent: 'flex-end' }, sheet: { padding: 20, paddingBottom: 35, borderTopLeftRadius: 24, borderTopRightRadius: 24, gap: 14 }, grab: { width: 38, height: 4, borderRadius: 2, alignSelf: 'center' }, sheetTitle: { fontSize: 20, fontWeight: '800' }, input: { height: 48, borderRadius: 13, paddingHorizontal: 14 } });

};

__modules["src/screens/chat"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatListScreen = ChatListScreen;
exports.ConversationScreen = ConversationScreen;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const safe_area_1 = require("react-native-safe-area-context");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const ImagePicker = __importStar(require("expo-image-picker"));
const WebView_1 = { default: require("react-native-webview").WebView };
const expo_audio_1 = require("expo-audio");
const api = __importStar(__load("src/api"));
const logic_1 = __load("src/logic");
const context_1 = __load("src/context");
const ui_1 = __load("src/components/ui");
const media_1 = __load("src/components/media");
function ChatListScreen({ colors }) { const a = (0, context_1.useApp)(); const [threads, setThreads] = (0, react_1.useState)([]); const [q, setQ] = (0, react_1.useState)(''); const [unread, setUnread] = (0, react_1.useState)(false); const [error, setError] = (0, react_1.useState)(''); const [refreshing, setRefreshing] = (0, react_1.useState)(false); const manualRefresh = async () => { if (refreshing) return; setRefreshing(true); try { const data = await api.threads(); setThreads(data); setError(''); } catch (e) { setError(e.message); } finally { setRefreshing(false); } }; (0, react_1.useEffect)(() => { let live = true, busy = false; const load = async () => { if (busy)
    return; busy = true; try {
    const data = await api.threads();
    if (live) {
        setThreads(data);
        setError('');
    }
}
catch (e) {
    if (live)
        setError(e.message);
}
finally {
    busy = false;
} }; load(); const t = setInterval(load, 4000); return () => { live = false; clearInterval(t); }; }, [a.posts]); const filtered = threads.filter(t => (!unread || t.unread > 0) && (t.peer.name + ' ' + t.peer.username).toLowerCase().includes(q.toLowerCase())); return react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
    react_1.default.createElement(react_native_1.View, { style: s.chatHeader },
        react_1.default.createElement(ui_1.Avatar, { person: a.me, colors: colors, onPress: () => a.push({ name: 'profile' }) }),
        react_1.default.createElement(ui_1.IconButton, { name: "search", label: "Rechercher", color: colors.text }),
        react_1.default.createElement(react_native_1.Text, { style: [s.chatTitle, { color: colors.text }] }, "Chat"),
        react_1.default.createElement(react_native_1.Pressable, { style: s.rainbowAction, onPress: () => a.push({ name: 'people', chat: true }) },
            react_1.default.createElement(Ionicons_1.default, { name: "person-add", size: 22, color: "#111" })),
        react_1.default.createElement(ui_1.IconButton, { name: "ellipsis-horizontal", label: "Param\u00E8tres", onPress: () => a.push({ name: 'settings' }), color: colors.text })),
    react_1.default.createElement(react_native_1.View, { style: [s.search, { backgroundColor: colors.panel }] },
        react_1.default.createElement(Ionicons_1.default, { name: "search", size: 18, color: colors.muted }),
        react_1.default.createElement(react_native_1.TextInput, { value: q, onChangeText: setQ, placeholder: "Rechercher un ami", placeholderTextColor: colors.muted, style: { flex: 1, color: colors.text } })),
    react_1.default.createElement(react_native_1.View, { style: [s.filters, { borderBottomColor: colors.line }] },
        react_1.default.createElement(react_native_1.Pressable, { onPress: () => setUnread(false) },
            react_1.default.createElement(react_native_1.Text, { style: { color: !unread ? colors.text : colors.muted, fontWeight: '700' } }, "Tous les chats")),
        react_1.default.createElement(react_native_1.Pressable, { onPress: () => setUnread(true) },
            react_1.default.createElement(react_native_1.Text, { style: { color: unread ? colors.text : colors.muted, fontWeight: '700' } },
                "Non lus  ",
                threads.reduce((n, t) => n + t.unread, 0)))),
    !!error && react_1.default.createElement(react_native_1.Text, { style: [s.error, { color: colors.danger }] },
        "Actualisation impossible. ",
        error),
    react_1.default.createElement(react_native_1.FlatList, { data: filtered, keyExtractor: x => x.id, refreshing: refreshing, onRefresh: manualRefresh, progressViewOffset: 6, renderItem: ({ item: t }) => react_1.default.createElement(react_native_1.Pressable, { style: [s.chatRow, { borderBottomColor: colors.line }], onPress: () => a.push({ name: 'conversation', thread: t }) },
            react_1.default.createElement(ui_1.Avatar, { person: t.peer, size: 55, colors: colors }),
            react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
                react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.chatPerson, { color: colors.text }] }, t.peer.name || t.peer.username),
                react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: { color: t.unread ? '#00b7ef' : colors.muted, fontSize: 12, marginTop: 6 } },
                    t.unread ? '▢ Nouveau message' : !t.last ? 'Dis bonjour 👋' : t.last.sender_id === api.uid ? t.last.read_at ? '➤ Ouvert' : '➤ Remis' : t.last.kind === 'audio' ? '▢ Message vocal' : t.last.kind === 'image' ? '▢ Photo' : t.last.kind === 'video' ? '▢ Vidéo' : '▢ ' + t.last.body.slice(0, 30),
                    t.last ? ' · ' + (0, logic_1.formatWhen)(t.last.created_at) : '')),
            t.unread > 0 && react_1.default.createElement(react_native_1.View, { style: s.badge },
                react_1.default.createElement(react_native_1.Text, { style: { color: '#fff', fontSize: 10 } }, t.unread)),
            react_1.default.createElement(Ionicons_1.default, { name: "camera-outline", size: 27, color: colors.text })), ListEmptyComponent: react_1.default.createElement(ui_1.Empty, { title: unread ? 'Tout est lu' : 'Les conversations commencent ici', body: unread ? 'Tu n’as aucun message non lu.' : 'Trouve un compte et envoie-lui un premier message.', colors: colors }) }),
    react_1.default.createElement(react_native_1.Pressable, { onPress: () => a.push({ name: 'people', chat: true }), style: s.floating },
        react_1.default.createElement(Ionicons_1.default, { name: "create-outline", size: 28, color: "#111" }))); }
function Voice({ url, colors }) { const player = (0, expo_audio_1.useAudioPlayer)(url, { updateInterval: 100 }); const status = (0, expo_audio_1.useAudioPlayerStatus)(player); const [speed, setSpeed] = (0, react_1.useState)(1); const current = status.currentTime || 0, duration = status.duration || 0; return react_1.default.createElement(react_native_1.View, { style: [s.voice, { backgroundColor: colors.panel }] },
    react_1.default.createElement(ui_1.IconButton, { name: status.playing ? 'pause' : 'play', label: status.playing ? 'Pause' : 'Lecture', onPress: () => status.playing ? player.pause() : player.play(), color: colors.accent, size: 19 }),
    react_1.default.createElement(react_native_1.View, { style: s.wave }, Array.from({ length: 28 }, (_, i) => react_1.default.createElement(react_native_1.View, { key: i, style: { width: 3, height: 8 + ((i * 17 + 13) % 27), borderRadius: 2, backgroundColor: colors.accent, opacity: duration && i / 28 < current / duration ? 1 : .35 } }))),
    react_1.default.createElement(react_native_1.Pressable, { onPress: () => { const n = speed === 1 ? 1.5 : speed === 1.5 ? 2 : 1; setSpeed(n); player.playbackRate = n; }, style: [s.speed, { backgroundColor: colors.line }] },
        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 10, fontWeight: '800' } },
            speed,
            "x")),
    react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 11 } },
        Math.floor((status.playing ? current : duration) / 60),
        ":",
        String(Math.floor((status.playing ? current : duration) % 60)).padStart(2, '0'))); }
function ConversationScreen({ thread, colors }) {
    const a = (0, context_1.useApp)();
    const insets = (0, safe_area_1.useSafeAreaInsets)();
    const [messages, setMessages] = (0, react_1.useState)([]);
    const [text, setText] = (0, react_1.useState)('');
    const [busy, setBusy] = (0, react_1.useState)(false);
    const [progress, setProgress] = (0, react_1.useState)(0);
    const [emoji, setEmoji] = (0, react_1.useState)(false);
    const [voice, setVoice] = (0, react_1.useState)(null);
    const list = (0, react_1.useRef)(null);
    const recorder = (0, expo_audio_1.useAudioRecorder)(expo_audio_1.RecordingPresets.HIGH_QUALITY);
    const rec = (0, expo_audio_1.useAudioRecorderState)(recorder, 250);
    const recording = rec.isRecording;
    const load = async () => { const r = await api.messages(thread.id); setMessages(r); await api.markRead(thread.id); setTimeout(() => list.current?.scrollToEnd({ animated: false }), 30); };
    (0, react_1.useEffect)(() => { let live = true; load().catch(() => { }); const t = setInterval(() => { if (live)
        load().catch(() => { }); }, 3000); return () => { live = false; clearInterval(t); }; }, [thread.id]);
    const sendText = async () => { if (!text.trim() || busy)
        return; setBusy(true); await a.run(async () => { await api.send(thread.id, 'text', text.trim()); setText(''); setEmoji(false); await load(); }); setBusy(false); };
    const sendFile = async (file) => { if (busy)
        return; setBusy(true); setProgress(0); await a.run(async () => { const path = await api.upload(file, setProgress, thread.id); await api.send(thread.id, file.mimeType.startsWith('image') ? 'image' : file.mimeType.startsWith('audio') ? 'audio' : 'video', '', path); setVoice(null); await load(); }); setBusy(false); };
    const choose = async () => { const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images', 'videos'], quality: 1 }); if (r.canceled)
        return; const x = r.assets[0]; sendFile({ uri: x.uri, mimeType: x.mimeType || (x.type === 'video' ? 'video/mp4' : 'image/jpeg'), fileName: x.fileName || undefined, fileSize: x.fileSize }); };
    const camera = async () => { const perm = await ImagePicker.requestCameraPermissionsAsync(); if (!perm.granted) {
        a.notify('Autorise la caméra pour prendre une photo.');
        return;
    } const r = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: .9 }); if (r.canceled)
        return; const x = r.assets[0]; sendFile({ uri: x.uri, mimeType: x.mimeType || 'image/jpeg', fileName: x.fileName || 'photo.jpg', fileSize: x.fileSize }); };
    const toggleRecord = async () => { if (recording) {
        await recorder.stop();
        const uri = recorder.uri;
        if (uri)
            setVoice({ uri, mimeType: 'audio/mp4', fileName: 'vocal.m4a' });
        return;
    } const perm = await expo_audio_1.AudioModule.requestRecordingPermissionsAsync(); if (!perm.granted) {
        a.notify('Permission microphone refusée.');
        return;
    } await (0, expo_audio_1.setAudioModeAsync)({ playsInSilentMode: true, allowsRecording: true }); await recorder.prepareToRecordAsync(); recorder.record({ forDuration: 120 }); };
    return react_1.default.createElement(react_native_1.View, { style: [s.conversation, { backgroundColor: colors.chat }] },
        react_1.default.createElement(react_native_1.View, { style: [s.convHeader, { borderBottomColor: colors.line, backgroundColor: colors.bg }] },
            react_1.default.createElement(ui_1.IconButton, { name: "chevron-back", label: "Retour", onPress: a.back, color: colors.text, size: 29 }),
            react_1.default.createElement(ui_1.Avatar, { person: thread.peer, colors: colors, onPress: () => a.push({ name: 'profile', person: thread.peer }) }),
            react_1.default.createElement(react_native_1.Pressable, { style: { flex: 1 }, onPress: () => a.push({ name: 'profile', person: thread.peer }) },
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 18, fontWeight: '700' } }, thread.peer.name || thread.peer.username),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 10 } },
                    "@",
                    thread.peer.username)),
            react_1.default.createElement(ui_1.IconButton, { name: "call-outline", label: "Appels audio non disponibles", color: colors.muted, disabled: true }),
            react_1.default.createElement(ui_1.IconButton, { name: "videocam-outline", label: "Appels vid\u00E9o non disponibles", color: colors.muted, disabled: true })),
        react_1.default.createElement(react_native_1.FlatList, { ref: list, style: { flex: 1 }, contentContainerStyle: { padding: 10, paddingBottom: 18 }, data: messages, keyExtractor: x => x.id, ListHeaderComponent: react_1.default.createElement(react_1.default.Fragment, null,
                !messages.length && react_1.default.createElement(react_native_1.View, { style: s.welcome },
                    react_1.default.createElement(ui_1.Avatar, { person: thread.peer, size: 92, colors: colors }),
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 22, fontWeight: '800' } }, thread.peer.name),
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted } }, "Un bonjour, et tout commence."))), renderItem: ({ item: m }) => react_1.default.createElement(react_native_1.View, { style: s.message },
                react_1.default.createElement(react_native_1.Text, { style: { color: m.sender_id === api.uid ? '#f13f70' : '#00b2ef', fontSize: 10, fontWeight: '800', marginBottom: 5 } }, m.sender_id === api.uid ? 'MOI' : thread.peer.name.toUpperCase()),
                react_1.default.createElement(react_native_1.View, { style: [s.messageContent, { borderLeftColor: m.sender_id === api.uid ? '#f13f70' : '#00b2ef' }] },
                    m.kind === 'text' ? react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 15, lineHeight: 23 } }, m.body) : m.kind === 'audio' ? react_1.default.createElement(Voice, { url: (0, logic_1.uriFor)(m.url), colors: colors }) : m.kind === 'image' ? react_1.default.createElement(react_native_1.Pressable, { onPress: () => a.lightbox(m.url || '', 'image') },
                        react_1.default.createElement(react_native_1.View, { style: s.msgMedia },
                            react_1.default.createElement(media_1.MediaItem, { media: { type: 'image', url: m.url }, active: false, full: false, colors: colors, fit: 'contain' }))) : react_1.default.createElement(react_native_1.Pressable, { onPress: () => a.lightbox(m.url || '', 'video'), style: s.msgMedia },
                        react_1.default.createElement(media_1.NativeVideo, { uri: (0, logic_1.uriFor)(m.url), active: false, colors: colors }),
                        react_1.default.createElement(Ionicons_1.default, { name: "play", size: 36, color: "#fff", style: s.mediaPlay })),
                    react_1.default.createElement(react_native_1.View, { style: s.meta },
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 9 } }, (0, logic_1.formatWhen)(m.created_at)),
                        m.sender_id === api.uid && react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 9 } }, m.read_at ? 'Ouvert ✓✓' : 'Envoyé')))) }),
        busy && react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 10, paddingHorizontal: 18 } },
            "Envoi en cours\u2026 ",
            progress,
            "%"),
        voice && react_1.default.createElement(react_native_1.View, { style: [s.voicePreview, { backgroundColor: colors.bg }] },
            react_1.default.createElement(Voice, { url: voice.uri, colors: colors }),
            react_1.default.createElement(ui_1.IconButton, { name: "trash-outline", label: "Supprimer", onPress: () => setVoice(null), color: colors.text }),
            react_1.default.createElement(ui_1.IconButton, { name: "send", label: "Envoyer", onPress: () => sendFile(voice), color: "#00b7ef" })),
        recording && react_1.default.createElement(react_native_1.View, { style: [s.recording, { backgroundColor: colors.panel }] },
            react_1.default.createElement(react_native_1.View, { style: s.recDot }),
            react_1.default.createElement(react_native_1.Text, { style: { color: colors.danger } },
                "Enregistrement \u00B7 ",
                Math.floor(rec.durationMillis / 1000),
                "s"),
            react_1.default.createElement(react_native_1.Pressable, { onPress: toggleRecord },
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800' } }, "Terminer"))),
        emoji && react_1.default.createElement(react_native_1.View, { style: [s.emoji, { backgroundColor: colors.panel }] }, ['❤️', '😂', '😍', '🏳️‍🌈', '🔥', '😘', '👍', '✨', '🌈', '🥰', '💎', '🙌'].map(e => react_1.default.createElement(react_native_1.Pressable, { key: e, onPress: () => setText(t => t + e) },
            react_1.default.createElement(react_native_1.Text, { style: { fontSize: 25 } }, e)))),
        react_1.default.createElement(react_native_1.View, { style: [s.compose, { backgroundColor: colors.bg, borderTopColor: colors.line, paddingBottom: Math.max(insets.bottom + 8, 18), minHeight: 64 + Math.max(insets.bottom, 10) }] },
            react_1.default.createElement(react_native_1.Pressable, { onPress: camera, style: [s.cameraCircle, { backgroundColor: colors.text }] },
                react_1.default.createElement(Ionicons_1.default, { name: "camera", size: 25, color: colors.bg })),
            react_1.default.createElement(react_native_1.View, { style: [s.inputWrap, { borderColor: colors.muted }] },
                react_1.default.createElement(react_native_1.TextInput, { value: text, onChangeText: setText, placeholder: "Envoyer un Chat", placeholderTextColor: colors.muted, style: { flex: 1, color: colors.text, paddingHorizontal: 13 } }),
                react_1.default.createElement(ui_1.IconButton, { name: recording ? 'stop' : 'mic', label: recording ? 'Terminer' : 'Vocal', onPress: toggleRecord, color: recording ? colors.danger : colors.text, size: 21 })),
            text.trim() ? react_1.default.createElement(ui_1.IconButton, { name: "send", label: "Envoyer", onPress: sendText, color: "#00b7ef", size: 22 }) : react_1.default.createElement(ui_1.IconButton, { name: "happy-outline", label: "\u00C9mojis", onPress: () => setEmoji(v => !v), color: "#ffcc19" }),
            react_1.default.createElement(ui_1.IconButton, { name: "image-outline", label: "Joindre", onPress: choose, color: colors.text })));
}
const s = react_native_1.StyleSheet.create({ chatHeader: { height: 72, flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 13 }, chatTitle: { flex: 1, textAlign: 'center', fontSize: 24, fontWeight: '700' }, rainbowAction: { width: 43, height: 43, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: '#ee8d62' }, search: { height: 46, marginHorizontal: 17, marginVertical: 12, paddingHorizontal: 13, borderRadius: 13, flexDirection: 'row', alignItems: 'center', gap: 9 }, filters: { flexDirection: 'row', gap: 22, paddingHorizontal: 17, paddingBottom: 16, borderBottomWidth: 1 }, error: { padding: 10, fontSize: 11 }, chatRow: { minHeight: 89, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 13, borderBottomWidth: 1 }, chatPerson: { fontSize: 19, fontWeight: '600' }, badge: { backgroundColor: '#00b7ef', borderRadius: 15, paddingHorizontal: 7, paddingVertical: 3 }, floating: { position: 'absolute', right: 21, bottom: 20, width: 58, height: 58, borderRadius: 29, alignItems: 'center', justifyContent: 'center', backgroundColor: '#d784cf', elevation: 4 }, conversation: { flex: 1 }, convHeader: { height: 72, flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 7, borderBottomWidth: 1 }, welcome: { alignItems: 'center', gap: 14, paddingVertical: 45 }, message: { marginVertical: 10 }, messageContent: { borderLeftWidth: 2, paddingLeft: 8 }, meta: { flexDirection: 'row', gap: 8, marginTop: 7 }, msgMedia: { width: 250, height: 320, borderRadius: 10, overflow: 'hidden', backgroundColor: '#111' }, mediaPlay: { position: 'absolute', left: 107, top: 140 }, voice: { minHeight: 60, borderRadius: 11, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 4, gap: 5 }, wave: { flex: 1, height: 38, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', overflow: 'hidden' }, speed: { padding: 7, borderRadius: 5 }, voicePreview: { flexDirection: 'row', alignItems: 'center', gap: 4, padding: 8 }, recording: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 18, paddingVertical: 12 }, recDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#ff456a' }, emoji: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around', padding: 10, gap: 14 }, compose: { minHeight: 64, borderTopWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 8 }, cameraCircle: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' }, inputWrap: { flex: 1, height: 42, borderWidth: 1, borderRadius: 24, flexDirection: 'row', alignItems: 'center' } });

};

__modules["src/screens/settings"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SettingsScreen = SettingsScreen;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const api = __importStar(__load("src/api"));
const context_1 = __load("src/context");
const ui_1 = __load("src/components/ui");
const auth_1 = __load("src/screens/auth");
function SettingsScreen({ colors }) { const a = (0, context_1.useApp)(); const [config, setConfig] = (0, react_1.useState)(false); const [privacyBusy, setPrivacyBusy] = (0, react_1.useState)(false); const themes = [{ id: 'light', title: 'Clair', icon: 'sunny-outline' }, { id: 'dark', title: 'Sombre', icon: 'moon-outline' }, { id: 'system', title: 'Automatique', icon: 'phone-portrait-outline' }]; const setPrivateAccount = async (value) => { if (privacyBusy) return; setPrivacyBusy(true); await a.run(async () => { const updated = await api.updateProfile({ ...a.me, privateAccount: !!value }); a.setMe(updated); await a.refresh(); a.notify(value ? 'Compte privé activé.' : 'Compte public activé.'); }); setPrivacyBusy(false); }; return react_1.default.createElement(react_native_1.ScrollView, null,
    react_1.default.createElement(ui_1.Header, { title: "Param\u00E8tres", onBack: a.back, colors: colors }),
    react_1.default.createElement(react_native_1.View, { style: s.body },
        react_1.default.createElement(react_native_1.Text, { style: [s.h2, { color: colors.text }] }, "\u00C0 tes couleurs"),
        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted } }, "Choisis l\u2019ambiance qui te ressemble."),
        react_1.default.createElement(react_native_1.View, { style: s.themeList }, themes.map(v => react_1.default.createElement(react_native_1.Pressable, { key: v.id, onPress: () => a.setTheme(v.id), style: [s.themeRow, { backgroundColor: colors.panel, borderColor: a.theme === v.id ? colors.accent : colors.line }] },
            react_1.default.createElement(Ionicons_1.default, { name: v.icon, size: 21, color: colors.text }),
            react_1.default.createElement(react_native_1.Text, { style: { flex: 1, color: colors.text, fontWeight: '700' } }, v.title),
            a.theme === v.id && react_1.default.createElement(Ionicons_1.default, { name: "checkmark", size: 18, color: colors.accent })))),
        react_1.default.createElement(react_native_1.Text, { style: [s.h2, { color: colors.text }] }, "Données et lecture"),
        react_1.default.createElement(react_native_1.View, { style: [s.dataSaverRow, { backgroundColor: colors.panel, borderColor: colors.line }] },
            react_1.default.createElement(Ionicons_1.default, { name: "speedometer-outline", size: 22, color: colors.text }),
            react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800', fontSize: 14 } }, "Économie de données"),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 } }, "Pour les connexions lentes : charge des photos et vidéos ImageKit plus légères pour réduire les ralentissements.")),
            react_1.default.createElement(react_native_1.Switch, { value: !!a.dataSaver, onValueChange: a.setDataSaver, trackColor: { false: colors.line, true: colors.accent + '88' }, thumbColor: a.dataSaver ? colors.accent : colors.muted })),
        react_1.default.createElement(react_native_1.Text, { style: [s.h2, { color: colors.text }] }, "Ton compte"),
        !a.isGuest && react_1.default.createElement(react_native_1.View, { style: [s.dataSaverRow, { backgroundColor: colors.panel, borderColor: colors.line, opacity: privacyBusy ? .65 : 1 }] },
            react_1.default.createElement(Ionicons_1.default, { name: "lock-closed-outline", size: 22, color: colors.text }),
            react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800', fontSize: 14 } }, "Compte privé"),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 11, lineHeight: 16, marginTop: 3 } }, "Quand cette option est activée, tes publications ne sont visibles que par toi.")),
            react_1.default.createElement(react_native_1.Switch, { disabled: privacyBusy, value: !!a.me?.privateAccount, onValueChange: setPrivateAccount, trackColor: { false: colors.line, true: colors.accent + '88' }, thumbColor: a.me?.privateAccount ? colors.accent : colors.muted })),
        react_1.default.createElement(Row, { icon: "person-outline", title: "Modifier mon profil", onPress: () => a.push({ name: 'edit' }), colors: colors }),
        react_1.default.createElement(Row, { icon: "log-out-outline", title: 'Se déconnecter', danger: true, onPress: () => react_native_1.Alert.alert('Déconnexion', 'Te déconnecter de Kitty of the World ?', [{ text: 'Annuler' }, { text: 'Se déconnecter', style: 'destructive', onPress: () => a.run(a.logout) }]), colors: colors }),
        react_1.default.createElement(Row, { icon: "trash-outline", title: 'Supprimer mon compte', danger: true, onPress: () => react_native_1.Alert.alert('Supprimer mon compte', 'Ton compte, ton profil et tes publications seront supprimés définitivement. Les messages déjà envoyés peuvent rester visibles dans les conversations. Cette action est irréversible.', [{ text: 'Annuler', style: 'cancel' }, { text: 'Supprimer', style: 'destructive', onPress: () => a.run(async () => { await api.deleteAccount(); await a.logout(); }) }]), colors: colors }),
        react_1.default.createElement(react_native_1.View, { style: [s.privacy, { backgroundColor: colors.panel }] },
            react_1.default.createElement(Ionicons_1.default, { name: "shield-checkmark-outline", size: 28, color: colors.accent }),
            react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800', fontSize: 16 } }, "Un espace qui te respecte"),
            react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, lineHeight: 19, fontSize: 12 } }, "Les conversations sont r\u00E9serv\u00E9es \u00E0 leurs participants. Elles sont conserv\u00E9es : elles ne s\u2019effacent pas apr\u00E8s lecture. Les publications et les profils sont visibles aux membres."),
            react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 10 } },
                "Kitty of the World \u00B7 Expo SDK 55",
                `\n`,
                "Appels audio/vid\u00E9o et notifications hors application non inclus."))),
    react_1.default.createElement(auth_1.ConfigModal, { visible: config, onClose: () => setConfig(false), colors: colors })); }
function Row({ icon, title, onPress, colors, danger = false }) { return react_1.default.createElement(react_native_1.Pressable, { onPress: onPress, style: [s.row, { borderBottomColor: colors.line }] },
    react_1.default.createElement(Ionicons_1.default, { name: icon, size: 21, color: danger ? colors.danger : colors.text }),
    react_1.default.createElement(react_native_1.Text, { style: { flex: 1, color: danger ? colors.danger : colors.text, fontWeight: '600' } }, title),
    react_1.default.createElement(Ionicons_1.default, { name: "chevron-forward", size: 20, color: colors.muted })); }
const s = react_native_1.StyleSheet.create({ body: { paddingHorizontal: 20, paddingBottom: 35, gap: 10 }, dataSaverRow: { minHeight: 72, borderRadius: 13, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14, paddingVertical: 11, marginTop: 6 }, h2: { fontSize: 18, fontWeight: '800', marginTop: 12 }, themeList: { gap: 8, marginTop: 8, marginBottom: 15 }, themeRow: { height: 52, borderRadius: 12, borderWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 14 }, row: { height: 55, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 12 }, privacy: { borderRadius: 16, padding: 18, gap: 10, marginTop: 16 } });

};

__modules["src/screens/social"] = function(module,exports,require){
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HomeScreen = HomeScreen;
exports.NotificationsScreen = NotificationsScreen;
exports.ExploreScreen = ExploreScreen;
exports.PeopleList = PeopleList;
exports.PeopleScreen = PeopleScreen;
exports.ProfileScreen = ProfileScreen;
exports.ConnectionsScreen = ConnectionsScreen;
exports.EditProfileScreen = EditProfileScreen;
exports.CreatePostScreen = CreatePostScreen;
const react_1 = __importStar(require("react"));
const react_native_1 = require("react-native");
const Ionicons_1 = { default: require("@expo/vector-icons").Ionicons };
const ImagePicker = __importStar(require("expo-image-picker"));
const WebView_1 = { default: require("react-native-webview").WebView };
const logic_1 = __load("src/logic");
const api = __importStar(__load("src/api"));
const context_1 = __load("src/context");
const ui_1 = __load("src/components/ui");
const post_1 = __load("src/components/post");
const media_1 = __load("src/components/media");
const W = react_native_1.Dimensions.get('window').width;
function HomeScreen({ colors, enabled }) {
    const a = (0, context_1.useApp)();
    const [mode, setMode] = (0, react_1.useState)('recent');
    const [people, setPeople] = (0, react_1.useState)([]);
    const [active, setActive] = (0, react_1.useState)(0);
    const [refreshing, setRefreshing] = (0, react_1.useState)(false);
    const [refreshTick, setRefreshTick] = (0, react_1.useState)(0);

    (0, react_1.useEffect)(() => {
        api.people().then(setPeople).catch(() => {});
    }, [a.posts, a.followed]);

    const onRefresh = async () => {
        if (refreshing) return;
        setRefreshing(true);
        await a.run(async () => {
            await a.refresh();
            setPeople(await api.people());
            setRefreshTick(v => v + 1);
        });
        setRefreshing(false);
    };

    // Accueil = toutes les publications récentes des comptes suivis
    // + des publications de découverte provenant de comptes non suivis.
    const recentPosts = [...a.posts]
        // Les republications restent uniquement dans l'onglet 🥵 du profil.
        .filter(p => !p.media?.[0]?.repost?.source_post_id)
        .sort((x, y) =>
            Date.parse(y.created_at || 0) - Date.parse(x.created_at || 0)
        );
    const followedPosts = recentPosts.filter(p =>
        p.user_id === api.uid || a.followed.includes(p.user_id)
    );
    const discoveryPosts = recentPosts.filter(p =>
        p.user_id !== api.uid && !a.followed.includes(p.user_id)
    );

    const items = (() => {
        const mixed = [];
        let fi = 0;
        let di = 0;

        // On garde toutes les publications des abonnements et on insère
        // régulièrement une publication d'un compte encore non suivi.
        while (fi < followedPosts.length || di < discoveryPosts.length) {
            for (let i = 0; i < 3 && fi < followedPosts.length; i++) {
                mixed.push(followedPosts[fi++]);
            }
            if (di < discoveryPosts.length) mixed.push(discoveryPosts[di++]);

            // Si l'utilisateur ne suit encore personne, le fil reste vivant
            // grâce aux publications de découverte.
            if (!followedPosts.length && di < discoveryPosts.length) {
                mixed.push(discoveryPosts[di++]);
            }
        }

        return mixed;
    })();

    return react_1.default.createElement(
        react_native_1.FlatList,
        {
            data: items,
            keyExtractor: x => x.id + ':' + refreshTick,
            refreshing,
            onRefresh,
            progressViewOffset: 4,
            onViewableItemsChanged: ({ viewableItems }) => {
                if (viewableItems[0]?.index != null) setActive(viewableItems[0].index);
            },
            viewabilityConfig: { itemVisiblePercentThreshold: 55 },
            ListHeaderComponent: react_1.default.createElement(
                react_1.default.Fragment,
                null,
                react_1.default.createElement(
                    react_native_1.View,
                    { style: [s.homeHeader, { backgroundColor: colors.bg }] },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { numberOfLines: 1, style: [s.brandText, { color: colors.text }] },
                        "Kitty of the World"
                    ),
                    react_1.default.createElement(ui_1.IconButton, {
                        name: "add-outline",
                        label: "Nouvelle publication",
                        onPress: () => a.push({ name: 'create' }),
                        color: colors.text,
                        size: 27
                    }),
                    react_1.default.createElement(
                        react_native_1.View,
                        { style: s.notificationButton },
                        react_1.default.createElement(ui_1.IconButton, {
                            name: a.notificationUnread > 0 ? "heart" : "heart-outline",
                            label: "Notifications",
                            onPress: () => a.push({ name: 'notifications' }),
                            color: a.notificationUnread > 0 ? colors.accent : colors.text,
                            size: 25
                        }),
                        a.notificationUnread > 0 && react_1.default.createElement(
                            react_native_1.View,
                            { pointerEvents: "none", style: [s.notificationBadge, { backgroundColor: colors.danger }] },
                            react_1.default.createElement(react_native_1.Text, { style: s.notificationBadgeText }, a.notificationUnread > 99 ? '99+' : String(a.notificationUnread))
                        )
                    ),
                    react_1.default.createElement(ui_1.IconButton, {
                        name: "paper-plane-outline",
                        label: "Messages",
                        onPress: () => a.replaceTab ? a.replaceTab('chats') : a.push({ name: 'chats' }),
                        color: colors.text,
                        size: 25
                    })
                ),
                react_1.default.createElement(
                    react_native_1.View,
                    { style: [s.feedTabs, { borderBottomColor: colors.line }] },
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => setMode('recent'),
                            style: [s.feedTab, mode === 'recent' && { borderBottomColor: colors.text, borderBottomWidth: 1.5 }]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            { style: [s.feedTabText, { color: mode === 'recent' ? colors.text : colors.muted, fontWeight: mode === 'recent' ? '800' : '600' }] },
                            "Pour vous"
                        )
                    ),
                ),
                people.length > 0 && react_1.default.createElement(
                    react_native_1.ScrollView,
                    {
                        horizontal: true,
                        showsHorizontalScrollIndicator: false,
                        contentContainerStyle: [s.suggestions, { borderBottomColor: colors.line }]
                    },
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        { style: s.suggestion, onPress: () => a.push({ name: 'create' }) },
                        react_1.default.createElement(
                            react_native_1.View,
                            { style: [s.storyAvatarWrap, { backgroundColor: colors.panel }] },
                            react_1.default.createElement(ui_1.Avatar, { person: a.me, size: 57, ring: false, colors }),
                            react_1.default.createElement(
                                react_native_1.View,
                                { style: [s.storyPlus, { backgroundColor: colors.accent, borderColor: colors.bg }] },
                                react_1.default.createElement(Ionicons_1.default, { name: "add", size: 14, color: "#fff" })
                            )
                        ),
                        react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.suggestText, { color: colors.text }] }, "Votre story")
                    ),
                    people.slice(0, 10).map(p =>
                        react_1.default.createElement(
                            react_native_1.Pressable,
                            { style: s.suggestion, key: p.id, onPress: () => a.push({ name: 'profile', person: p }) },
                            react_1.default.createElement(ui_1.Avatar, { person: p, size: 61, ring: true, colors }),
                            react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.suggestText, { color: colors.text }] }, p.username)
                        )
                    )
                )
            ),
            renderItem: ({ item, index }) =>
                react_1.default.createElement(post_1.PostCard, {
                    post: item,
                    active: enabled && active === index,
                    colors,
                    onOpen: () => a.view(items, index)
                }),
            ListEmptyComponent: react_1.default.createElement(ui_1.Empty, {
                title: mode === 'following' ? 'Suis des comptes pour remplir ton fil' : 'Aucune publication pour le moment',
                body: "Publie une photo ou explore des comptes.",
                colors
            }),
            ListFooterComponent: a.hasMore ? react_1.default.createElement(
                react_native_1.Pressable,
                { style: s.loadMore, onPress: () => a.run(a.loadMore) },
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.accent, fontWeight: '700' } }, "Voir plus")
            ) : null
        }
    );
}
function NotificationsScreen({ colors }) {
    const a = (0, context_1.useApp)();
    const [items, setItems] = (0, react_1.useState)([]);
    const [refreshing, setRefreshing] = (0, react_1.useState)(false);
    const load = async () => {
        const rows = await api.likeNotifications();
        setItems(rows);
        await api.markNotificationsSeen();
        if (a.setNotificationUnread) a.setNotificationUnread(0);
    };
    (0, react_1.useEffect)(() => { a.run(load); }, []);
    const onRefresh = async () => {
        if (refreshing) return;
        setRefreshing(true);
        await a.run(load);
        setRefreshing(false);
    };
    const formatWhen = (value) => {
        const d = new Date(value || 0);
        if (Number.isNaN(d.getTime())) return '';
        try { return d.toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); }
        catch { return d.toLocaleString(); }
    };
    return react_1.default.createElement(
        react_native_1.View,
        { style: { flex: 1, backgroundColor: colors.bg } },
        react_1.default.createElement(ui_1.Header, { title: "Notifications", onBack: a.back, colors: colors }),
        react_1.default.createElement(react_native_1.FlatList, {
            data: items,
            keyExtractor: item => item.id,
            refreshing,
            onRefresh,
            renderItem: ({ item }) => react_1.default.createElement(
                react_native_1.Pressable,
                {
                    style: [s.notificationRow, { borderBottomColor: colors.line }],
                    onPress: () => a.push({ name: 'profile', person: item.actor })
                },
                react_1.default.createElement(ui_1.Avatar, { person: item.actor, size: 46, colors: colors }),
                react_1.default.createElement(
                    react_native_1.View,
                    { style: { flex: 1, minWidth: 0 } },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: [s.notificationText, { color: colors.text }] },
                        react_1.default.createElement(react_native_1.Text, { style: { fontWeight: '800' } }, '@' + (item.actor?.username || 'utilisateur')),
                        " a aimé ta publication."
                    ),
                    react_1.default.createElement(react_native_1.Text, { style: [s.notificationTime, { color: colors.muted }] }, formatWhen(item.created_at))
                ),
                react_1.default.createElement(Ionicons_1.default, { name: "heart", size: 22, color: colors.accent })
            ),
            ListEmptyComponent: react_1.default.createElement(ui_1.Empty, {
                title: "Aucune notification",
                body: "Les J’aime reçus sur tes publications apparaîtront ici.",
                colors,
                icon: "heart-outline"
            })
        })
    );
}

function ExploreScreen({ colors, initialQuery = '' }) {
    const a = (0, context_1.useApp)();
    const [query, setQuery] = (0, react_1.useState)(initialQuery);
    const [mode, setMode] = (0, react_1.useState)('popular');
    const [people, setPeople] = (0, react_1.useState)([]);
    const [refreshing, setRefreshing] = (0, react_1.useState)(false);
    const [refreshTick, setRefreshTick] = (0, react_1.useState)(0);

    (0, react_1.useEffect)(() => setQuery(initialQuery), [initialQuery]);
    (0, react_1.useEffect)(() => {
        const t = setTimeout(() => {
            api.people(query.replace(/^@/, '')).then(setPeople).catch(() => {});
        }, 220);
        return () => clearTimeout(t);
    }, [query, a.followed]);

    const onRefresh = async () => {
        if (refreshing) return;
        setRefreshing(true);
        await a.run(async () => {
            await a.refresh();
            setPeople(await api.people(query.replace(/^@/, '')));
            setRefreshTick(v => v + 1);
        });
        setRefreshing(false);
    };

    const items = (0, react_1.useMemo)(() => {
        const filtered = a.posts.filter(p =>
            !p.media?.[0]?.repost?.source_post_id &&
            ((p.caption || '') + ' ' + (p.owner?.username || '')).toLowerCase().includes(query.toLowerCase())
        );
        return (0, logic_1.sortPosts)(filtered, mode === 'popular' ? 'popular' : 'recent');
    }, [a.posts, query, mode, refreshTick]);

    return react_1.default.createElement(
        react_native_1.ScrollView,
        {
            style: { flex: 1 },
            keyboardShouldPersistTaps: "handled",
            refreshControl: react_1.default.createElement(react_native_1.RefreshControl, {
                refreshing,
                onRefresh,
                tintColor: colors.text,
                colors: [colors.accent]
            })
        },
        react_1.default.createElement(
            react_native_1.View,
            { style: [s.exploreTop, { backgroundColor: colors.bg }] },
            react_1.default.createElement(SearchBox, { value: query, setValue: setQuery, colors }),
            react_1.default.createElement(Ionicons_1.default, { name: "ellipsis-horizontal", size: 22, color: colors.text })
        ),
        react_1.default.createElement(
            react_native_1.View,
            { style: [s.exploreTabs, { borderBottomColor: colors.line }] },
            [
                ['popular', 'Pour vous'],
                ['recent', 'Récentes'],
                ['people', 'Comptes']
            ].map(([id, title]) =>
                react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        key: id,
                        onPress: () => setMode(id),
                        style: [s.exploreTab, mode === id && { borderBottomColor: colors.text, borderBottomWidth: 1.5 }]
                    },
                    react_1.default.createElement(
                        react_native_1.Text,
                        {
                            style: {
                                color: mode === id ? colors.text : colors.muted,
                                fontWeight: mode === id ? '800' : '600',
                                fontSize: 12
                            }
                        },
                        title
                    )
                )
            )
        ),
        mode === 'people'
            ? react_1.default.createElement(PeopleList, { people, colors })
            : react_1.default.createElement(Grid, { posts: items, colors, onPress: i => a.view(items, i) }),
        mode !== 'people' && a.hasMore && react_1.default.createElement(
            react_native_1.Pressable,
            { style: s.loadMore, onPress: () => a.run(a.loadMore) },
            react_1.default.createElement(react_native_1.Text, { style: { color: colors.accent, fontWeight: '700' } }, "Voir plus")
        )
    );
}
function SearchBox({ value, setValue, colors }) {
    return react_1.default.createElement(
        react_native_1.View,
        { style: [s.search, { backgroundColor: colors.panel }] },
        react_1.default.createElement(Ionicons_1.default, { name: "search", size: 18, color: colors.muted }),
        react_1.default.createElement(react_native_1.TextInput, {
            value,
            onChangeText: setValue,
            placeholder: "Rechercher",
            placeholderTextColor: colors.muted,
            style: [s.searchInput, { color: colors.text }]
        }),
        !!value && react_1.default.createElement(
            react_native_1.Pressable,
            { onPress: () => setValue(''), style: s.searchClear },
            react_1.default.createElement(Ionicons_1.default, { name: "close-circle", size: 18, color: colors.muted })
        )
    );
}
function Grid({ posts, colors, onPress, emptyTitle = 'Aucune publication', emptyBody = 'Publie ta première photo ou vidéo.' }) {
    const screen = react_native_1.useWindowDimensions();
    const [measuredWidth, setMeasuredWidth] = (0, react_1.useState)(0);
    const width = Math.floor(((measuredWidth || screen.width) - 4) / 3);
    if (!posts.length) return react_1.default.createElement(ui_1.Empty, { title: emptyTitle, body: emptyBody, colors });
    return react_1.default.createElement(
        react_native_1.View,
        { style: s.grid, onLayout: e => setMeasuredWidth(e.nativeEvent.layout.width) },
        posts.map((p, i) =>
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    key: p.id,
                    testID: 'post-tile-' + p.id,
                    style: [s.tile, { width, height: width, backgroundColor: colors.panel }],
                    onPress: () => onPress(i)
                },
                react_1.default.createElement(
                    react_native_1.View,
                    { pointerEvents: 'none', style: react_native_1.StyleSheet.absoluteFill },
                    react_1.default.createElement(GridMedia, { post: p, colors })
                ),
                p.media.length > 1 && react_1.default.createElement(
                    react_native_1.View,
                    { style: s.gridTag },
                    react_1.default.createElement(Ionicons_1.default, { name: 'copy-outline', size: 16, color: '#fff' })
                )
            )
        )
    );
}

function GridMedia({ post, colors }) {
    const m = post.media[0];
    if (!m) return null;
    if (m.type === 'image')
        return react_1.default.createElement(media_1.MediaItem, { media: m, active: false, colors, fit: 'cover' });
    if (m.poster)
        return react_1.default.createElement(react_native_1.Image, {
            source: (0, logic_1.sourceFor)(m.poster),
            style: react_native_1.StyleSheet.absoluteFill,
            resizeMode: "cover"
        });
    if (m.type === 'video')
        return react_1.default.createElement(
            react_native_1.View,
            { style: react_native_1.StyleSheet.absoluteFill },
            react_1.default.createElement(media_1.NativeVideo, {
                uri: typeof m.url === 'string' ? m.url : '',
                active: false,
                controls: false,
                colors,
                fit: 'cover'
            }),
            react_1.default.createElement(Ionicons_1.default, { name: "play", size: 15, color: "#fff", style: s.playTag })
        );
    return react_1.default.createElement(
        react_native_1.View,
        { pointerEvents: "none", style: react_native_1.StyleSheet.absoluteFill },
        react_1.default.createElement(media_1.MediaItem, { media: m, active: true, full: false, colors, fit: 'cover' }),
        react_1.default.createElement(Ionicons_1.default, {
            name: "play-circle",
            size: 17,
            color: "#fff",
            style: s.playTag
        })
    );
}
function PeopleList({ people, colors, chat = false }) { const a = (0, context_1.useApp)(); if (!people.length)
    return react_1.default.createElement(ui_1.Empty, { title: "Aucun compte trouv\u00E9", body: "Les comptes appara\u00EEtront ici apr\u00E8s leur inscription.", colors: colors }); return react_1.default.createElement(react_native_1.View, null, people.map(p => react_1.default.createElement(react_native_1.Pressable, { key: p.id, style: [s.personRow, { borderBottomColor: colors.line }], onPress: () => chat ? a.run(async () => { const thread = await api.openThread(p); a.push({ name: 'conversation', thread }); }) : a.push({ name: 'profile', person: p }) },
    react_1.default.createElement(ui_1.Avatar, { person: p, colors: colors }),
    react_1.default.createElement(react_native_1.View, { style: { flex: 1 } },
        react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontWeight: '800' } }, p.name || p.username),
        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, fontSize: 12, marginTop: 3 } },
            "@",
            p.username)),
    react_1.default.createElement(Ionicons_1.default, { name: "chevron-forward", size: 22, color: colors.muted })))); }
function PeopleScreen({ colors }) { const a = (0, context_1.useApp)(); const [q, setQ] = (0, react_1.useState)(''); const [people, setPeople] = (0, react_1.useState)([]); (0, react_1.useEffect)(() => { const t = setTimeout(() => api.people(q).then(setPeople).catch(e => a.notify(e.message)), 200); return () => clearTimeout(t); }, [q]); return react_1.default.createElement(react_native_1.ScrollView, null,
    react_1.default.createElement(ui_1.Header, { title: "Nouveau chat", onBack: a.back, colors: colors }),
    react_1.default.createElement(SearchBox, { value: q, setValue: setQ, colors: colors }),
    react_1.default.createElement(PeopleList, { people: people, colors: colors, chat: true })); }
function ProfileSuggestions({ people, colors, app, dismissed, onDismiss }) {
    const visible = people.filter(p => !dismissed.includes(p.id)).slice(0, 8);
    if (!visible.length) return null;
    return react_1.default.createElement(
        react_native_1.View,
        { style: s.profileSuggestions },
        react_1.default.createElement(
            react_native_1.View,
            { style: s.profileSuggestHead },
            react_1.default.createElement(
                react_native_1.Text,
                { style: [s.profileSuggestTitle, { color: colors.text }] },
                "Suivez des comptes pour démarrer"
            ),
            react_1.default.createElement(
                react_native_1.Pressable,
                { onPress: () => app.push({ name: 'people' }) },
                react_1.default.createElement(
                    react_native_1.Text,
                    { style: { color: colors.accent, fontSize: 12, fontWeight: '700' } },
                    "Voir tout"
                )
            )
        ),
        react_1.default.createElement(
            react_native_1.ScrollView,
            {
                horizontal: true,
                showsHorizontalScrollIndicator: false,
                contentContainerStyle: s.profileSuggestList
            },
            visible.map(person => {
                const followed = app.followed.includes(person.id);
                return react_1.default.createElement(
                    react_native_1.View,
                    {
                        key: person.id,
                        style: [s.profileSuggestCard, { backgroundColor: colors.panel, borderColor: colors.line }]
                    },
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        { onPress: () => onDismiss(person.id), style: s.profileSuggestClose },
                        react_1.default.createElement(Ionicons_1.default, { name: "close", size: 18, color: colors.muted })
                    ),
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        { onPress: () => app.push({ name: 'profile', person }) },
                        react_1.default.createElement(ui_1.Avatar, { person, size: 77, ring: false, colors })
                    ),
                    react_1.default.createElement(
                        react_native_1.Text,
                        { numberOfLines: 1, style: [s.profileSuggestUser, { color: colors.text }] },
                        person.username
                    ),
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: [s.profileSuggestMeta, { color: colors.muted }] },
                        "Suggestions"
                    ),
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => app.run(async () => {
                                await api.follow(person.id);
                                await app.refresh();
                            }),
                            style: [
                                s.profileSuggestFollow,
                                {
                                    backgroundColor: followed ? '#30353d' : colors.accent,
                                    borderColor: followed ? colors.line : colors.accent
                                }
                            ]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            { style: { color: '#fff', fontSize: 12, fontWeight: '800' } },
                            followed ? "Suivi(e)" : "Suivre"
                        )
                    )
                );
            })
        )
    );
}

function profileBannerMedia(raw) {
    if (!raw) return null;
    try {
        return logic_1.parseEmbeds(String(raw))[0] || null;
    }
    catch {
        return null;
    }
}
function mutedBannerEmbedUrl(raw) {
    const url = String(raw || '');
    const join = url.includes('?') ? '&' : '?';
    if (/youtube(?:-nocookie)?\.com\/embed\//i.test(url)) return url + join + 'autoplay=1&mute=1&playsinline=1&controls=0&loop=1';
    if (/player\.vimeo\.com\/video\//i.test(url)) return url + join + 'autoplay=1&muted=1&background=1&playsinline=1';
    if (/dailymotion\.com\/embed\/video\//i.test(url)) return url + join + 'autoplay=1&mute=1&ui-start-screen-info=0';
    return url;
}
function ProfileBannerMedia({ raw, position = 50, colors }) {
    const media = (0, react_1.useMemo)(() => profileBannerMedia(raw), [raw]);
    if (!media) return null;
    const y = Math.max(0, Math.min(100, Number(position) || 50));
    const movingStyle = [s.profileBannerMoving, { top: `${-(y * .40)}%` }];
    if (media.type === 'image') {
        return react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: movingStyle },
            react_1.default.createElement(media_1.MediaItem, { media: { type: 'image', url: media.url }, active: true, full: false, colors: colors, fit: 'cover' }));
    }
    if (media.type === 'video') {
        return react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: movingStyle },
            react_1.default.createElement(media_1.NativeVideo, { uri: logic_1.uriFor(media.url), active: true, full: false, controls: false, colors: colors, fit: "cover" }));
    }
    const injected = `(() => { const mute = () => { document.querySelectorAll('video,audio').forEach(m => { try { m.muted = true; m.volume = 0; m.autoplay = true; m.setAttribute('muted',''); m.setAttribute('playsinline',''); const p = m.play && m.play(); if (p && p.catch) p.catch(() => {}); } catch(e) {} }); }; mute(); setInterval(mute, 700); true; })();`;
    return react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: movingStyle },
        react_1.default.createElement(WebView_1.default, {
            source: { uri: mutedBannerEmbedUrl(media.url) },
            style: { flex: 1, backgroundColor: '#000' },
            containerStyle: { flex: 1 },
            javaScriptEnabled: true,
            domStorageEnabled: true,
            allowsInlineMediaPlayback: true,
            allowsFullscreenVideo: false,
            mediaPlaybackRequiresUserAction: false,
            scrollEnabled: false,
            bounces: false,
            injectedJavaScript: injected,
            injectedJavaScriptBeforeContentLoaded: injected,
            originWhitelist: ['https://*', 'http://*']
        }));
}
function ProfileScreen({ person, colors }) {
    const a = (0, context_1.useApp)();
    const p = !person || person.id === a.me.id ? a.me : person;
    const own = p.id === a.me.id;
    const [mode, setMode] = (0, react_1.useState)('posts');
    const [stats, setStats] = (0, react_1.useState)({ posts: 0, followers: 0, following: 0 });
    const [snapshot, setSnapshot] = (0, react_1.useState)({ key: '', items: [] });
    const [refreshing, setRefreshing] = (0, react_1.useState)(false);
    const [tick, setTick] = (0, react_1.useState)(0);
    const [hasMore, setHasMore] = (0, react_1.useState)(false);
    const [loadingMore, setLoadingMore] = (0, react_1.useState)(false);
    const [suggested, setSuggested] = (0, react_1.useState)([]);
    const [dismissed, setDismissed] = (0, react_1.useState)([]);
    const offset = (0, react_1.useRef)(0);
    const request = (0, react_1.useRef)(0);
    const key = p.id + ':' + mode;
    const select = list => mode === 'activity'
        ? logic_1.profileActivityItems(list, api.uid)
        : logic_1.profileItems(list, p.id, false, api.uid);
    const fetchItems = offset => mode === 'activity'
        ? api.profileActivity(offset)
        : api.profilePosts(p.id, false, offset);
    const mergedItems = logic_1.mergePosts(a.posts, snapshot.key === key ? snapshot.items : []);
    const liveItems = select(mergedItems);

    (0, react_1.useEffect)(() => {
        const ticket = ++request.current;
        setLoadingMore(false);
        api.stats(p.id)
            .then(value => { if (ticket === request.current) setStats(value); })
            .catch(e => a.notify(e.message));
        fetchItems(0)
            .then(remote => {
                if (ticket !== request.current) return;
                setSnapshot({ key, items: remote });
                offset.current = remote.length;
                setHasMore(remote.length === 30);
            })
            .catch(e => a.notify(e.message));
        return () => { request.current++; };
    }, [key, tick, a.posts, a.followed]);

    (0, react_1.useEffect)(() => {
        let live = true;
        if (!own) {
            setSuggested([]);
            return () => { live = false; };
        }
        api.people()
            .then(rows => {
                if (live) setSuggested((rows || []).filter(x => x.id !== p.id));
            })
            .catch(() => {});
        return () => { live = false; };
    }, [own, p.id, tick, a.followed.length, a.posts.length]);

    const onRefresh = async () => {
        if (refreshing) return;
        setRefreshing(true);
        await a.run(a.refresh);
        setTick(v => v + 1);
        setRefreshing(false);
    };

    const loadMore = async () => {
        if (loadingMore || !hasMore) return;
        setLoadingMore(true);
        const ticket = request.current;
        try {
            const remote = await fetchItems(offset.current);
            if (ticket !== request.current) return;
            offset.current += remote.length;
            setHasMore(remote.length === 30);
            setSnapshot(v => ({
                key,
                items: logic_1.mergePosts(v.key === key ? v.items : [], remote)
            }));
        } catch (e) {
            a.notify(e.message);
        } finally {
            if (ticket === request.current) setLoadingMore(false);
        }
    };

    const postCount = Math.max(stats.posts, mode === 'posts' ? liveItems.length : 0);
    const bannerMedia = profileBannerMedia(p.banner);
    const hasBanner = !!bannerMedia;
    const heroText = hasBanner ? '#fff' : colors.text;
    const heroMuted = hasBanner ? '#e2e5ea' : colors.muted;
    const heroAccent = hasBanner ? '#8eb6ff' : colors.accent;
    const heroLine = hasBanner ? '#ffffff66' : colors.line;

    return react_1.default.createElement(
        react_native_1.ScrollView,
        {
            style: { flex: 1, backgroundColor: colors.bg },
            showsVerticalScrollIndicator: false,
            refreshControl: react_1.default.createElement(react_native_1.RefreshControl, {
                refreshing,
                onRefresh,
                tintColor: colors.text,
                colors: [colors.accent]
            })
        },

        react_1.default.createElement(
            react_native_1.View,
            { style: [s.profileHero, { backgroundColor: colors.bg }, hasBanner && s.profileHeroWithBanner] },
            hasBanner && react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: s.profileBannerLayer },
                react_1.default.createElement(ProfileBannerMedia, { raw: p.banner, position: p.bannerPosition, colors: colors })),
            hasBanner && react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: s.profileBannerShade }),

            react_1.default.createElement(
                react_native_1.View,
                { style: [s.profileHeader, { backgroundColor: 'transparent' }] },
                own
                    ? react_1.default.createElement(react_native_1.View, { style: { width: 42, height: 42 } })
                    : react_1.default.createElement(ui_1.IconButton, {
                        name: "chevron-back",
                        label: "Retour",
                        onPress: a.back,
                        color: heroText,
                        size: 25
                    }),
                react_1.default.createElement(
                    react_native_1.View,
                    { style: s.profileTitleWrap },
                    react_1.default.createElement(
                        react_native_1.Text,
                        { numberOfLines: 1, style: [s.profileName, { color: heroText }] },
                        p.username
                    ),
                    own && react_1.default.createElement(Ionicons_1.default, {
                        name: "chevron-down",
                        size: 14,
                        color: heroMuted,
                        style: { marginTop: 2 }
                    })
                ),
                own
                    ? react_1.default.createElement(
                        react_native_1.View,
                        { style: s.profileHeaderRight },
                        react_1.default.createElement(ui_1.IconButton, {
                            name: "menu-outline",
                            label: "Paramètres",
                            onPress: () => a.push({ name: 'settings' }),
                            color: heroText,
                            size: 28
                        })
                    )
                    : react_1.default.createElement(ui_1.IconButton, {
                        name: "ellipsis-horizontal",
                        label: "Plus",
                        onPress: () => {},
                        color: heroText,
                        size: 24
                    })
            ),

            react_1.default.createElement(
                react_native_1.View,
                { style: s.profileTop },
                react_1.default.createElement(react_native_1.View, { style: hasBanner ? s.profileAvatarOnBanner : null },
                    react_1.default.createElement(ui_1.Avatar, {
                        person: p,
                        size: 66,
                        ring: false,
                        colors
                    })),
                !hasBanner && react_1.default.createElement(
                    react_native_1.View,
                    { style: s.profileIdentity },
                    react_1.default.createElement(
                        react_native_1.View,
                        { style: s.stats },
                        [
                            ['publications', postCount, null],
                            ['follower', stats.followers, 'followers'],
                            ['suivi(e)s', stats.following, 'following']
                        ].map(([label, n, connectionMode]) => {
                            const Component = connectionMode ? react_native_1.Pressable : react_native_1.View;
                            return react_1.default.createElement(
                                Component,
                                {
                                    key: label,
                                    style: s.stat,
                                    onPress: connectionMode ? () => a.push({ name: 'connections', person: p, mode: connectionMode }) : undefined,
                                    accessibilityRole: connectionMode ? 'button' : undefined,
                                    accessibilityLabel: connectionMode === 'followers' ? 'Voir les abonnés' : connectionMode === 'following' ? 'Voir les abonnements' : undefined
                                },
                                react_1.default.createElement(react_native_1.Text, { style: [s.statN, { color: heroText }] }, n),
                                react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.statLabel, { color: heroText }] }, label)
                            );
                        })
                    )
                )
            ),

            react_1.default.createElement(
                react_native_1.View,
                { style: s.bio },
                !!p.bio && react_1.default.createElement(
                    react_native_1.Text,
                    { style: [s.bioText, { color: heroText }] },
                    p.bio
                ),
                !!(0, logic_1.safeUrl)(p.website || '') && react_1.default.createElement(
                    react_native_1.Pressable,
                    { onPress: () => react_native_1.Linking.openURL(p.website), style: s.web },
                    react_1.default.createElement(Ionicons_1.default, { name: "link", size: 13, color: heroAccent }),
                    react_1.default.createElement(react_native_1.Text, { style: { color: heroAccent, fontSize: 12 } }, new StandardURL(p.website).hostname)
                ),
            ),

            hasBanner && react_1.default.createElement(
                react_native_1.View,
                { style: s.statsBannerBottom },
                [
                    ['publications', postCount, null],
                    ['follower', stats.followers, 'followers'],
                    ['suivi(e)s', stats.following, 'following']
                ].map(([label, n, connectionMode]) => {
                    const Component = connectionMode ? react_native_1.Pressable : react_native_1.View;
                    return react_1.default.createElement(
                        Component,
                        {
                            key: label,
                            style: s.stat,
                            onPress: connectionMode ? () => a.push({ name: 'connections', person: p, mode: connectionMode }) : undefined,
                            accessibilityRole: connectionMode ? 'button' : undefined,
                            accessibilityLabel: connectionMode === 'followers' ? 'Voir les abonnés' : connectionMode === 'following' ? 'Voir les abonnements' : undefined
                        },
                        react_1.default.createElement(react_native_1.Text, { style: [s.statN, { color: heroText }] }, n),
                        react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.statLabel, { color: heroText }] }, label)
                    );
                })
            )
        ),

        react_1.default.createElement(
            react_native_1.View,
            { style: s.profileButtons },
            own
                ? react_1.default.createElement(
                    react_1.default.Fragment,
                    null,
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => a.push({ name: 'edit' }),
                            style: [s.profileAction, { backgroundColor: colors.panel, borderColor: colors.panel }]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            { style: [s.profileActionText, { color: colors.text }] },
                            "Modifier le profil"
                        )
                    ),
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => react_native_1.Share.share({
                                message: '@' + p.username + (p.bio ? '\n' + p.bio : '')
                            }).catch(() => {}),
                            style: [s.profileAction, { backgroundColor: colors.panel, borderColor: colors.panel }]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            { style: [s.profileActionText, { color: colors.text }] },
                            "Partager le profil"
                        )
                    ),
                )
                : react_1.default.createElement(
                    react_1.default.Fragment,
                    null,
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => a.run(async () => {
                                await api.follow(p.id);
                                await a.refresh();
                            }),
                            style: [
                                s.profileAction,
                                {
                                    backgroundColor: a.followed.includes(p.id) ? colors.panel : colors.accent,
                                    borderColor: a.followed.includes(p.id) ? colors.panel : colors.accent
                                }
                            ]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            {
                                style: [
                                    s.profileActionText,
                                    { color: a.followed.includes(p.id) ? colors.text : '#fff' }
                                ]
                            },
                            a.followed.includes(p.id) ? "Suivi(e)" : "Suivre"
                        )
                    ),
                    react_1.default.createElement(
                        react_native_1.Pressable,
                        {
                            onPress: () => a.run(async () => {
                                const thread = await api.openThread(p);
                                a.push({ name: 'conversation', thread });
                            }),
                            style: [s.profileAction, { backgroundColor: colors.panel, borderColor: colors.panel }]
                        },
                        react_1.default.createElement(
                            react_native_1.Text,
                            { style: [s.profileActionText, { color: colors.text }] },
                            "Message"
                        )
                    )
                )
        ),

        own && react_1.default.createElement(ProfileSuggestions, {
            people: suggested,
            colors,
            app: a,
            dismissed,
            onDismiss: id => setDismissed(v => v.includes(id) ? v : [...v, id])
        }),

        react_1.default.createElement(
            react_native_1.View,
            { style: [s.profileTabs, { borderBottomColor: colors.line }] },
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    onPress: () => setMode('posts'),
                    style: [s.profileTab, mode === 'posts' && { borderBottomWidth: 1.5, borderBottomColor: colors.text }]
                },
                react_1.default.createElement(Ionicons_1.default, {
                    name: "grid",
                    size: 21,
                    color: mode === 'posts' ? colors.text : colors.muted
                })
            ),
            own && react_1.default.createElement(
                react_native_1.Pressable,
                {
                    accessibilityRole: 'tab',
                    accessibilityLabel: '🥵 Vidéos aimées et republications',
                    accessibilityState: { selected: mode === 'activity' },
                    onPress: () => setMode('activity'),
                    style: [s.profileTab, mode === 'activity' && { borderBottomWidth: 1.5, borderBottomColor: colors.text }]
                },
                react_1.default.createElement(
                    react_native_1.Text,
                    { style: { fontSize: 21, opacity: mode === 'activity' ? 1 : .48 } },
                    '🥵'
                )
            )
        ),

        liveItems.length
            ? react_1.default.createElement(Grid, {
                posts: liveItems,
                colors,
                onPress: i => a.view(liveItems, i)
            })
            : react_1.default.createElement(
                react_native_1.View,
                { style: s.profileEmpty },
                react_1.default.createElement(
                    react_native_1.Text,
                    { style: [s.profileEmptyTitle, { color: colors.text }] },
                    !own && p.privateAccount && mode === 'posts' ? 'Compte privé' : mode === 'activity' ? '🥵' : 'Créez votre première publication'
                ),
                react_1.default.createElement(
                    react_native_1.Text,
                    { style: [s.profileEmptyBody, { color: colors.muted }] },
                    !own && p.privateAccount && mode === 'posts'
                        ? 'Les publications de ce compte ne sont pas visibles.'
                        : mode === 'activity'
                            ? 'Tes vidéos aimées et tes republications apparaîtront ici.'
                            : 'Appropriez-vous cet espace.'
                )
            ),

        hasMore && react_1.default.createElement(
            react_native_1.Pressable,
            { onPress: loadMore, style: s.loadMore },
            react_1.default.createElement(
                react_native_1.Text,
                { style: { color: colors.accent, fontWeight: '700' } },
                loadingMore ? 'Chargement…' : 'Voir plus de publications'
            )
        )
    );
}

function ConnectionsScreen({ person, initialMode = 'followers', colors }) {
    const a = (0, context_1.useApp)();
    const p = !person || person.id === a.me.id ? a.me : person;
    const [mode, setMode] = (0, react_1.useState)(initialMode === 'following' ? 'following' : 'followers');
    const [followers, setFollowers] = (0, react_1.useState)([]);
    const [following, setFollowing] = (0, react_1.useState)([]);
    const [query, setQuery] = (0, react_1.useState)('');
    const [loading, setLoading] = (0, react_1.useState)(true);
    const [refreshing, setRefreshing] = (0, react_1.useState)(false);
    const [tick, setTick] = (0, react_1.useState)(0);

    const load = (0, react_1.useCallback)(async () => {
        const [f1, f2] = await Promise.all([api.followersOf(p.id), api.followingOf(p.id)]);
        setFollowers(f1 || []);
        setFollowing(f2 || []);
    }, [p.id]);

    (0, react_1.useEffect)(() => {
        let live = true;
        setLoading(true);
        Promise.all([api.followersOf(p.id), api.followingOf(p.id)])
            .then(([f1, f2]) => {
                if (!live) return;
                setFollowers(f1 || []);
                setFollowing(f2 || []);
            })
            .catch(e => a.notify(e.message))
            .finally(() => { if (live) setLoading(false); });
        return () => { live = false; };
    }, [p.id, tick]);

    const source = mode === 'followers' ? followers : following;
    const needle = query.trim().toLowerCase().replace(/^@/, '');
    const rows = !needle ? source : source.filter(x => ((x.username || '') + ' ' + (x.name || '')).toLowerCase().includes(needle));

    const refresh = async () => {
        if (refreshing) return;
        setRefreshing(true);
        try {
            await a.refresh();
            await load();
        } catch (e) { a.notify(e.message); }
        setRefreshing(false);
    };

    const toggleFollow = async person => {
        await a.run(async () => {
            await api.follow(person.id);
            await a.refresh();
            setTick(v => v + 1);
        });
    };

    const renderPerson = ({ item }) => {
        const mine = item.id === a.me.id;
        const followed = a.followed.includes(item.id);
        return react_1.default.createElement(
            react_native_1.View,
            { style: s.connectionRow },
            react_1.default.createElement(
                react_native_1.Pressable,
                { onPress: () => a.push({ name: 'profile', person: item }), style: s.connectionIdentity },
                react_1.default.createElement(ui_1.Avatar, { person: item, size: 52, ring: false, colors }),
                react_1.default.createElement(
                    react_native_1.View,
                    { style: { flex: 1, minWidth: 0 } },
                    react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.connectionUser, { color: colors.text }] }, item.username || 'utilisateur'),
                    !!item.name && item.name !== item.username && react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.connectionName, { color: colors.muted }] }, item.name)
                )
            ),
            !mine && react_1.default.createElement(
                react_native_1.Pressable,
                {
                    onPress: () => toggleFollow(item),
                    style: [s.connectionFollow, { backgroundColor: followed ? colors.panel : '#4158e8', borderColor: followed ? colors.line : '#4158e8' }]
                },
                react_1.default.createElement(react_native_1.Text, { style: { color: followed ? colors.text : '#fff', fontSize: 12.5, fontWeight: '800' } }, followed ? 'Suivi(e)' : 'Suivre')
            )
        );
    };

    return react_1.default.createElement(
        react_native_1.View,
        { style: { flex: 1, backgroundColor: colors.bg } },
        react_1.default.createElement(
            react_native_1.View,
            { style: s.connectionsHeader },
            react_1.default.createElement(ui_1.IconButton, { name: 'arrow-back', label: 'Retour', onPress: a.back, color: colors.text, size: 26 }),
            react_1.default.createElement(react_native_1.Text, { numberOfLines: 1, style: [s.connectionsTitle, { color: colors.text }] }, p.username || 'Profil'),
            react_1.default.createElement(react_native_1.View, { style: { width: 42 } })
        ),
        react_1.default.createElement(
            react_native_1.View,
            { style: [s.connectionsTabs, { borderBottomColor: colors.line }] },
            react_1.default.createElement(
                react_native_1.Pressable,
                { onPress: () => setMode('followers'), style: [s.connectionsTab, mode === 'followers' && { borderBottomColor: colors.text, borderBottomWidth: 2 }] },
                react_1.default.createElement(react_native_1.Text, { style: [s.connectionsTabText, { color: mode === 'followers' ? colors.text : colors.muted }] }, followers.length + ' Abonnés')
            ),
            react_1.default.createElement(
                react_native_1.Pressable,
                { onPress: () => setMode('following'), style: [s.connectionsTab, mode === 'following' && { borderBottomColor: colors.text, borderBottomWidth: 2 }] },
                react_1.default.createElement(react_native_1.Text, { style: [s.connectionsTabText, { color: mode === 'following' ? colors.text : colors.muted }] }, following.length + ' Abonnements')
            )
        ),
        react_1.default.createElement(
            react_native_1.View,
            { style: [s.connectionsSearch, { backgroundColor: colors.panel }] },
            react_1.default.createElement(Ionicons_1.default, { name: 'search', size: 18, color: colors.muted }),
            react_1.default.createElement(react_native_1.TextInput, {
                value: query,
                onChangeText: setQuery,
                placeholder: 'Rechercher',
                placeholderTextColor: colors.muted,
                autoCapitalize: 'none',
                style: [s.connectionsSearchInput, { color: colors.text }]
            }),
            !!query && react_1.default.createElement(react_native_1.Pressable, { onPress: () => setQuery(''), style: { padding: 5 } }, react_1.default.createElement(Ionicons_1.default, { name: 'close-circle', size: 18, color: colors.muted }))
        ),
        loading
            ? react_1.default.createElement(react_native_1.View, { style: { flex: 1, alignItems: 'center', justifyContent: 'center' } }, react_1.default.createElement(react_native_1.ActivityIndicator, { color: colors.accent }))
            : react_1.default.createElement(react_native_1.FlatList, {
                data: rows,
                keyExtractor: x => x.id,
                renderItem: renderPerson,
                refreshing,
                onRefresh: refresh,
                keyboardShouldPersistTaps: 'handled',
                showsVerticalScrollIndicator: false,
                contentContainerStyle: rows.length ? { paddingBottom: 25 } : { flexGrow: 1 },
                ListEmptyComponent: react_1.default.createElement(
                    react_native_1.View,
                    { style: s.connectionsEmpty },
                    react_1.default.createElement(Ionicons_1.default, { name: mode === 'followers' ? 'people-outline' : 'person-add-outline', size: 42, color: colors.muted }),
                    react_1.default.createElement(react_native_1.Text, { style: [s.connectionsEmptyTitle, { color: colors.text }] }, query ? 'Aucun compte trouvé' : mode === 'followers' ? 'Aucun abonné pour le moment' : 'Aucun abonnement pour le moment')
                )
            })
    );
}

function EditProfileScreen({ colors }) {
    const a = (0, context_1.useApp)();
    const [p, setP] = (0, react_1.useState)({ ...a.me, banner: a.me.banner || '', bannerPosition: Number(a.me.bannerPosition ?? 50) });
    const [busy, setBusy] = (0, react_1.useState)(false);
    const bannerPreview = (0, react_1.useMemo)(() => profileBannerMedia(p.banner), [p.banner]);
    const pickAvatar = async () => {
        if (a.isGuest) { a.notify('Le transfert de médias depuis le téléphone est réservé aux comptes inscrits.'); return; }
        const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: .9 });
        if (r.canceled) return;
        const x = r.assets[0];
        setBusy(true);
        await a.run(async () => {
            const avatar = await api.upload({ uri: x.uri, mimeType: x.mimeType || 'image/jpeg', fileName: x.fileName || 'avatar.jpg', fileSize: x.fileSize }, () => {});
            setP(v => ({ ...v, avatar }));
        });
        setBusy(false);
    };
    const shiftBanner = amount => setP(v => ({ ...v, bannerPosition: Math.max(0, Math.min(100, Number(v.bannerPosition ?? 50) + amount)) }));
    return react_1.default.createElement(react_native_1.ScrollView, { keyboardShouldPersistTaps: "handled", showsVerticalScrollIndicator: false },
        react_1.default.createElement(ui_1.Header, { title: "Modifier le profil", onBack: a.back, colors: colors }),
        react_1.default.createElement(react_native_1.View, { style: s.form },
            react_1.default.createElement(react_native_1.Pressable, { onPress: pickAvatar, style: s.avatarEdit },
                react_1.default.createElement(ui_1.Avatar, { person: p, size: 92, ring: true, colors: colors }),
                react_1.default.createElement(react_native_1.Text, { style: { color: colors.accent, marginTop: 8, fontWeight: '700' } }, busy ? 'Transfert…' : 'Changer la photo')),

            react_1.default.createElement(react_native_1.View, { style: s.bannerEditor },
                react_1.default.createElement(react_native_1.Text, { style: [s.bannerEditorTitle, { color: colors.text }] }, "Bannière du profil"),
                react_1.default.createElement(react_native_1.Text, { style: [s.bannerEditorHint, { color: colors.muted }] }, "Photo ou vidéo par URL, iframe ou BBCode uniquement. Les vidéos sont lues sans son."),
                react_1.default.createElement(react_native_1.TextInput, {
                    value: p.banner || '',
                    onChangeText: value => setP(v => ({ ...v, banner: value })),
                    placeholder: "https://... ou <iframe ...> ou [img]...[/img]",
                    placeholderTextColor: colors.muted,
                    multiline: true,
                    autoCapitalize: "none",
                    autoCorrect: false,
                    style: [s.bannerInput, { color: colors.text, backgroundColor: colors.panel, borderColor: colors.line }]
                }),
                !!p.banner && !bannerPreview && react_1.default.createElement(react_native_1.Text, { style: { color: colors.danger, fontSize: 11 } }, "Lien / iframe / BBCode non reconnu."),
                !!bannerPreview && react_1.default.createElement(react_1.default.Fragment, null,
                    react_1.default.createElement(react_native_1.View, { style: [s.bannerEditorPreview, { backgroundColor: '#000' }] },
                        react_1.default.createElement(ProfileBannerMedia, { raw: p.banner, position: p.bannerPosition, colors: colors }),
                        react_1.default.createElement(react_native_1.View, { pointerEvents: "none", style: s.bannerEditorShade })),
                    react_1.default.createElement(react_native_1.View, { style: s.bannerAdjustRow },
                        react_1.default.createElement(react_native_1.Pressable, { onPress: () => shiftBanner(10), style: [s.bannerAdjustButton, { backgroundColor: colors.panel }] },
                            react_1.default.createElement(Ionicons_1.default, { name: "arrow-up", size: 18, color: colors.text }),
                            react_1.default.createElement(react_native_1.Text, { style: [s.bannerAdjustText, { color: colors.text }] }, "Monter")),
                        react_1.default.createElement(react_native_1.Pressable, { onPress: () => shiftBanner(-10), style: [s.bannerAdjustButton, { backgroundColor: colors.panel }] },
                            react_1.default.createElement(Ionicons_1.default, { name: "arrow-down", size: 18, color: colors.text }),
                            react_1.default.createElement(react_native_1.Text, { style: [s.bannerAdjustText, { color: colors.text }] }, "Descendre")),
                        react_1.default.createElement(react_native_1.Text, { style: [s.bannerPositionText, { color: colors.muted }] }, `${Math.round(Number(p.bannerPosition ?? 50))}%`)),
                    react_1.default.createElement(react_native_1.Pressable, { onPress: () => setP(v => ({ ...v, banner: '', bannerPosition: 50 })), style: s.removeBanner },
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.danger, fontSize: 12, fontWeight: '700' } }, "Supprimer la bannière"))
                )),

            react_1.default.createElement(Field, { label: "Nom", value: p.name, setValue: v => setP({ ...p, name: v }), colors: colors }),
            react_1.default.createElement(Field, { label: "Pseudo", value: p.username, setValue: v => setP({ ...p, username: v.toLowerCase() }), colors: colors }),
            react_1.default.createElement(Field, { label: "Bio", value: p.bio, setValue: v => setP({ ...p, bio: v.slice(0, 200) }), colors: colors, multiline: true }),
            react_1.default.createElement(Field, { label: "Site web", value: p.website || '', setValue: v => setP({ ...p, website: v }), colors: colors }),
            react_1.default.createElement(ui_1.PrimaryButton, { title: busy ? 'Enregistrement…' : 'Enregistrer', disabled: busy, colors: colors, onPress: () => {
                if (p.banner && !bannerPreview) { a.notify('La bannière doit être une URL, un iframe ou un BBCode valide.'); return; }
                setBusy(true);
                a.run(async () => {
                    const u = await api.updateProfile(p);
                    a.setMe(u);
                    await a.refresh();
                    a.back();
                    a.notify('Profil enregistré.');
                }).finally(() => setBusy(false));
            } })));
}
function Field({ label, value, setValue, colors, multiline = false, placeholder }) { return react_1.default.createElement(react_native_1.View, { style: { gap: 8 } },
    react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 12, fontWeight: '700' } }, label),
    react_1.default.createElement(react_native_1.TextInput, { value: value, onChangeText: setValue, placeholder: placeholder, placeholderTextColor: colors.muted, multiline: multiline, style: [s.input, { color: colors.text, backgroundColor: colors.panel, minHeight: multiline ? 86 : 48, textAlignVertical: multiline ? 'top' : 'center' }] })); }
function CreatePostScreen({ colors }) {
    const a = (0, context_1.useApp)();
    const [mode, setMode] = (0, react_1.useState)(a.isGuest ? 'embed' : 'gallery');
    const [files, setFiles] = (0, react_1.useState)([]);
    const [embed, setEmbed] = (0, react_1.useState)('');
    const [caption, setCaption] = (0, react_1.useState)('');
    const [index, setIndex] = (0, react_1.useState)(0);
    const [busy, setBusy] = (0, react_1.useState)(false);
    const [progress, setProgress] = (0, react_1.useState)(0);

    const parsedEmbed = (0, react_1.useMemo)(() => {
        try { return { items: logic_1.parseEmbeds(embed), error: '' }; }
        catch (e) { return { items: [], error: e.message }; }
    }, [embed]);
    const embedPreview = parsedEmbed.items.slice(0, 10);

    const galleryPreview = files.map(f => ({
        type: f.mimeType.startsWith('video') ? 'video' : 'image',
        url: f.uri, width: f.width, height: f.height
    }));

    const previewItems = mode === 'gallery' ? galleryPreview : embedPreview;
    const previewIndex = Math.min(index, Math.max(0, previewItems.length - 1));
    const previewItem = previewItems[previewIndex];

    (0, react_1.useEffect)(() => {
        if (index >= previewItems.length)
            setIndex(Math.max(0, previewItems.length - 1));
    }, [previewItems.length, index]);

    const pick = async () => {
        if (a.isGuest) { a.notify('En mode visiteur, utilise Lien / Embed, iframe, BBCode ou URL.'); return; }
        const r = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images', 'videos'],
            allowsMultipleSelection: true,
            selectionLimit: 10,
            quality: 1
        });
        if (r.canceled) return;
        if (r.assets.length > 10) {
            a.notify('Maximum 10 médias.');
            return;
        }
        setFiles(r.assets.map(x => ({
            uri: x.uri,
            mimeType: x.mimeType || (x.type === 'video' ? 'video/mp4' : 'image/jpeg'),
            fileName: x.fileName || undefined,
            fileSize: x.fileSize, width: x.width, height: x.height
        })));
        setIndex(0);
    };

    const publish = async () => {
        if (busy) return;
        setBusy(true);
        setProgress(0);
        try {
            await a.run(async () => {
                let media = [];
                if (a.isGuest && mode !== 'embed') throw new Error('En mode visiteur, utilise Lien / Embed.');
                if (mode === 'embed') {
                    media = logic_1.parseEmbeds(embed);
                    if (media.length > 10)
                        throw new Error('Maximum 10 médias par publication.');
                    if (!media.length)
                        throw new Error('Ajoute au moins un lien.');
                } else {
                    if (!files.length)
                        throw new Error('Choisis une photo ou une vidéo.');
                    for (let i = 0; i < files.length; i++) {
                        const f = files[i];
                        const url = await api.upload(f, p => setProgress(Math.round((i + p / 100) / files.length * 100)));
                        media.push({ type: f.mimeType.startsWith('video') ? 'video' : 'image', url, ...(f.width && f.height ? { width: f.width, height: f.height } : {}) });
                    }
                }

                const created = await api.addPost(caption.trim(), media);

                // Les trois écrans lisent immédiatement la même publication enregistrée.
                a.registerPost(created);

                setFiles([]);
                setEmbed('');
                setCaption('');
                setIndex(0);
                a.back();
                a.notify('Ta publication est en ligne.');
            });
        } finally {
            setBusy(false);
        }
    };

    const thumbStrip = previewItems.length > 1
        ? react_1.default.createElement(
            react_native_1.ScrollView,
            { horizontal: true, showsHorizontalScrollIndicator: false, contentContainerStyle: s.previewThumbs },
            previewItems.map((m, i) =>
                react_1.default.createElement(
                    react_native_1.Pressable,
                    { key: String(m.url) + i, onPress: () => setIndex(i), style: [s.previewThumb, i === previewIndex && { borderColor: colors.accent }] },
                    m.type === 'image' || m.poster
                        ? react_1.default.createElement(react_native_1.Image, {
                            source: (0, logic_1.sourceFor)(m.poster || m.url),
                            style: react_native_1.StyleSheet.absoluteFill,
                            resizeMode: "cover"
                        })
                        : react_1.default.createElement(
                            react_native_1.View,
                            { style: s.previewThumbVideo },
                            react_1.default.createElement(Ionicons_1.default, { name: m.type === 'video' ? "videocam" : "link", size: 22, color: "#fff" })
                        )
                )
            )
        ) : null;

    const previewBox = previewItem
        ? react_1.default.createElement(
            react_1.default.Fragment,
            null,
            react_1.default.createElement(
                react_native_1.View,
                { style: [s.preview, { backgroundColor: '#141418' }] },
                react_1.default.createElement(media_1.MediaItem, {
                    key: String(previewItem.url),
                    media: previewItem,
                    active: true,
                    full: false,
                    colors
                }),
                previewItems.length > 1 && react_1.default.createElement(
                    react_native_1.View,
                    { style: s.previewCounter },
                    react_1.default.createElement(react_native_1.Text, { style: s.previewCounterText }, `${previewIndex + 1}/${previewItems.length}`)
                ),
                mode === 'gallery' && react_1.default.createElement(
                    react_native_1.Pressable,
                    {
                        style: s.remove,
                        onPress: () => {
                            setFiles(v => v.filter((_, i) => i !== previewIndex));
                            setIndex(0);
                        }
                    },
                    react_1.default.createElement(Ionicons_1.default, { name: "close", size: 20, color: "#fff" })
                )
            ),
            thumbStrip
        ) : null;

    return react_1.default.createElement(
        react_native_1.ScrollView,
        { keyboardShouldPersistTaps: "handled" },
        react_1.default.createElement(
            react_native_1.View,
            { style: [s.createHeader, { borderBottomColor: colors.line, backgroundColor: colors.bg }] },
            react_1.default.createElement(ui_1.IconButton, { name: "close", label: "Fermer", onPress: a.back, color: colors.text, size: 25 }),
            react_1.default.createElement(react_native_1.Text, { style: [s.createHeaderTitle, { color: colors.text }] }, "Nouvelle publication"),
            react_1.default.createElement(
                react_native_1.Pressable,
                {
                    disabled: busy || !(a.isGuest ? embed.trim() : (mode === 'gallery' ? files.length : embed.trim())),
                    onPress: publish,
                    style: s.createShare
                },
                react_1.default.createElement(
                    react_native_1.Text,
                    {
                        style: {
                            color: busy || !(a.isGuest ? embed.trim() : (mode === 'gallery' ? files.length : embed.trim())) ? colors.muted : colors.accent,
                            fontSize: 12.5,
                            fontWeight: '800'
                        }
                    },
                    busy ? "Publication…" : "Partager"
                )
            )
        ),
        react_1.default.createElement(
            react_native_1.View,
            { style: s.composer },

            a.isGuest
                ? react_1.default.createElement(
                    react_native_1.View,
                    { style: [s.previewHint, { backgroundColor: colors.panel, borderColor: colors.line }] },
                    react_1.default.createElement(Ionicons_1.default, { name: "eye-outline", size: 21, color: colors.accent }),
                    react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, flex: 1, fontSize: 12, lineHeight: 17 } }, "Mode visiteur · publication par URL, iframe, BBCode ou lien média. La publication restera en ligne même si l’application est désinstallée.")
                )
                : react_1.default.createElement(
                    react_native_1.View,
                    { style: [s.segmented, { backgroundColor: colors.panel }] },
                    ['gallery', 'embed'].map(x =>
                        react_1.default.createElement(
                            react_native_1.Pressable,
                            {
                                key: x,
                                onPress: () => { setMode(x); setIndex(0); },
                                style: [s.segment, mode === x && { backgroundColor: colors.bg }]
                            },
                            react_1.default.createElement(
                                react_native_1.Text,
                                { style: { color: mode === x ? colors.accent : colors.muted, fontWeight: '700' } },
                                x === 'gallery' ? 'Galerie' : 'Lien / Embed'
                            )
                        )
                    )
                ),

            mode === 'gallery'
                ? react_1.default.createElement(
                    react_1.default.Fragment,
                    null,
                    previewBox || react_1.default.createElement(
                        react_native_1.View,
                        { style: [s.uploadEmpty, { backgroundColor: colors.panel, borderColor: colors.line }] },
                        react_1.default.createElement(Ionicons_1.default, { name: "images-outline", size: 42, color: colors.muted }),
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.text, fontSize: 19, fontWeight: '800' } }, "Partage un moment"),
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted } }, "Photos, vidéos ou carrousel jusqu’à 10 médias.")
                    ),
                    react_1.default.createElement(ui_1.SecondaryButton, {
                        title: files.length ? 'Changer la sélection' : 'Choisir dans le téléphone',
                        onPress: pick,
                        colors
                    })
                )
                : react_1.default.createElement(
                    react_native_1.View,
                    { style: { gap: 12 } },
                    react_1.default.createElement(Field, {
                        label: "Lien ou code intégré",
                        value: embed,
                        setValue: v => { setEmbed(v); setIndex(0); },
                        colors,
                        multiline: true,
                        placeholder: 'https://…\nou <iframe src="https://…"></iframe>'
                    }),
                    previewBox || (!!embed.trim() && react_1.default.createElement(
                        react_native_1.View,
                        { style: [s.previewHint, { backgroundColor: colors.panel, borderColor: colors.line }] },
                        react_1.default.createElement(Ionicons_1.default, { name: "eye-outline", size: 22, color: colors.muted }),
                        react_1.default.createElement(react_native_1.Text, { style: { color: colors.muted, flex: 1, fontSize: 12 } }, parsedEmbed.error || 'Aperçu dès qu’un média valide est détecté.')
                    )),
                    react_1.default.createElement(
                        react_native_1.Text,
                        { style: { color: colors.muted, fontSize: 11, lineHeight: 18 } },
                        "Photos, vidéos, iframe, HTML et BBCode · 10 médias maximum. Certains sites peuvent refuser la lecture intégrée. Utilise de préférence un lien HTTPS direct."
                    )
                ),

            react_1.default.createElement(Field, {
                label: "Légende",
                value: caption,
                setValue: v => setCaption(v.slice(0, 2200)),
                colors,
                multiline: true,
                placeholder: "Ajouter une légende… #theworldisyour"
            }),

            busy && react_1.default.createElement(
                react_native_1.Text,
                { style: { color: colors.muted } },
                "Publication en cours · ", progress, " %"
            ),

            react_1.default.createElement(
                react_native_1.Text,
                { style: { color: colors.muted, fontSize: 10.5, textAlign: 'center', paddingVertical: 3 } },
                "Les publications apparaîtront immédiatement sur ton profil et dans Explorer."
            )
        )
    );
}
const s = react_native_1.StyleSheet.create({
    homeHeader: {
        height: 52,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 14,
        paddingRight: 4
    },
    brand: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
    brandText: {
        flex: 1,
        fontSize: 20,
        fontWeight: '900',
        letterSpacing: -.7
    },
    notificationButton: { position: 'relative' },
    notificationBadge: {
        position: 'absolute',
        right: 0,
        top: 1,
        minWidth: 17,
        height: 17,
        borderRadius: 9,
        paddingHorizontal: 4,
        alignItems: 'center',
        justifyContent: 'center'
    },
    notificationBadgeText: { color: '#fff', fontSize: 9, fontWeight: '900' },
    notificationRow: {
        minHeight: 72,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 11,
        paddingHorizontal: 14,
        paddingVertical: 10,
        borderBottomWidth: 1
    },
    notificationText: { fontSize: 13.5, lineHeight: 19 },
    notificationTime: { fontSize: 10.5, marginTop: 3 },
    simpleHeader: {
        height: 54,
        paddingHorizontal: 14,
        flexDirection: 'row',
        alignItems: 'center'
    },
    pageTitle: { fontSize: 20, fontWeight: '800', flex: 1 },
    feedTabs: {
        height: 38,
        flexDirection: 'row',
        gap: 24,
        paddingHorizontal: 15,
        borderBottomWidth: 1
    },
    feedTab: {
        justifyContent: 'center',
        paddingHorizontal: 1
    },
    feedTabText: { fontSize: 12.5 },
    suggestions: {
        paddingHorizontal: 10,
        paddingVertical: 10,
        gap: 12,
        borderBottomWidth: 1
    },
    suggestion: {
        width: 65,
        alignItems: 'center',
        gap: 5
    },
    suggestText: { fontSize: 9.5, maxWidth: 66, textAlign: 'center' },
    addCircle: {
        width: 59,
        height: 59,
        borderRadius: 30,
        borderWidth: 1,
        borderStyle: 'dashed',
        alignItems: 'center',
        justifyContent: 'center'
    },
    storyAvatarWrap: { width: 61, height: 61, borderRadius: 31, position: 'relative', alignItems: 'center', justifyContent: 'center' },
    storyPlus: {
        position: 'absolute',
        right: -1,
        bottom: -1,
        width: 20,
        height: 20,
        borderRadius: 10,
        borderWidth: 2,
        alignItems: 'center',
        justifyContent: 'center'
    },
    loadMore: { padding: 20, alignItems: 'center' },

    exploreTop: {
        minHeight: 54,
        flexDirection: 'row',
        alignItems: 'center',
        paddingRight: 10,
        gap: 2
    },
    search: {
        flex: 1,
        height: 37,
        marginHorizontal: 12,
        marginVertical: 8,
        borderRadius: 11,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 11
    },
    searchInput: { flex: 1, paddingHorizontal: 8, fontSize: 12.5, paddingVertical: 0 },
    searchClear: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
    chips: { flexDirection: 'row', gap: 8, marginHorizontal: 17, marginBottom: 17 },
    exploreTabs: {
        height: 38,
        flexDirection: 'row',
        borderBottomWidth: 1,
        paddingHorizontal: 10,
        gap: 18
    },
    exploreTab: { justifyContent: 'center', paddingHorizontal: 2 },

    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 2 },
    tile: { width: (W - 4) / 3, overflow: 'hidden' },
    gridTag: {
        position: 'absolute',
        right: 6,
        top: 6,
        flexDirection: 'row',
        gap: 3,
        alignItems: 'center',
        padding: 2
    },
    playTag: {
        position: 'absolute',
        right: 7,
        top: 7,
        textShadowColor: '#000a',
        textShadowRadius: 3
    },
    embedTile: { alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#15191f' },

    personRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 16,
        paddingVertical: 12,
        borderBottomWidth: 1
    },

    connectionsHeader: {
        height: 54,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 4
    },
    connectionsTitle: {
        flex: 1,
        textAlign: 'center',
        fontSize: 18.5,
        fontWeight: '800',
        letterSpacing: -.35
    },
    connectionsTabs: {
        height: 47,
        flexDirection: 'row',
        borderBottomWidth: 1
    },
    connectionsTab: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    connectionsTabText: { fontSize: 12.5, fontWeight: '700' },
    connectionsSearch: {
        height: 42,
        marginHorizontal: 12,
        marginTop: 10,
        marginBottom: 6,
        borderRadius: 11,
        paddingHorizontal: 12,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 7
    },
    connectionsSearchInput: { flex: 1, fontSize: 13, paddingVertical: 0 },
    connectionRow: {
        minHeight: 70,
        paddingHorizontal: 14,
        paddingVertical: 8,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 9
    },
    connectionIdentity: {
        flex: 1,
        minWidth: 0,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 11
    },
    connectionUser: { fontSize: 13.5, fontWeight: '800' },
    connectionName: { fontSize: 12, marginTop: 2 },
    connectionFollow: {
        minWidth: 92,
        minHeight: 34,
        borderRadius: 8,
        borderWidth: 1,
        paddingHorizontal: 13,
        alignItems: 'center',
        justifyContent: 'center'
    },
    connectionsEmpty: {
        flex: 1,
        minHeight: 260,
        alignItems: 'center',
        justifyContent: 'center',
        gap: 12,
        paddingHorizontal: 30
    },
    connectionsEmptyTitle: { fontSize: 17, fontWeight: '800', textAlign: 'center' },

    profileHeader: {
        height: 50,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 4
    },
    profileTitleWrap: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 3,
        paddingHorizontal: 2
    },
    profileName: {
        maxWidth: '88%',
        textAlign: 'center',
        fontSize: 18.5,
        fontWeight: '800',
        letterSpacing: -.45
    },
    profileHeaderRight: {
        width: 84,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end'
    },
    profileHero: { position: 'relative', overflow: 'hidden' },
    profileHeroWithBanner: { minHeight: 255 },
    profileBannerLayer: { ...react_native_1.StyleSheet.absoluteFillObject, backgroundColor: '#000' },
    profileBannerMoving: { position: 'absolute', left: 0, right: 0, height: '140%', backgroundColor: '#000' },
    profileBannerShade: { ...react_native_1.StyleSheet.absoluteFillObject, backgroundColor: '#0000004d' },
    profileAvatarOnBanner: { borderRadius: 40, borderWidth: 2, borderColor: '#ffffffcc', padding: 2, backgroundColor: '#00000055' },
    profileTop: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        gap: 14,
        paddingHorizontal: 14,
        paddingTop: 7,
        paddingBottom: 3
    },
    profileIdentity: { flex: 1, paddingTop: 0 },
    profileDisplayName: {
        fontSize: 12.5,
        fontWeight: '800',
        marginBottom: 10
    },
    stats: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between'
    },
    statsBannerBottom: {
        position: 'absolute',
        left: 105,
        right: 14,
        bottom: 14,
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'space-between'
    },
    stat: { flex: 1, alignItems: 'flex-start', gap: 1 },
    statN: { fontSize: 15.5, fontWeight: '800', lineHeight: 18 },
    statLabel: { fontSize: 10.5, lineHeight: 13.5 },
    bio: {
        paddingHorizontal: 14,
        paddingTop: 4,
        paddingBottom: 8,
        alignItems: 'flex-start'
    },
    bioText: { fontSize: 12.5, lineHeight: 17 },
    web: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
    bannerChip: {
        minHeight: 30,
        marginTop: 8,
        borderWidth: 1,
        borderRadius: 17,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        gap: 4
    },
    bannerEditor: { gap: 9 },
    bannerEditorTitle: { fontSize: 14, fontWeight: '800' },
    bannerEditorHint: { fontSize: 11.5, lineHeight: 17 },
    bannerInput: { minHeight: 92, borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, textAlignVertical: 'top', fontSize: 12 },
    bannerEditorPreview: { height: 190, borderRadius: 13, overflow: 'hidden', position: 'relative' },
    bannerEditorShade: { ...react_native_1.StyleSheet.absoluteFillObject, backgroundColor: '#00000020' },
    bannerAdjustRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    bannerAdjustButton: { minHeight: 38, borderRadius: 9, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
    bannerAdjustText: { fontSize: 11.5, fontWeight: '700' },
    bannerPositionText: { marginLeft: 'auto', minWidth: 34, textAlign: 'right', fontSize: 11 },
    removeBanner: { alignSelf: 'flex-start', paddingVertical: 4 },
    profileButtons: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        paddingHorizontal: 12,
        paddingTop: 6,
        paddingBottom: 12
    },
    profileAction: {
        flex: 1,
        minHeight: 34,
        borderRadius: 7,
        borderWidth: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 7
    },
    profileActionText: { fontSize: 11.8, fontWeight: '800' },
    profileIconAction: {
        width: 38,
        height: 34,
        borderRadius: 7,
        borderWidth: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },

    profileSuggestions: { paddingBottom: 10 },
    profileSuggestHead: {
        minHeight: 32,
        paddingHorizontal: 14,
        flexDirection: 'row',
        alignItems: 'center'
    },
    profileSuggestTitle: { flex: 1, fontSize: 12, fontWeight: '800' },
    profileSuggestList: { paddingHorizontal: 10, gap: 8 },
    profileSuggestCard: {
        width: 139,
        minHeight: 180,
        borderRadius: 10,
        borderWidth: 1,
        paddingHorizontal: 10,
        paddingTop: 16,
        paddingBottom: 10,
        alignItems: 'center',
        position: 'relative'
    },
    profileSuggestClose: {
        position: 'absolute',
        top: 4,
        right: 4,
        width: 28,
        height: 28,
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 3
    },
    profileSuggestUser: {
        width: '100%',
        textAlign: 'center',
        marginTop: 8,
        fontSize: 11.5,
        fontWeight: '800'
    },
    profileSuggestMeta: { fontSize: 10.5, marginTop: 2, marginBottom: 9 },
    profileSuggestFollow: {
        width: '100%',
        minHeight: 34,
        borderWidth: 1,
        borderRadius: 7,
        alignItems: 'center',
        justifyContent: 'center'
    },

    profileTabs: {
        flexDirection: 'row',
        borderBottomWidth: 1,
        minHeight: 43
    },
    profileTab: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 8
    },
    profileEmpty: {
        minHeight: 255,
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 30,
        gap: 8
    },
    profileEmptyTitle: {
        maxWidth: 290,
        textAlign: 'center',
        fontSize: 20,
        lineHeight: 23,
        fontWeight: '800'
    },
    profileEmptyBody: { fontSize: 12.5, textAlign: 'center' },

    form: { paddingHorizontal: 18, paddingBottom: 35, gap: 18 },
    avatarEdit: { alignItems: 'center' },
    input: {
        borderRadius: 10,
        paddingHorizontal: 12,
        paddingVertical: 11,
        fontSize: 13
    },

    createHeader: {
        height: 50,
        borderBottomWidth: 1,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 3
    },
    createHeaderTitle: {
        flex: 1,
        textAlign: 'center',
        fontSize: 15,
        fontWeight: '800'
    },
    createShare: {
        width: 62,
        height: 42,
        alignItems: 'center',
        justifyContent: 'center'
    },
    composer: { paddingHorizontal: 14, paddingBottom: 35, gap: 13 },
    segmented: { flexDirection: 'row', borderRadius: 10, padding: 3 },
    segment: { flex: 1, paddingVertical: 9, alignItems: 'center', borderRadius: 8 },
    preview: {
        height: 330,
        borderRadius: 0,
        overflow: 'hidden',
        position: 'relative'
    },
    previewCounter: {
        position: 'absolute',
        left: 10,
        top: 10,
        backgroundColor: '#0009',
        borderRadius: 16,
        paddingHorizontal: 9,
        paddingVertical: 5
    },
    previewCounterText: { color: '#fff', fontSize: 11, fontWeight: '800' },
    previewThumbs: { gap: 7, paddingVertical: 2 },
    previewThumb: {
        width: 56,
        height: 56,
        borderRadius: 7,
        overflow: 'hidden',
        borderWidth: 2,
        borderColor: 'transparent',
        backgroundColor: '#17171b'
    },
    previewThumbVideo: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#202027'
    },
    previewHint: {
        minHeight: 54,
        borderRadius: 10,
        borderWidth: 1,
        paddingHorizontal: 12,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 9
    },
    remove: {
        position: 'absolute',
        right: 9,
        top: 9,
        width: 31,
        height: 31,
        borderRadius: 16,
        backgroundColor: '#0009',
        alignItems: 'center',
        justifyContent: 'center'
    },
    uploadEmpty: {
        height: 250,
        borderRadius: 0,
        borderWidth: 1,
        borderStyle: 'dashed',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        padding: 20
    }
});

};

__modules["src/theme"] = function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dark = exports.light = exports.RAINBOW = void 0;
exports.useResolvedTheme = useResolvedTheme;
const react_native_1 = require("react-native");
exports.RAINBOW = ['#ff4fa3', '#ff77c8', '#ff67df', '#d861ff', '#ff8cb8', '#ff4fa3'];
exports.light = { bg: '#fff8fc', panel: '#fff0f7', text: '#1c1020', muted: '#8e7888', line: '#f0d7e5', accent: '#ff4fa3', chat: '#ffffff', danger: '#ff4d8d' };
exports.dark = { bg: '#0b0610', panel: '#1a1018', text: '#fff7fb', muted: '#a88e9d', line: '#33202f', accent: '#ff4fa3', chat: '#0b0610', danger: '#ff5f93' };
function useResolvedTheme(mode) { const system = (0, react_native_1.useColorScheme)(); const darkMode = mode === 'dark' || (mode === 'system' && system === 'dark'); return { colors: darkMode ? exports.dark : exports.light, dark: darkMode }; }

};

__modules["src/types"] = function(module,exports,require){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });

};

const __entry = __load('App');
export default (__entry && __entry.default) ? __entry.default : __entry;
