import React,{useCallback,useEffect,useMemo,useState} from 'react';
import {ActivityIndicator,BackHandler,Linking,Platform,Pressable,StatusBar,StyleSheet,Text,View} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Ionicons from '@expo/vector-icons/Ionicons';
import * as NavigationBar from 'expo-navigation-bar';
import {SafeAreaProvider,useSafeAreaInsets} from 'react-native-safe-area-context';
import type {Post,Profile,Route,ThemeMode} from './src/types';
import * as api from './src/api';
import {AppContext} from './src/context';
import {useResolvedTheme} from './src/theme';
import {RainbowMark} from './src/components/ui';
import {FullViewer,CommentsModal,MediaLightbox} from './src/components/overlays';
import {AuthScreen} from './src/screens/auth';
import {HomeScreen,ExploreScreen,ProfileScreen,EditProfileScreen,CreatePostScreen,PeopleScreen} from './src/screens/social';
import {ChatListScreen,ConversationScreen} from './src/screens/chat';
import {SettingsScreen} from './src/screens/settings';

const THEME_KEY='twy-theme-v1';

type ViewerState={posts:Post[];index:number}|null;
type LightboxState={url:string|number;kind:'image'|'video'}|null;

export default function App(){return <SafeAreaProvider><Root/></SafeAreaProvider>}
function Root(){
 const insets=useSafeAreaInsets();
 const[booting,setBooting]=useState(true);const[resetPassword,setResetPassword]=useState(false);const[me,setMe]=useState<Profile|null>(null);const[posts,setPosts]=useState<Post[]>([]);const[followed,setFollowed]=useState<string[]>([]);const[stack,setStack]=useState<Route[]>([{name:'home'}]);const[theme,setThemeState]=useState<ThemeMode>('system');const[toast,setToast]=useState('');const[viewer,setViewer]=useState<ViewerState>(null);const[commentPost,setCommentPost]=useState<Post|null>(null);const[lightbox,setLightbox]=useState<LightboxState>(null);const[hasMore,setHasMore]=useState(false);
 const{colors,dark}=useResolvedTheme(theme);const route=stack[stack.length-1];
 const notify=useCallback((message:string)=>{setToast(message);setTimeout(()=>setToast(v=>v===message?'':v),3500);},[]);
 const run=useCallback(async<T,>(fn:()=>Promise<T>)=>{try{return await fn();}catch(e){notify((e as Error)?.message||'Une erreur est survenue.');return undefined;}},[notify]);
 const refresh=useCallback(async()=>{if(!api.uid)return;const[p,f]=await Promise.all([api.posts(0,30),api.following()]);setPosts(p);setFollowed(f);setHasMore(p.length===30);},[]);
 const loadMore=useCallback(async()=>{if(!hasMore)return;const more=await api.posts(posts.length,30);setPosts(v=>[...v,...more.filter(x=>!v.some(y=>y.id===x.id))]);setHasMore(more.length===30);},[hasMore,posts.length]);
 const setTheme=useCallback((value:ThemeMode)=>{setThemeState(value);AsyncStorage.setItem(THEME_KEY,value).catch(()=>{});},[]);
 const push=useCallback((r:Route)=>{setViewer(null);setCommentPost(null);setLightbox(null);setStack(v=>[...v,r]);},[]);
 const replaceTab=useCallback((name:'home'|'explore'|'chats'|'profile')=>{setViewer(null);setCommentPost(null);setLightbox(null);setStack([name==='profile'?{name:'profile'}:{name} as Route]);},[]);
 const back=useCallback(()=>{if(lightbox){setLightbox(null);return;}if(commentPost){setCommentPost(null);return;}if(viewer){setViewer(null);return;}setStack(v=>v.length>1?v.slice(0,-1):v);},[lightbox,commentPost,viewer]);
 const logout=useCallback(async()=>{await api.logout();setMe(null);setPosts([]);setFollowed([]);setStack([{name:'home'}]);},[]);
 const signedIn=useCallback(async(p:Profile)=>{setResetPassword(false);setMe(p);setStack([{name:'home'}]);await refresh();},[refresh]);
 const consumeAuthLink=useCallback(async(url:string|null):Promise<'recovery'|'login'|null>=>{if(!url||!url.startsWith('theworldisyour://auth')||!api.client)return null;const hash=url.split('#')[1]||url.split('?')[1];if(!hash)return null;const q=new URLSearchParams(hash);const access_token=q.get('access_token'),refresh_token=q.get('refresh_token');if(!access_token||!refresh_token)return null;const{error}=await api.client.auth.setSession({access_token,refresh_token});if(error)throw error;await api.session();if(q.get('type')==='recovery'){setResetPassword(true);setMe(null);return 'recovery';}await signedIn(await api.profile(api.uid));return 'login';},[signedIn]);
 useEffect(()=>{let mounted=true;(async()=>{try{const saved=await AsyncStorage.getItem(THEME_KEY);if(saved==='light'||saved==='dark'||saved==='system')setThemeState(saved);await api.init();const initialUrl=await Linking.getInitialURL();const linkKind=initialUrl?await consumeAuthLink(initialUrl):null;const sess=await api.session();if(sess&&mounted&&linkKind!=='recovery'){const p=await api.profile(api.uid);setMe(p);const[data,f]=await Promise.all([api.posts(0,30),api.following()]);if(mounted){setPosts(data);setFollowed(f);setHasMore(data.length===30);}}}catch(e){notify((e as Error).message);}finally{if(mounted)setBooting(false);}})();return()=>{mounted=false};},[]);
 useEffect(()=>{const sub=Linking.addEventListener('url',({url})=>{run(()=>consumeAuthLink(url));});return()=>sub.remove();},[consumeAuthLink,run]);
 useEffect(()=>{const sub=BackHandler.addEventListener('hardwareBackPress',()=>{if(!me)return false;if(lightbox||commentPost||viewer||stack.length>1){back();return true;}return false;});return()=>sub.remove();},[me,lightbox,commentPost,viewer,stack.length,back]);
 useEffect(()=>{const immersive=!!viewer||!!lightbox;StatusBar.setHidden(immersive,'fade');if(Platform.OS==='android'){NavigationBar.setVisibilityAsync(immersive?'hidden':'visible').catch(()=>{});NavigationBar.setButtonStyleAsync(dark?'light':'dark').catch(()=>{});}return()=>{StatusBar.setHidden(false,'fade');if(Platform.OS==='android')NavigationBar.setVisibilityAsync('visible').catch(()=>{});};},[viewer,lightbox,dark]);
 if(booting)return <View style={[a.loading,{backgroundColor:colors.bg}]}><RainbowMark size={70}/><Text style={[a.loadingTitle,{color:colors.text}]}>the World IS your</Text><ActivityIndicator color={colors.accent}/></View>;
 if(!me)return <><StatusBar hidden={false} barStyle={dark?'light-content':'dark-content'} backgroundColor={colors.bg}/><AuthScreen colors={colors} onReady={signedIn} notify={notify} reset={resetPassword}/>{!!toast&&<Toast text={toast}/>}</>;
 const ctx={me,setMe,posts,followed,push,back,run,notify,refresh,view:(list:Post[],index:number)=>setViewer({posts:list,index}),comments:(p:Post)=>setCommentPost(p),lightbox:(url:string|number,kind:'image'|'video'='image')=>setLightbox({url,kind}),theme,setTheme,logout,loadMore,hasMore};
 const mainTab=stack.length===1&&['home','explore','chats','profile'].includes(route.name);
 return <AppContext.Provider value={ctx}><View style={[a.app,{backgroundColor:colors.bg,paddingTop:viewer||lightbox?0:insets.top}]}><StatusBar hidden={false} barStyle={dark?'light-content':'dark-content'} backgroundColor={colors.bg}/><View style={a.rainbow}/>{api.demo&&<Text style={[a.demo,{backgroundColor:colors.panel,color:colors.muted}]}>MODE DÉMONSTRATION · DONNÉES LOCALES</Text>}<View style={{flex:1}}>{renderRoute(route,colors)}</View>{mainTab&&<BottomNav current={route.name} onTab={replaceTab} onCreate={()=>push({name:'create'})} colors={colors} bottom={insets.bottom}/>}<FullViewer visible={!!viewer} posts={viewer?.posts||[]} start={viewer?.index||0} paused={!!commentPost} colors={colors} onClose={()=>setViewer(null)}/><CommentsModal post={commentPost} colors={colors} onClose={()=>setCommentPost(null)}/><MediaLightbox open={lightbox} colors={colors} onClose={()=>setLightbox(null)}/>{!!toast&&<Toast text={toast}/>}</View></AppContext.Provider>;
}
function renderRoute(route:Route,colors:any){switch(route.name){case'home':return <HomeScreen colors={colors} enabled/>;case'explore':return <ExploreScreen colors={colors} initialQuery={route.query}/>;case'chats':return <ChatListScreen colors={colors}/>;case'profile':return <ProfileScreen person={route.person} colors={colors}/>;case'edit':return <EditProfileScreen colors={colors}/>;case'create':return <CreatePostScreen colors={colors}/>;case'people':return <PeopleScreen colors={colors}/>;case'conversation':return <ConversationScreen thread={route.thread} colors={colors}/>;case'settings':return <SettingsScreen colors={colors}/>;}}
function BottomNav({current,onTab,onCreate,colors,bottom}:{current:string;onTab:(n:'home'|'explore'|'chats'|'profile')=>void;onCreate:()=>void;colors:any;bottom:number}){const tabs:[string,any,string][]=[['home','home-outline','Accueil'],['explore','search-outline','Explorer'],['create','add-circle-outline','Publier'],['chats','chatbubble-outline','Messages'],['profile','person-outline','Profil']];return <View style={[a.nav,{backgroundColor:colors.bg,borderTopColor:colors.line,paddingBottom:Math.max(8,bottom)}]}>{tabs.map(([id,icon,label])=><Pressable key={id} onPress={()=>id==='create'?onCreate():onTab(id as any)} onLongPress={undefined} style={a.navItem}>{id==='create'?<Ionicons name={icon} size={30} color={colors.text}/>:<Ionicons name={current===id?icon.replace('-outline',''):icon} size={24} color={colors.text}/>}<Text style={{fontSize:9,color:current===id?colors.text:colors.muted,fontWeight:current===id?'800':'500'}}>{label}</Text>{current===id&&id!=='create'&&<View style={[a.navActive,{backgroundColor:colors.accent}]}/>}</Pressable>)}</View>}
function Toast({text}:{text:string}){return <View pointerEvents="none" style={a.toast}><Text style={a.toastText}>{text}</Text></View>}
const a=StyleSheet.create({app:{flex:1},rainbow:{height:3,backgroundColor:'#d544a8'},demo:{textAlign:'center',fontSize:9,fontWeight:'800',letterSpacing:1.2,paddingVertical:4},loading:{flex:1,alignItems:'center',justifyContent:'center',gap:15},loadingTitle:{fontSize:28,fontWeight:'900',letterSpacing:-1.5},nav:{minHeight:69,borderTopWidth:1,flexDirection:'row',paddingTop:6,paddingHorizontal:3},navItem:{flex:1,alignItems:'center',justifyContent:'center',gap:3,position:'relative'},navActive:{position:'absolute',bottom:0,width:18,height:3,borderRadius:2},toast:{position:'absolute',left:18,right:18,bottom:94,backgroundColor:'#313137',paddingHorizontal:16,paddingVertical:14,borderRadius:14,elevation:20},toastText:{color:'#fff',fontSize:13,lineHeight:19}});
