# the World IS your — Expo SDK 55

Version React Native/Expo de l’application d’origine, créée comme projet séparé pour ne pas modifier la version React/Vite/Capacitor.

## Base technique

- Expo SDK 55
- React Native 0.83
- React 19.2
- TypeScript
- Supabase
- `expo-video` pour les vidéos natives
- `react-native-webview` pour les embeds
- `expo-image-picker` pour publier depuis le téléphone
- `expo-audio` pour les messages vocaux
- AsyncStorage pour le mode démonstration et la configuration locale

## Comportements reproduits

- inscription / connexion + mode démo local
- accueil « Pour vous » et « Abonnements »
- Explorer, recherche, comptes et tri populaire/récent
- profils, abonnements, statistiques, favoris
- publication photo, vidéo, carrousel et liens/embed
- double tap pour aimer
- swipe horizontal dans les carrousels
- viewer plein écran avec swipe vertical entre publications
- une seule vidéo active à la fois
- lecteur plein écran sans contrôles natifs, avec barre de progression personnalisée tout en bas
- son muet par défaut avec bouton son
- likes, commentaires, partage et favoris
- messagerie, photos, vidéos, vocaux, emojis, statut lu/envoyé
- thèmes clair / sombre / système
- retour Android cohérent
- Supabase SQL d’origine conservé dans `supabase/INSTALL.sql`

## Démarrage dans Expo Go

Dans le dossier du projet :

```bash
npm install
npx expo install --fix
npx expo start
```

Puis ouvrir le QR code avec une version d’Expo Go compatible SDK 55.

`npx expo install --fix` est volontairement conseillé après `npm install` : Expo vérifie ainsi que toutes les versions natives correspondent exactement au SDK 55 installé.

## Supabase

L’écran Connexion permet de choisir **Configurer Supabase**. Utiliser uniquement :

- l’URL HTTPS du projet Supabase ;
- la clé publique `sb_publishable_...` / anon.

Ne jamais saisir une clé `sb_secret_...`.

Le schéma SQL de la version d’origine est dans `supabase/INSTALL.sql`.

## Tester sans backend

Sur l’écran Connexion, toucher **Ouvrir la démonstration**. Les données de démonstration restent uniquement sur le téléphone.

## APK plus tard

Le projet contient `eas.json`. Pour un APK de test :

```bash
npx eas build -p android --profile preview
```
