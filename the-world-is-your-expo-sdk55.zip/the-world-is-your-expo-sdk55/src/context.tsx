import {createContext,useContext} from 'react';
import type {Profile,Post,Route,ThemeMode} from './types';
export type AppContextValue={
 me:Profile;setMe:(p:Profile)=>void;posts:Post[];followed:string[];push:(r:Route)=>void;back:()=>void;
 run:<T>(fn:()=>Promise<T>)=>Promise<T|undefined>;notify:(s:string)=>void;refresh:()=>Promise<void>;
 view:(list:Post[],index:number)=>void;comments:(p:Post)=>void;lightbox:(url:string|number,kind?:'image'|'video')=>void;
 theme:ThemeMode;setTheme:(v:ThemeMode)=>void;logout:()=>Promise<void>;loadMore:()=>Promise<void>;hasMore:boolean;
};
export const AppContext=createContext<AppContextValue|null>(null);
export function useApp(){const v=useContext(AppContext);if(!v)throw new Error('AppContext absent');return v;}
