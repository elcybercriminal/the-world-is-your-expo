import type {Media,Post} from './types';
export const cleanUsername=(v:string)=>v.trim().toLowerCase().replace(/^@/,'');
export const validUsername=(v:string)=>/^[a-z0-9_.]{3,24}$/.test(v);
export function safeUrl(raw:string){try{const u=new URL(raw);return u.protocol==='https:'?u.href:'';}catch{return '';}}
export function parseEmbed(raw:string):Media{
  const text=raw.trim();
  const match=text.match(/(?:src\s*=\s*["'])(https:\/\/[^"']+)/i)||text.match(/\[url(?:=([^\]]+))?\]([^[]*)/i)||text.match(/\[(?:video|img)\](https:\/\/[^[]+)/i);
  const value=match?(match[1]||match[2]):text;
  const href=safeUrl((value||'').replace(/&amp;/g,'&'));
  if(!href)throw new Error('Colle une URL HTTPS ou un code iframe contenant une URL HTTPS.');
  const u=new URL(href),host=u.hostname.toLowerCase();
  if(/\.(mp4|webm|m4v)(\?.*)?$/i.test(u.pathname))return{type:'video',url:href};
  if(/\.(jpe?g|png|webp|gif)(\?.*)?$/i.test(u.pathname))return{type:'image',url:href};
  if(['youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtube-nocookie.com'].includes(host)){
    const id=host==='youtu.be'?u.pathname.slice(1):u.searchParams.get('v')||u.pathname.split('/').filter(Boolean).pop();
    if(!/^[\w-]{11}$/.test(id||''))throw new Error('Ce lien YouTube ne contient pas de vidéo valide.');
    return{type:'embed',url:'https://www.youtube-nocookie.com/embed/'+id,poster:'https://i.ytimg.com/vi/'+id+'/hqdefault.jpg'};
  }
  if(['vimeo.com','www.vimeo.com','player.vimeo.com'].includes(host)){
    const id=u.pathname.split('/').filter(Boolean).pop(); if(!/^\d+$/.test(id||''))throw new Error('Lien Vimeo invalide.');
    return{type:'embed',url:'https://player.vimeo.com/video/'+id};
  }
  if(['www.dailymotion.com','dailymotion.com','dai.ly'].includes(host)){
    const id=u.pathname.split('/').filter(Boolean).pop()?.split('_')[0]; if(!/^[a-zA-Z0-9]+$/.test(id||''))throw new Error('Lien Dailymotion invalide.');
    return{type:'embed',url:'https://www.dailymotion.com/embed/video/'+id};
  }
  throw new Error('Intégration non prise en charge. Utilise YouTube, Vimeo, Dailymotion, ou un lien direct vers une image/vidéo.');
}
export const sortPosts=(posts:Post[],mode:string)=>[...posts].sort((a,b)=>mode==='popular'?(b.likes.length*2+b.comments.length*3)-(a.likes.length*2+a.comments.length*3)||Date.parse(b.created_at)-Date.parse(a.created_at):Date.parse(b.created_at)-Date.parse(a.created_at));
export function formatWhen(date:string){const diff=Date.now()-Date.parse(date);return diff<60000?'À l’instant':diff<3600000?Math.floor(diff/60000)+' min':diff<86400000?Math.floor(diff/3600000)+' h':new Date(date).toLocaleDateString('fr-FR',{day:'numeric',month:'short'});}
export const sourceFor=(ref:string|number|undefined)=>typeof ref==='number'?ref:ref?{uri:ref}:undefined;
export const uriFor=(ref:string|number|undefined)=>typeof ref==='string'?ref:'';
