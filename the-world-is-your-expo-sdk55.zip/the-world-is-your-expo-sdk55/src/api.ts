import AsyncStorage from '@react-native-async-storage/async-storage';
import {createClient, type SupabaseClient} from '@supabase/supabase-js';
import type {Profile,Post,Comment,Thread,Message,Config,PickedFile,AssetRef} from './types';
import {cleanUsername,validUsername,safeUrl} from './logic';

export let client:SupabaseClient|null=null;
export let demo=false;
export let uid='';
let cfg:Config={supabaseUrl:'',supabaseAnonKey:''};
const signed=new Map<string,{url:string;until:number}>();
const DB_KEY='twy-demo-db-v1';
const CONFIG_KEY='twy-supabase-config-v1';

const A={
  avatar:require('../assets/demo/avatar.jpg'),camille:require('../assets/demo/camille.jpg'),leo:require('../assets/demo/leo.jpg'),
  coast:require('../assets/demo/coast.jpg'),city:require('../assets/demo/city.jpg'),cafe:require('../assets/demo/cafe.jpg'),mountain:require('../assets/demo/mountain.jpg')
};
export const meDemo:Profile={id:'demo-me',username:'alex.world',name:'Alex',bio:'Les belles rencontres et les petits moments. 🏳️‍🌈\nMarseille, France',avatar:A.avatar,website:''};
type DB={profiles:Profile[];posts:Post[];comments:Comment[];messages:Message[];threads:Thread[];follows:string[];blocks:string[]};
let db:DB=seed();
function rid(){return 'id-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,10);}
function seed():DB{
  const cam:Profile={id:'demo-cam',username:'camille.m',name:'Camille',bio:'De la lumière, la mer et des rencontres. ☀️',avatar:A.camille};
  const leo:Profile={id:'demo-leo',username:'leo.voyage',name:'Léo',bio:'Toujours dehors. 📷',avatar:A.leo};
  const now=Date.now();
  const posts:Post[]=[
    {id:'sample-1',user_id:cam.id,caption:'Le bonheur, c’est parfois juste une fin de journée au bord de l’eau. 🌊 #marseille #voyage',media:[{type:'image',url:A.coast},{type:'image',url:A.city},{type:'image',url:A.cafe}],created_at:new Date(now-3600000).toISOString(),owner:cam,likes:[{user_id:leo.id}],saves:[],comments:[]},
    {id:'sample-2',user_id:leo.id,caption:'Prendre le temps. #nature #weekend',media:[{type:'image',url:A.mountain}],created_at:new Date(now-7200000).toISOString(),owner:leo,likes:[],saves:[],comments:[]},
    {id:'sample-3',user_id:meDemo.id,caption:'Un nouveau départ, toutes nos couleurs. 🏳️‍🌈 #theworldisyour',media:[{type:'image',url:A.city},{type:'image',url:A.coast}],created_at:new Date(now-10800000).toISOString(),owner:meDemo,likes:[{user_id:cam.id}],saves:[],comments:[]}
  ];
  return{profiles:[meDemo,cam,leo],posts,comments:[],messages:[],threads:[{id:'demo-thread',user_a:meDemo.id,user_b:cam.id,peer:cam,created_at:new Date(now).toISOString(),unread:0}],follows:[cam.id],blocks:[]};
}
async function save(){if(demo)await AsyncStorage.setItem(DB_KEY,JSON.stringify(db));}
async function loadDemo(){const raw=await AsyncStorage.getItem(DB_KEY);try{db=raw?JSON.parse(raw):seed();}catch{db=seed();}await save();}

export async function init(){
  const raw=await AsyncStorage.getItem(CONFIG_KEY); if(raw){try{cfg=JSON.parse(raw);}catch{}}
  if(cfg.supabaseUrl&&cfg.supabaseAnonKey){client=createClient(cfg.supabaseUrl,cfg.supabaseAnonKey,{auth:{storage:AsyncStorage,autoRefreshToken:true,persistSession:true,detectSessionInUrl:false}});}
  return cfg;
}
export const configured=()=>!!client;
export async function getConfig(){return cfg;}
export async function setConfig(value:Config){
  let u:URL;try{u=new URL(value.supabaseUrl);}catch{throw new Error('URL Supabase invalide.');}
  if(u.protocol!=='https:'||!u.hostname.endsWith('.supabase.co'))throw new Error('Utilise l’URL HTTPS de ton projet Supabase (.supabase.co).');
  if(value.supabaseAnonKey.startsWith('sb_secret_'))throw new Error('Clé secrète refusée. Utilise seulement la clé publique publishable ou anon.');
  if(!value.supabaseAnonKey.startsWith('sb_publishable_')&&!value.supabaseAnonKey.includes('.'))throw new Error('Clé publique Supabase invalide.');
  cfg=value;await AsyncStorage.setItem(CONFIG_KEY,JSON.stringify(value));
  client=createClient(cfg.supabaseUrl,cfg.supabaseAnonKey,{auth:{storage:AsyncStorage,autoRefreshToken:true,persistSession:true,detectSessionInUrl:false}});
}
export async function clearConfig(){cfg={supabaseUrl:'',supabaseAnonKey:''};client=null;await AsyncStorage.removeItem(CONFIG_KEY);}
export async function startDemo(){demo=true;uid=meDemo.id;await loadDemo();return profile(uid);}
export async function resetDemo(){await AsyncStorage.removeItem(DB_KEY);db=seed();if(demo)await save();}
export async function session(){if(!client)return null;const{data,error}=await client.auth.getSession();if(error)throw error;uid=data.session?.user.id||'';return data.session;}
export async function login(email:string,password:string){if(!client)throw new Error('Configure Supabase ou utilise la démonstration.');const{data,error}=await client.auth.signInWithPassword({email,password});if(error)throw error;uid=data.user.id;return profile(uid);}
export async function signup(email:string,password:string){if(!client)throw new Error('Configure Supabase ou utilise la démonstration.');const{data,error}=await client.auth.signUp({email,password,options:{emailRedirectTo:'theworldisyour://auth'}});if(error)throw error;if(!data.session)return null;uid=data.user!.id;return profile(uid);}
export async function logout(){if(client&&!demo)await client.auth.signOut();demo=false;uid='';signed.clear();}
export async function profile(id:string):Promise<Profile>{if(demo){const p=db.profiles.find(x=>x.id===id);if(!p)throw new Error('Profil introuvable.');return p;}const{data,error}=await client!.from('profiles').select('*').eq('id',id).single();if(error)throw error;return data as Profile;}
export async function updateProfile(p:Profile){p={...p,username:cleanUsername(p.username)};if(p.website&&!safeUrl(p.website))throw new Error('Le lien du profil doit commencer par https://.');if(!validUsername(p.username))throw new Error('Pseudo : 3 à 24 caractères, lettres sans accents, chiffres, points ou _.');if(demo){db.profiles=db.profiles.map(x=>x.id===uid?p:x);db.posts=db.posts.map(x=>x.user_id===uid?{...x,owner:p}:x);await save();return p;}const{error}=await client!.from('profiles').update({username:p.username,name:p.name,bio:p.bio,avatar:p.avatar,website:p.website||''}).eq('id',uid);if(error)throw error;return p;}
export async function posts(offset=0,limit=30):Promise<Post[]>{if(demo)return db.posts.filter(p=>!db.blocks.includes(p.user_id)).slice(offset,offset+limit);const{data,error}=await client!.from('posts').select('*,owner:profiles!posts_user_id_fkey(*),likes(user_id),saves(user_id),comments(id)').order('created_at',{ascending:false}).range(offset,offset+limit-1);if(error)throw error;return data as Post[];}
export async function addPost(caption:string,media:Post['media']){if(demo){db.posts.unshift({id:rid(),user_id:uid,caption,media,created_at:new Date().toISOString(),owner:await profile(uid),likes:[],saves:[],comments:[]});await save();return;}const serial=media.map(m=>({...m,url:typeof m.url==='string'?m.url:'',poster:typeof m.poster==='string'?m.poster:undefined}));const{error}=await client!.from('posts').insert({user_id:uid,caption,media:serial});if(error)throw error;}
export async function removePost(id:string){if(demo){db.posts=db.posts.filter(p=>p.id!==id||p.user_id!==uid);await save();return;}const{error}=await client!.from('posts').delete().eq('id',id).eq('user_id',uid);if(error)throw error;}
export async function toggle(table:'likes'|'saves',post:Post){const exists=post[table].some(l=>l.user_id===uid);if(demo){const p=db.posts.find(x=>x.id===post.id)!;p[table]=exists?p[table].filter(l=>l.user_id!==uid):[...p[table],{user_id:uid}];await save();return;}const q=client!.from(table);const{error}=exists?await q.delete().eq('user_id',uid).eq('post_id',post.id):await q.insert({post_id:post.id,user_id:uid});if(error)throw error;}
export async function getComments(post_id:string):Promise<Comment[]>{if(demo)return db.comments.filter(c=>c.post_id===post_id);const{data,error}=await client!.from('comments').select('*,owner:profiles!comments_user_id_fkey(*)').eq('post_id',post_id).order('created_at').limit(200);if(error)throw error;return data as Comment[];}
export async function comment(post_id:string,body:string){if(demo){const c:Comment={id:rid(),post_id,user_id:uid,body,owner:await profile(uid),created_at:new Date().toISOString()};db.comments.push(c);db.posts.find(p=>p.id===post_id)?.comments.push({id:c.id});await save();return;}const{error}=await client!.from('comments').insert({post_id,user_id:uid,body});if(error)throw error;}
export async function people(q=''):Promise<Profile[]>{if(demo)return db.profiles.filter(p=>p.id!==uid&&!db.blocks.includes(p.id)&&(p.username+' '+p.name).toLowerCase().includes(q.toLowerCase()));let r=client!.from('profiles').select('*').neq('id',uid).limit(40);if(q)r=r.ilike('username','%'+q.replace(/[^\p{L}\p{N}_.]/gu,'')+'%');const{data,error}=await r;if(error)throw error;return data as Profile[];}
export async function following():Promise<string[]>{if(demo)return db.follows;const{data,error}=await client!.from('follows').select('following_id').eq('follower_id',uid);if(error)throw error;return data.map((x:any)=>x.following_id);}
export async function follow(id:string){const follows=await following();if(demo){db.follows=follows.includes(id)?follows.filter(x=>x!==id):[...follows,id];await save();return;}const{error}=follows.includes(id)?await client!.from('follows').delete().eq('follower_id',uid).eq('following_id',id):await client!.from('follows').insert({follower_id:uid,following_id:id});if(error)throw error;}
export async function stats(id:string){if(demo)return{posts:db.posts.filter(p=>p.user_id===id).length,followers:id===uid?0:db.follows.includes(id)?1:0,following:id===uid?db.follows.length:0};const count=async(table:string,column:string)=>{const{count,error}=await client!.from(table).select('*',{count:'exact',head:true}).eq(column,id);if(error)throw error;return count||0;};const[p,f,g]=await Promise.all([count('posts','user_id'),count('follows','following_id'),count('follows','follower_id')]);return{posts:p,followers:f,following:g};}
export async function profilePosts(id:string,saved=false,offset=0):Promise<Post[]>{if(demo)return db.posts.filter(p=>saved?p.saves.some(x=>x.user_id===uid):p.user_id===id).slice(offset,offset+30);let q=client!.from('posts').select('*,owner:profiles!posts_user_id_fkey(*),likes(user_id),saves'+(saved?'!inner':'')+'(user_id),comments(id)').order('created_at',{ascending:false}).range(offset,offset+29);q=saved?q.eq('saves.user_id',uid):q.eq('user_id',id);const{data,error}=await q;if(error)throw error;return data as unknown as Post[];}
export async function openThread(peer:Profile):Promise<Thread>{if(demo){let t=db.threads.find(t=>t.peer.id===peer.id);if(!t){t={id:rid(),user_a:uid,user_b:peer.id,peer,created_at:new Date().toISOString(),unread:0};db.threads.push(t);await save();}return t;}const{data,error}=await client!.rpc('open_thread',{peer_id:peer.id});if(error)throw error;return{...(data as any),peer,unread:0};}
export async function threads():Promise<Thread[]>{if(demo)return db.threads.filter(t=>!db.blocks.includes(t.peer.id)).map(t=>({...t,last:db.messages.filter(m=>m.thread_id===t.id).at(-1)}));const{data,error}=await client!.rpc('inbox');if(error)throw error;return(data||[]) as Thread[];}
async function mediaUrl(path:string):Promise<string>{if(!path)return'';if(demo)return path;const found=signed.get(path);if(found&&found.until>Date.now())return found.url;const{data,error}=await client!.storage.from('chat-media').createSignedUrl(path,3600);if(error)throw error;signed.set(path,{url:data.signedUrl,until:Date.now()+3000000});return data.signedUrl;}
export async function messages(thread_id:string):Promise<Message[]>{if(demo)return db.messages.filter(m=>m.thread_id===thread_id).map(m=>({...m,url:m.media_path}));const{data,error}=await client!.from('messages').select('*').eq('thread_id',thread_id).order('created_at',{ascending:false}).limit(200);if(error)throw error;return Promise.all((data||[]).reverse().map(async(m:any)=>({...m,url:await mediaUrl(m.media_path)})));}
export async function markRead(thread_id:string){if(demo)return;const{error}=await client!.from('messages').update({read_at:new Date().toISOString()}).eq('thread_id',thread_id).neq('sender_id',uid).is('read_at',null);if(error)throw error;}
export async function send(thread_id:string,kind:Message['kind'],body='',media_path=''){if(demo){db.messages.push({id:rid(),thread_id,sender_id:uid,kind,body,media_path,created_at:new Date().toISOString(),read_at:null});await save();return;}const{error}=await client!.from('messages').insert({thread_id,sender_id:uid,kind,body,media_path});if(error)throw error;}
function extFor(file:PickedFile){return(file.fileName?.split('.').pop()||file.mimeType.split('/').pop()||'bin').replace(/[^a-z0-9]/gi,'').slice(0,8);}
export async function upload(file:PickedFile,progress:(n:number)=>void,thread?:string):Promise<string>{
  if((file.fileSize||0)>50*1024*1024)throw new Error('Ce fichier dépasse 50 Mo. Choisis une version plus légère.');
  if(!/^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|quicktime)|audio\/(webm|ogg|mp4|mpeg|wav|m4a|x-m4a))/.test(file.mimeType))throw new Error('Format non pris en charge.');
  if(demo){progress(100);return file.uri;}
  const bucket=thread?'chat-media':'media';const path=(thread?thread+'/':'')+uid+'/'+rid()+'.'+extFor(file);progress(8);
  const res=await fetch(file.uri);const body=await res.arrayBuffer();progress(55);
  const{error}=await client!.storage.from(bucket).upload(path,body,{contentType:file.mimeType,upsert:false});if(error)throw error;progress(100);
  return thread?path:client!.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}
export async function block(id:string){if(demo){if(!db.blocks.includes(id))db.blocks.push(id);await save();return;}const{error}=await client!.from('blocks').insert({user_id:uid,blocked_id:id});if(error&&(error as any).code!=='23505')throw error;}
export async function report(post_id:string,reason:string){if(demo)return;const{error}=await client!.from('reports').insert({user_id:uid,post_id,reason});if(error)throw error;}
export async function resolveAsset(ref:AssetRef){return ref;}
