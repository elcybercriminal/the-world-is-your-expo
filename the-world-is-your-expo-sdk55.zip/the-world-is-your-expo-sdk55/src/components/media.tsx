import React,{useEffect,useMemo,useRef,useState} from 'react';
import {Dimensions,FlatList,Image,LayoutChangeEvent,PanResponder,Pressable,StyleSheet,Text,View} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import {useEvent} from 'expo';
import {VideoView,useVideoPlayer} from 'expo-video';
import {WebView} from 'react-native-webview';
import type {Media} from '../types';
import type {Colors} from '../theme';
import {sourceFor,uriFor} from '../logic';
import {IconButton} from './ui';

const SCREEN=Dimensions.get('window');
export function NativeVideo({uri,active,full=false,colors}:{uri:string;active:boolean;full?:boolean;colors:Colors}){
 const player=useVideoPlayer(uri,p=>{p.loop=true;p.muted=true;p.timeUpdateEventInterval=.15;});
 const [muted,setMuted]=useState(true);const [trackW,setTrackW]=useState(0);
 const time=useEvent(player,'timeUpdate',{currentTime:0,bufferedPosition:0,currentLiveTimestamp:null,currentOffsetFromLive:null});
 const playing=useEvent(player,'playingChange',{isPlaying:false} as any);
 useEffect(()=>{player.muted=muted;},[muted]);
 useEffect(()=>{if(active)player.play();else player.pause();},[active]);
 const duration=Math.max(0,player.duration||0),current=Math.max(0,(time as any).currentTime||player.currentTime||0);const ratio=duration?Math.min(1,current/duration):0;
 const seek=(x:number)=>{if(!duration||!trackW)return;player.currentTime=Math.max(0,Math.min(duration,(x/trackW)*duration));};
 const pan=useMemo(()=>PanResponder.create({onStartShouldSetPanResponder:()=>full,onMoveShouldSetPanResponder:()=>full,onPanResponderGrant:e=>seek(e.nativeEvent.locationX),onPanResponderMove:e=>seek(e.nativeEvent.locationX)}),[duration,trackW,full]);
 return <View style={StyleSheet.absoluteFill}>
   <Pressable style={StyleSheet.absoluteFill} onPress={()=>{if(full){if((playing as any).isPlaying??player.playing)player.pause();else player.play();}}}>
    <VideoView player={player} style={StyleSheet.absoluteFill} contentFit={full?'contain':'cover'} nativeControls={false} surfaceType="textureView"/>
   </Pressable>
   <IconButton name={muted?'volume-mute':'volume-high'} label={muted?'Activer le son':'Couper le son'} onPress={()=>setMuted(v=>!v)} color="#fff" size={18} style={[m.sound,full&&m.soundFull]}/>
   {full&&<View style={m.progressTouch} onLayout={(e:LayoutChangeEvent)=>setTrackW(e.nativeEvent.layout.width)} {...pan.panHandlers}><View style={m.progressTrack}><View style={[m.progressFill,{width:`${ratio*100}%`}]} /></View></View>}
 </View>;
}
export function MediaItem({media,active,full,colors}:{media:Media;active:boolean;full:boolean;colors:Colors}){
 if(media.type==='image')return <Image source={sourceFor(media.url)} resizeMode={full?'contain':'cover'} style={StyleSheet.absoluteFill}/>;
 if(media.type==='video')return <NativeVideo uri={uriFor(media.url)} active={active} full={full} colors={colors}/>;
 const uri=uriFor(media.url);return <WebView source={{uri}} style={StyleSheet.absoluteFill} javaScriptEnabled allowsFullscreenVideo mediaPlaybackRequiresUserAction={false} originWhitelist={['https://*']} />;
}
export function MediaCarousel({media,active,full=false,colors,onDoubleTap,onOpen}:{media:Media[];active:boolean;full?:boolean;colors:Colors;onDoubleTap?:()=>void;onOpen?:()=>void}){
 const [index,setIndex]=useState(0);const last=useRef(0);const single=useRef<ReturnType<typeof setTimeout>|null>(null);const width=SCREEN.width;
 useEffect(()=>()=>{if(single.current)clearTimeout(single.current);},[]);
 const tap=()=>{const now=Date.now();if(now-last.current<300){if(single.current)clearTimeout(single.current);single.current=null;onDoubleTap?.();last.current=0;}else{last.current=now;if(onOpen)single.current=setTimeout(()=>{single.current=null;onOpen();},260);}};
 return <View style={[m.wrap,full?m.full:{height:Math.min(SCREEN.width*1.12,650)}]}>
  <FlatList horizontal pagingEnabled showsHorizontalScrollIndicator={false} data={media} keyExtractor={(_,i)=>String(i)} onMomentumScrollEnd={e=>setIndex(Math.round(e.nativeEvent.contentOffset.x/e.nativeEvent.layoutMeasurement.width))} renderItem={({item,index:i}:any)=><Pressable onPress={tap} style={{width,height:'100%'}}><MediaItem media={item} active={active&&i===index} full={full} colors={colors}/></Pressable>}/>
  {media.length>1&&<><View style={m.counter}><Text style={m.counterText}>{index+1}/{media.length}</Text></View><View style={[m.dots,full&&{bottom:150}]}>{media.map((_,i)=><View key={i} style={[m.dot,i===index&&m.dotOn]}/>)}</View></>}
 </View>;
}
export const m=StyleSheet.create({
 wrap:{width:'100%',backgroundColor:'#141418',position:'relative'},full:{height:'100%',width:SCREEN.width,backgroundColor:'#000'},
 counter:{position:'absolute',right:12,top:12,backgroundColor:'#0008',borderRadius:20,paddingHorizontal:10,paddingVertical:6},counterText:{color:'#fff',fontSize:11},
 dots:{position:'absolute',left:0,right:0,bottom:14,flexDirection:'row',justifyContent:'center',gap:5},dot:{width:6,height:6,borderRadius:3,backgroundColor:'#ffffff66'},dotOn:{width:16,backgroundColor:'#fff'},
 sound:{position:'absolute',right:12,bottom:13,backgroundColor:'#0008',width:34,height:34},soundFull:{right:18,bottom:235},
 progressTouch:{position:'absolute',left:0,right:0,bottom:0,height:25,justifyContent:'flex-end'},progressTrack:{height:3,backgroundColor:'#ffffff55'},progressFill:{height:3,backgroundColor:'#fff'}
});
