import React from 'react';
import {Image,Pressable,StyleSheet,Text,View,ViewStyle} from 'react-native';
import Ionicons from '@expo/vector-icons/Ionicons';
import {LinearGradient} from 'expo-linear-gradient';
import type {Profile} from '../types';
import type {Colors} from '../theme';
import {RAINBOW} from '../theme';
import {sourceFor} from '../logic';

export function IconButton({name,label,onPress,color,size=23,disabled=false,style}:{name:any;label:string;onPress?:()=>void;color:string;size?:number;disabled?:boolean;style?:ViewStyle}){
  return <Pressable accessibilityLabel={label} disabled={disabled} onPress={onPress} style={({pressed})=>[s.iconButton,style,pressed&&{opacity:.6},disabled&&{opacity:.35}]}><Ionicons name={name} size={size} color={color}/></Pressable>;
}
export function RainbowMark({size=34}:{size?:number}){return <LinearGradient colors={RAINBOW} start={{x:0,y:0}} end={{x:1,y:1}} style={[s.mark,{width:size,height:size,borderRadius:size*.35}]}><Text style={[s.markText,{fontSize:size*.82}]}>W</Text></LinearGradient>}
export function Avatar({person,size=38,ring=false,onPress,colors}:{person:Profile;size?:number;ring?:boolean;onPress?:()=>void;colors:Colors}){
 const body=<View style={[s.avatar,{width:size,height:size,borderRadius:size/2,backgroundColor:colors.panel}]}>{person.avatar?<Image source={sourceFor(person.avatar)} style={{width:'100%',height:'100%',borderRadius:size/2}} resizeMode="cover"/>:<Text style={{color:colors.text,fontWeight:'800',fontSize:size*.38}}>{(person.name||person.username||'?')[0]?.toUpperCase()}</Text>}</View>;
 const inner=ring?<LinearGradient colors={RAINBOW} style={{padding:3,borderRadius:size/2+4}}>{React.cloneElement(body,{style:[body.props.style,{borderWidth:3,borderColor:colors.bg}]})}</LinearGradient>:body;
 return onPress?<Pressable onPress={onPress}>{inner}</Pressable>:inner;
}
export function Header({title,onBack,right,colors}:{title:string;onBack?:()=>void;right?:React.ReactNode;colors:Colors}){return <View style={[s.header,{backgroundColor:colors.bg}]}>{onBack?<IconButton name="chevron-back" label="Retour" onPress={onBack} color={colors.text}/>:<View style={{width:42}}/>}<Text numberOfLines={1} style={[s.headerTitle,{color:colors.text}]}>{title}</Text>{right||<View style={{width:42}}/>}</View>}
export function Empty({title,body,colors,icon='camera-outline'}:{title:string;body:string;colors:Colors;icon?:any}){return <View style={s.empty}><View style={[s.emptyIcon,{borderColor:colors.line}]}><Ionicons name={icon} size={30} color={colors.accent}/></View><Text style={[s.emptyTitle,{color:colors.text}]}>{title}</Text><Text style={[s.emptyBody,{color:colors.muted}]}>{body}</Text></View>}
export function PrimaryButton({title,onPress,disabled=false,colors}:{title:string;onPress:()=>void;disabled?:boolean;colors:Colors}){return <Pressable disabled={disabled} onPress={onPress} style={{opacity:disabled ? .45 : 1}}><LinearGradient colors={['#c32655','#bb5412','#817210','#177e61','#236db0','#7736b1']} start={{x:0,y:.5}} end={{x:1,y:.5}} style={s.primary}><Text style={s.primaryText}>{title}</Text></LinearGradient></Pressable>}
export function SecondaryButton({title,onPress,colors}:{title:string;onPress:()=>void;colors:Colors}){return <Pressable onPress={onPress} style={[s.secondary,{backgroundColor:colors.panel,borderColor:colors.line}]}><Text style={{color:colors.text,fontWeight:'700'}}>{title}</Text></Pressable>}
export function TabChip({title,active,onPress,colors}:{title:string;active:boolean;onPress:()=>void;colors:Colors}){return <Pressable onPress={onPress} style={[s.chip,{backgroundColor:active?colors.accent+'20':colors.panel}]}><Text style={{fontSize:12,fontWeight:active?'800':'500',color:active?colors.accent:colors.text}}>{title}</Text></Pressable>}
export const s=StyleSheet.create({
 iconButton:{width:42,height:42,alignItems:'center',justifyContent:'center',borderRadius:21},
 mark:{alignItems:'center',justifyContent:'center'},markText:{color:'#fff',fontWeight:'900',fontFamily:'sans-serif-condensed',lineHeight:34},
 avatar:{overflow:'hidden',alignItems:'center',justifyContent:'center'},
 header:{height:62,flexDirection:'row',alignItems:'center',paddingHorizontal:10},headerTitle:{flex:1,fontSize:22,fontWeight:'800',letterSpacing:-.7,textAlign:'center'},
 empty:{paddingHorizontal:25,paddingVertical:50,alignItems:'center',gap:12},emptyIcon:{width:68,height:68,borderRadius:34,borderWidth:1,alignItems:'center',justifyContent:'center'},emptyTitle:{fontSize:18,fontWeight:'800'},emptyBody:{fontSize:13,lineHeight:22,textAlign:'center',maxWidth:290},
 primary:{minHeight:48,borderRadius:13,alignItems:'center',justifyContent:'center',paddingHorizontal:20},primaryText:{color:'#fff',fontWeight:'800',fontSize:14},
 secondary:{minHeight:44,borderRadius:11,borderWidth:1,alignItems:'center',justifyContent:'center',paddingHorizontal:18},
 chip:{paddingHorizontal:15,paddingVertical:8,borderRadius:20}
});
