import {useColorScheme} from 'react-native';
import type {ThemeMode} from './types';
export const RAINBOW=['#f84655','#ff8a32','#eec638','#39b77b','#2892f0','#a44eff'] as const;
export const light={bg:'#ffffff',panel:'#f5f5f7',text:'#18181b',muted:'#818188',line:'#e9e9ed',accent:'#a62bdd',chat:'#ffffff',danger:'#ff456a'};
export const dark={bg:'#111113',panel:'#202023',text:'#f7f7f8',muted:'#929299',line:'#2b2b2f',accent:'#d086fa',chat:'#050505',danger:'#ff617e'};
export type Colors=typeof light;
export function useResolvedTheme(mode:ThemeMode){const system=useColorScheme();const darkMode=mode==='dark'||(mode==='system'&&system==='dark');return{colors:darkMode?dark:light,dark:darkMode};}
